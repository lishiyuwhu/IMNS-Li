#! /usr/bin/env python
# $Id$

"""
Calculate the FP and FN rates given a feature file and
a prediction file.  Assuming libsvm format.
"""

from numpy import sign,log10,ceil
import optparse 
parser = optparse.OptionParser()
parser.add_option("-t", "--truefile", help="File with true labels",
          dest="truefile" )
parser.add_option("-l", "--latex", help="Create LaTeX tabular.",
          action="store_true",default=False, dest="latex" )
(options,args) = parser.parse_args()

def getlist(infile):
  f = open(infile,"r")
  L = [ int(l.split()[0]) for l in f.readlines() ]
  f.close()
  return L

header = "  FP\t  FN\t  FPR\t  FNR"
def lheader():
  print "\\begin{tabular}{|l||r|r||r|r|}\n\\hline"
  print "& FP & FN &  FP rate & FN rate \\\\"
  print "\\hline\\hline"

def pad(s,n):
  return s + (n-len(s))*" "

def accuracy(Lp,Lt,getstr=False,latex=False):
  assert len(Lp) == len(Lt)
  lt = len(Lp)
  af = "%%%ii\t" % (ceil(log10(lt)))

  D = [ sign(Lp[i]-Lt[i]) for i in xrange(lt) ]

  FP = D.count(1)
  FN = D.count(-1)
  
  TP = Lt.count(1)
  TN = Lt.count(0)
  R = (FP,FN,100.0*FP/TP,100.0*FN/TN)
  if latex: return "& %i & %i & %2.1f\\%% & %2.1f\\%% \\\\" % R
  elif getstr: return (2*af + 2*"%2.1F%%\t") % R
  else: return R

if options.truefile == None:
  assert False == options.latex
  Lp = getlist(args[0])
  Lt = getlist(args[1])
  (FP,FN,FPR,FNR) = accuracy(Lp,Lt)
  print "FP:", FP, FPR
  print "FN:", FN, FNR
else:
  Lt = getlist(options.truefile)
  if options.latex: lheader()
  else: print "\t\t" + header
  for f in args:
    Lp = getlist(f)
    fb = f.split("-")[0]
    if options.latex:
      print pad(fb,12) + "\t" + accuracy(Lp,Lt,latex=True)
    else:
      print pad(fb,12) + "\t" + accuracy(Lp,Lt,getstr=True)
  if options.latex: print "\\hline\n\\end{tabular}"
