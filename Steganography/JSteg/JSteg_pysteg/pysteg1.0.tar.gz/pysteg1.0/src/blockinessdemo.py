#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# Blockiness Demo
# ===============
#
# :Script:    blockinessdemo.py
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

import matplotlib
matplotlib.use( "Cairo" )
matplotlib.rcParams["font.size"] = 8
import matplotlib.pyplot as plt

from optparse import OptionParser
from pysteg.sim.jim import bnessjim, jim as plainjim

# Argument Parsing
# ----------------

parser = OptionParser()

parser.add_option("-s", "--msg-step", help="Message length step size.",
          dest="msgstep", default=0.05 )
parser.add_option("-o", "--outfile", help="Output file",
          dest="outfile" )
parser.add_option("-l", "--alpha", help="The order of the norm.",
          dest="alpha", default=1 )
parser.add_option("-A", "--algorithm", help="The algorithm to be used.",
          dest="alg", default="f5" )
parser.add_option("-L", "--legend", help="Location of the legend",
          dest="loc", default="upper left" )
parser.add_option("-y", "--ylim", help="Limits for the y axist.",
          dest="ylim" )
parser.add_option("-a", "--all-algorithms", help="The algorithm to be used.",
          dest="allalg", action="store_true", default=False )
parser.add_option("-c", "--calibration",
          help="Compare with blockiness for calibrated images.",
          dest="cal", action="store_true", default=False )

(opt,args) = parser.parse_args()

msgstep = float(opt.msgstep)
alpha = int(opt.alpha)
if opt.cal: jim = bnessjim
else: jim = plainjim

# The main function
# -----------------

def mplot(alg,infile,*a,**kw):
   im = plainjim ( alg, infile, *a, **kw) 
   im.fplot("-",label="Image")
   im = plainjim ( alg, infile, cal=True, *a, **kw) 
   im.fplot("--",label="Calibrated")
   im = plainjim ( alg, infile, emb=True, *a, **kw) 
   im.fplot(":",label="Reembedded")

def main():
  
  fl = args
  print len(fl)
  plt.figure(figsize=(5,3.2))
  plt.xlim(0,1.05)
  if opt.ylim: plt.ylim( *eval(opt.ylim) )
  plt.xlabel( "Message length" )
  plt.ylabel( "Blockiness" )

  A = [ "+", "x", "o", "*", "d" ]
  B = [ "-", ":", "-.", "--" ]
  idx = 0

  if opt.allalg and opt.cal:
     assert len(args) == 1
     infile = args[0]
     im = jim ( "f5", infile, msgstep=msgstep ) 
     im.fplot("+",label=False)
     im = jim ( "f1", infile, msgstep=msgstep ) 
     im.fplot("",)
  elif opt.cal:
     assert len(args) == 1
     infile = args[0]
     mplot(opt.alg,infile,msgstep=msgstep )
  else:
    for infile in fl:
      im = jim ( opt.alg, infile, msgstep=msgstep ) 
      if opt.allalg:
        assert not opt.cal
	im.fplot("k+"+B[idx],"f5",alpha=alpha,label=False)
        im.fplot("k"+B[idx],"f1",alpha=alpha,label=infile)
      else: im.fplot(A[idx]+"-")
      idx += 1
  leg = plt.legend( loc=opt.loc ) # ,bbox_to_anchor=(1,0.5))
  if opt.outfile != None:
    plt.savefig(opt.outfile,pad_inches=0.3)

if __name__ == "__main__": main()
