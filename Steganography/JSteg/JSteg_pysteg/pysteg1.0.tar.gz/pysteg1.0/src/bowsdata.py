#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

docstring = """
:Script:    bowsdata.py
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

This script is used to generate a file specifying feature vectors
(objects) for test and training sets.

bowsdata.py -c cdir -s sdir -n N -e outfile [-v verbosity] [from to]
  Randomly draw images to build training and test sets.
  This is used to be able to run multiple or repeat experiments
  using the same dataset.

  Clean images are taken from cdir, and steganograms from sdir.
  It is assumed that both directories contain the same filenames,
  representing the same image with and without embedding.  Only
  one version of each image is used, and the same number of images
  are used for each class.

  For each class N images are used for the training set; the 
  remainder is used for the test set.  The result is a pickled
  object written to outfile.  Note that the outfile does not
  contain features, as that would create impractical file sizes;
  only filenames are stored.

  If the from and to argumetns are given, they indicate a range
  of images to use, assuming the files are named as a number with
  the ".pgm.jpg" option.  The range includes no. from, but excludes
  no. to.  This has been specially designed to work with the BOWS image
  set, with images numbered from 0 through 10000, and it will skip
  image no. 3661 which is missing in BOWS.
"""

from itml.eval import fvEval,hstring
import pysteg.tools as pt 
import optparse 
import pickle 

# Parse options
# -------------
#
# ::

parser = optparse.OptionParser()
parser.add_option("-c", "--clean-dir",
          help="Directory of clean images.",
          dest="cdir" )
parser.add_option("-s", "--stego-dir",
          help="Directory of steganogrammes.",
          dest="sdir" )
parser.add_option("-n", "--image-count",
          help="Number of images to use for training from each class.",
          dest="imgcount" )
parser.add_option("-x", "--extension",
          help="File name extension for input files.",
          dest="ext", default=".pgm.dat" )
parser.add_option("-e", "--fveval-file",
          help="Output file for a pickled fvEval object",
          dest="fvfile" )
parser.add_option("-1", "--one-class", 
          help="Create data sets for one-class SVM.",
          default=False, dest="oneclass", action="store_true" )
parser.add_option("-v", "--verbose", 
          help="Verbosity level",
          default=2,dest="verbosity" )
(opt,args) = parser.parse_args()

# Interpret options
# -----------------
#
# ::

verbosity = int(opt.verbosity)

# Main Functionality
# ------------------
#
# ::

def mkEval(**kw):
   ev = fvEval(opt.cdir,opt.sdir,**kw)
   assert opt.fvfile != None
   f = open(opt.fvfile,"wb")
   pickle.dump(ev,f)
   f.close()

def main():
   assert opt.cdir != None, "No directory of clean images"
   assert opt.sdir != None, "No directory of steganogrammes"
   kw = { "verbosity" : verbosity }
   if len(args) == 2:
      kw["filelist"] = [ str(i) + opt.ext
	      for i in xrange(int(args[0]),int(args[1])) 
	      if i != 3661 ]
   if opt.imgcount != None:
      kw["N"] = int(opt.imgcount)
   if opt.oneclass: kw["oneclass"] = True
   return mkEval(**kw)

if __name__ == "__main__":
    main()
