#! /usr/bin/env python
## -*- coding: utf-8 -*-
## $Id$

docstring="""
:Script:    cliselect.py
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "$Id$"

from itml.cliselect import *
from itml.mysocket import *
import optparse 

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

  parser.add_option("-H", "--host", 
            help="Hostname of the server",
            default=defaultHost, dest="host" )
  parser.add_option("-p", "--port", 
            help="Port number",
            default=defaultPort, dest="port" )
  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            default=0, dest="verbosity" )

  (opt,a) = parser.parse_args()
  opt.verbosity = int( opt.verbosity )
  return (opt,a)

if __name__ == "__main__":
   (opt,a) = parseArgs()
   if opt.port: port = int( opt.port )
   else: port = None
   run(host=opt.host,port=port,verbosity=opt.verbosity)
