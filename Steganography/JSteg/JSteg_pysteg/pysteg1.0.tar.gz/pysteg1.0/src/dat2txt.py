#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# Text file feature sets
# ======================

docstring = """
:Script:    dat2txt.py
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

This script is designed to convert pickled objects containing feature
sets into text files, either comma-separated values or the libsvm 
sparse format.

dat2txt.py -i datfile -O dictfile -o outfile -t testfile [-f id] [-C]
  Read the datfile which should be a pickled python objects
  (different classes are supported).  The feature vectors
  are written to outfile.  If the object includes both
  a training and a test set, the training set is written
  to outfile and the test data to testfile.

  If -O is given, a pickled dictionary object is written to dictfile,
  with the elements FV for training feature vectors, PV for
  training labels, FV1 for test set feature vecors and PV1 for
  test set labels.  (Not implemented yet.)

  If -C is specified, the output is comma-separated values.
  Otherwise the sparse libsvm format is used.

  If the -f option is given, id specifies a feature subvector
  See svmtest.py for further details.
"""

import optparse 
import svm.tools as stools
import pysteg.tools as pt

# Parsing Options
# ---------------

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

# The following are core options, fully supported and validated.
#
# ::

# File name options::

  parser.add_option("-O", "--dictionary-file",
            help="""Output file for the pickled dictionary object.""",
            dest="dictfile" )
  parser.add_option("-o", "--outfile",
            help="""Output file for the training set text file.""",
            dest="outfile" )
  parser.add_option("-i", "--infile",
            help="Input data file for a pickled DataSet object",
            dest="infile" )
  parser.add_option("-t", "--test-outfile",
            help="""Output file for the test set.""",
            dest="testfile" )
  parser.add_option("-T", "--test-stegofile",
            help="""Output file for the stego test set.""",
            dest="stegofile" )
  parser.add_option("-C", "--csv-format", 
            help="Print features as CSV file instead of libsvm.",
            dest="libsvm", default=True,
	    action='store_false' )

# Other options::

  parser.add_option("-f", "--feature-set", 
            help="Feature set identifier (e.g. Fridrich, Markov, CP)",
            dest="id" )
  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            default=0, dest="verbosity" )

  (opt,a) = parser.parse_args()

# Some options need to be converted to appropriate data types::

  opt.verbosity = int(opt.verbosity)

  return (opt,a)

def newlabels(L):
   i = 1
   D = {}
   for k in set(L):
      D[k] = i
      i += 1
   return [ D[k] for k in L ]

# The actual work
# ===============
#
#   ::

if __name__ == '__main__':
  (opt,args) = parseArgs()

  assert opt.infile != None
  X = pt.loadObject( opt.infile )
  if hasattr(X,"load"): X.load()
  print "[svmtest] loaded object"

# The :class:`fvEval` object has :meth:`testVectors` and :meth:`iterVectors`
# methods to get iterators of lists representing feature vectors. 

  if opt.stegofile != None:
     if hasattr(X,"testCover"):
	  test = X.testCoverVectors( opt.id )
	  test1 = X.testStegoVectors( opt.id )
     else: raise Exception, "-T is only supported for fvEval objects."
     stools.savefeatures(opt.testfile,test,opt.libsvm)
     stools.savefeatures(opt.stegofile,test1,opt.libsvm)
  elif opt.testfile != None:
     if hasattr(X,"testVectors"):
	  test = X.testVectors( opt.id )
     elif X.has_key( "FV1"):
	  test = stools.fvjoin(newlabels(X["PV1"]), list(X["FV1"]) )
     stools.savefeatures(opt.testfile,test,opt.libsvm)

  if opt.outfile != None:
     if hasattr(X,"iterVectors"):
	  train = X.iterVectors( opt.id )
     elif X.has_key( "FV"):
	  train = stools.fvjoin(newlabels(X["PV"]), list(X["FV"]) )
     else: train = None
     stools.savefeatures(opt.outfile,train,opt.libsvm)

  if opt.dictfile != None:
	  raise NotImplementedError

