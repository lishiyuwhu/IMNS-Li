#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# SVM Testing
# ===========

docstring = """
:Script:    eval.py
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

# This script is used to evaluate features using information theory.
# It should be revised and documented.
"""

# We have to choose a batch friendly engine for matplotlib, before
# other packages load pyplot::

import matplotlib
matplotlib.use( "Cairo" )

from itml.eval import fvEval
import pysteg.tools as pt 
import optparse 
import pickle 

# Parse options
# -------------
#
# ::

parser = optparse.OptionParser()
parser.add_option("-i", "--infile",
          help="Input file (pickled fvEval object).",
          dest="infile" )
parser.add_option("-c", "--clean-dir",
          help="Directory of clean images.",
          dest="cdir" )
parser.add_option("-s", "--stego-dir",
          help="Directory of steganogrammes.",
          dest="sdir" )
parser.add_option("-n", "--image-count",
          help="Number of images to use from each class.",
          dest="imgcount" )
parser.add_option("-R", "--no-loading",
          help="Do not rank nor load features.",
          default=True, action='store_false', dest="load" )
parser.add_option("-e", "--fveval-file",
          help="Output file for a pickled fvEval object",
          dest="fvfile" )
parser.add_option("-o", "--outfile",
          help="Text output file.",
          dest="outfile" )
parser.add_option("-p", "--second-order",
          help="""Calculate second order heuristics with given primary feature
	       fixed""",
          dest="primary" )
parser.add_option("-H", "--hist", 
          help="Generate histogram on given file",
          dest="histfile" )
parser.add_option("-x", "--exclude-extremal", 
          help="Exclude objects with feature exceeding /exclude/ std. deviations.",
          dest="exclude" )
parser.add_option("-D", "--pre-sorted",
          help="Images are not repeated in the stego and clean directories.",
          dest="complete", action="store_false", default=True )
parser.add_option("-v", "--verbose", 
          help="Verbosity level",
          default=2,dest="verbosity" )
(opt,args) = parser.parse_args()

# Interpret options
# -----------------
#
# ::

verbosity = int(opt.verbosity)
if opt.exclude != None: opt.exclude = int(opt.exclude)

# Main Functionality
# ------------------
#
# ::

def main():
   if opt.infile != None:
     ev = pt.loadObject(opt.infile)
   else:
     assert opt.cdir != None, "No directory of clean images"
     assert opt.sdir != None, "No directory of steganogrammes"
     kw = { "verbosity" : verbosity,
	   "complete" : opt.complete,
	   }
     if opt.imgcount != None: kw["N"] = int(opt.imgcount)
     ev = fvEval(opt.cdir,opt.sdir,**kw)
     if opt.load: ev.load()
   if opt.fvfile != None:
      assert opt.infile == None, \
	     "If you really want to copy the file, use cp(1)."
      f = open(opt.fvfile,"wb")
      pickle.dump(ev,f)
      f.close()
   if opt.histfile != None:
      ev.hist(int(opt.primary),opt.histfile)

if __name__ == "__main__":
    main()
