#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

"""
Quick script to list feature names (keys) from a pickled
feature vector.

:Script:    featurelist.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

# We may want to extend this later with other diagnostics.

import optparse 
from pysteg.tools import loadObject

def main():

# Parsing Options
# ---------------

  parser = optparse.OptionParser()

  parser.add_option("-L", "--list-names",
            help="List feature component names with numbers.",
            dest="List", default=False,
	    action='store_true' )
  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            dest="verbosity" )
  (opt,args) = parser.parse_args()

# Do the work
# -----------

  assert len(args) == 1, "One and only one filename required"
  X = loadObject(args[0])
  X.listnames()

if __name__ == '__main__': main()
