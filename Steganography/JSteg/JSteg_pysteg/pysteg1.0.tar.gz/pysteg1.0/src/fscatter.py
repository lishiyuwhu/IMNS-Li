#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# SVM Testing
# ===========
#
# :Script:    fscatter.py
# :Date:      $Date$
# :Revision:  $Revision$
# Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>


docstring = """
datsvm [-o plot.pdf] -i data.dat idx
datsvm [-o output dir] -i data.dat idx1 idx2 ...
datsvm [-o output dir] -i data.dat -a
datsvm [-o output dir] -i data.dat -I range(idx1,idxN)
"""

import optparse 
import sys
import subprocess

import matplotlib
matplotlib.use( "Cairo" )
import matplotlib.pyplot as plt

from pysteg.tools import loadObject
from itml.eval import fvScatter
from itertools import imap

# Function Definitions
# ====================

# Parsing Options
# ---------------

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

# The following are core options, fully supported and validated.
#
# ::

  parser.add_option("-o", "--outfile",
            help="""Output file for the one-feature scatter plots.""",
            dest="outfile" )
  parser.add_option("-O", "--ccoutfile",
            help="""Output file for the two-feature scatter plots.""",
            dest="ccoutfile" )
  parser.add_option("-H", "--histfile",
            help="""Output file for the histogram plot.""",
            dest="histfile" )
  parser.add_option("-X", "--experimental-histograms",
            help="""Create experimental histogram plots.""",
            dest="xhist", default=False, action="store_true" )
  parser.add_option("-i", "--infile",
            help="Input data file for a pickled DataSet object",
            dest="infile" )
  parser.add_option("-I", "--index-eval",
            help="Indices given as an expression to be evaluated.",
            dest="idxeval" )
  parser.add_option("-a", "--all",
            help="Make plots for all features.",
            dest="all", default=False, action="store_true" )
  parser.add_option("-x", "--exclude-extremal", 
     help="Exclude objects with feature exceeding /exclude/ std. deviations.",
     dest="exclude" )
  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            dest="verbosity" )
  (opt,a) = parser.parse_args()

# Some options need to be converted to appropriate data types::

  if opt.verbosity != None:
    opt.verbosity = int(opt.verbosity)

  return (opt,a)

# The actual work
# ===============
#
#   ::

if __name__ == '__main__':
  (opt,args) = parseArgs()

  assert opt.infile != None, "No input file is given"
  X = loadObject( opt.infile )
  print "[svmtest] loaded object"
  sys.stdout.flush()

  # We need to reformat the arguments::

  if opt.all: idx = None
  elif opt.idxeval != None: idx = eval(opt.idxeval)
  elif len(args) == 1: idx = eval(args[0])
  else: idx = map(eval,args)

  # If -o is given, we create one-feature scatter plots::

  if opt.outfile != None:
     S = fvScatter( X, opt.verbosity )
     print "[svmtest] created fvScatter object"
     S.scatterplot(opt.outfile,idx=idx)

  # If -O is given, we create two-feature scatter plots::

  if opt.ccoutfile != None:
     assert len(idx) == 2
     X.ccscatter(idx[0],idx[1],opt.ccoutfile)

  # If -H is given, we create histograms::

  elif opt.histfile != None:
     X.hist(idx,opt.histfile)
  elif opt.xhist:
     try:
       X.hist(idx,"hist-n-i.pdf", independent=True )
     except Exception as e: pass
     try:
       X.hist(idx,"hist-n-s.pdf", independent=False )
     except Exception as e: pass
     if opt.exclude != None:
       try:
         X.hist(idx,"hist-x" + str(opt.exclude) + "-i.pdf",
	     exclude=int(opt.exclude), independent=True )
       except Exception as e: pass
       try:
         X.hist(idx,"hist-x" + str(opt.exclude) + "-s.pdf",
	     exclude=int(opt.exclude), independent=False )
       except Exception as e: pass

  print "[svmtest] completed test run"
