#!/usr/bin/env python
# $Id$

import os, sys
from svm.gnuplot import GnuPlot
from svm.gridsearch import gridsearch

import svm.svmutil as svmutil
import svm.svm as svm0

class Options(object):
  """
    A class to parse and store command line arguments and system
    parameters.
  """

  nr_local_worker = 1
  fold = 5
  crange = ( -5,  15,  2)
  grange = (  3, -15, -2)
  verbosity = 1

  def __init__(self):
    "Initialise.  System parameters are inspected now."
    is_win32 = (sys.platform == 'win32')
    if not is_win32:
       self.gnuplot_exe = "/usr/bin/gnuplot"
    else:
       # example for windows
       self.gnuplot_exe = r"c:\tmp\gnuplot\bin\pgnuplot.exe"

# process command line options, set global parameters
  def process_options(self,argv=sys.argv):
    "Parse command line arguments."

    usage = """\
Usage: grid.py [-log2c begin,end,step] [-log2g begin,end,step] [-v fold] 
[-gnuplot pathname] [-out pathname] [-png pathname]
[additional parameters for svm-train] dataset"""

    if len(argv) < 2:
        print(usage)
        sys.exit(1)

    self.datafile = argv[-1]
    self.title = os.path.split(self.datafile)[1]
    self.outfile = '%s.out' % self.title
    self.pngfile = '%s.png' % self.title
    pass_through_options = []

    i = 1
    while i < len(argv) - 1:
        if argv[i] == "-log2c":
            i = i + 1
            self.crange = map(float,split(argv[i],","))
        elif argv[i] == "-log2g":
            i = i + 1
            self.grange = map(float,split(argv[i],","))
        elif argv[i] == "-v":
            i = i + 1
            self.fold = argv[i]
        elif argv[i] == '-gnuplot':
            i = i + 1
            self.gnuplot_exe = argv[i]
        elif argv[i] == '-out':
            i = i + 1
            self.outfile = argv[i]
        elif argv[i] == '-png':
            i = i + 1
            self.pngfile = argv[i]
        else:
            pass_through_options.append(argv[i])
        i = i + 1

    self.xargs = " ".join(pass_through_options)
    #assert os.path.exists(dataset_pathname),"dataset not found"
    if os.path.exists(self.gnuplot_exe):
      self.gnuplot = GnuPlot(self.gnuplot_exe,
            self.crange, self.grange, self.title)
    else:
      # If we do not have gnuplot, simply ignore it.
      self.gnuplot = VoidPlot()

def main():
    # set parameters
    opt = Options()
    opt.process_options()

    y,x = svmutil.svm_read_problem(opt.datafile)
    testset = svm0.svm_problem(y,x)

    (db, (best_c1, best_g1), (best_c, best_g),  best_rate) = \
      gridsearch(testset,opt,opt.gnuplot)

    result_file = open(opt.outfile, 'w')
    for (c,g,r) in db: result_file.write('%s %s %s\n' %(c,g,r))
    result_file.close()

    opt.gnuplot.redraw(db,[best_c1, best_g1, best_rate],opt.pngfile)
    print("%s %s %s" % (best_c, best_g, best_rate))

if __name__ == '__main__': main()
