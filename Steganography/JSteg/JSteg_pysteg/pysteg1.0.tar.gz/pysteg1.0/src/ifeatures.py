#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# Feature Extraction
# ==================
#
#
# This script is used to extract features from a single image file and
# produce a single pickle output file.
#
# ::

docstring = """
:Script:    ifeatures.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    2011: Hans Georg Schaathun <georg@schaathun.net>

ifeatures.py -o outfile -F fv -l label [-v verbosity] infile

  Extract features from the given image infile.  
  The output is a pickled feature vector object written ot
  outfile.

  fv : feature vector type
     Either "RGB", "JPEG", "Gray", "Hugo", or "JAB-EXP".
     "JPEG" for JPEG input and "Gray" for gray-scale, spatial
     domain input have been tested and work satisfactory.
     The others are incomplete or experimental or both.

  label : the classification label
     Normally, this should be 0 for clean images and 1 for a
     steganogram


ifeatures.py -H host [-v verbosity]

  Start a client to do feature extraction, getting the parameters
  from a server running at host.  Use the iserver.py script to
  run the server.
"""

import pysteg.analysis as pa
import pysteg.cliserv.client as client
import optparse 
import os
import numpy as np
import pickle
from PIL import Image

import pysteg.analysis.features as features

from   pysteg.analysis.sfeatures.maskedmarkov import maskedmarkovFeatures
from   pysteg.analysis.hugo  import hugoVector

# Parse options
# -------------
#
#

parser = optparse.OptionParser()
parser.add_option("-p", "--port", 
          help="Port number", dest="port" )
parser.add_option("-o", "--outfile",
          help="Output data file for complete feature vectors in raw format.",
          dest="outfile" )
parser.add_option("-F", "--feature-set", 
          help="Feature vector to extract",
          dest="fvtype" )
parser.add_option("-l", "--label", 
          help="Classification label",
          dest="label" )
parser.add_option("-H", "--server", 
          help="Server from which to get tasks",
          dest="server" )
parser.add_option("-v", "--verbose", 
          help="Verbosity level",
          dest="verbosity" )
(options,args) = parser.parse_args()

# Interpret options
# -----------------

outfile = options.outfile
if outfile == None: outfile = "master.dat"
if options.port != None: options.port = int(options.port)
if options.verbosity != None:
  verbosity = int(options.verbosity)
else: verbosity = 0
if options.label != None: label = int(options.label)
else: label = None
print "[ifeatures] Verbosity", verbosity

fvtl = {
  "RGB"  : features.colVector,
  "JPEG" : features.featureVector,
  "Gray" : features.baseVector,
  "DeepGray" : features.deepVector,
  "Hugo" : hugoVector,
  "JAB-EXP" : maskedmarkovFeatures
}
fvol = [ "JAB-EXP" ]

def mkfeatures( infile, outfile, fvtype, label=None, verbosity=1 ):
  fv = fvtl[fvtype]
  if options.fvtype in fvol: imgload = True
  else: imgload = False
  if imgload: infile = np.array(Image.open(infile))

# Extract features::

  X = fv( infile, label=label, verbosity=verbosity)

# Save file::

  f = open ( outfile, "wb" )
  pickle.dump( X, f, protocol=2 )
  f.close()

# Main Functionality
# ------------------

if options.server == None:
   assert len(args) == 1
   mkfeatures( args[0], outfile, options.fvtype, label, verbosity )
else:
   cont = True
   kw = {}
   if options.port != None: kw["port"] = options.port
   if options.server != None: kw["host"] = options.server
   while cont:
      sock = client.mySocket(verbosity=verbosity,**kw)
      a = client.getTask( sock )
      print a
      if a == False: cont = False
      else: mkfeatures( *a, verbosity=verbosity )
