#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

docstring="""
Draw pixel histograms from spatial domain images

:Script:    imhist.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

from pysteg.imtools import imhist,imhist2d
from PIL import Image
import numpy as np
from pysteg.tools import fnsplit

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-o", "--outfile",
          help="Output filename for the histogram.",
          dest="outfile" )
parser.add_option("-d", "--difference-histogram",
          help="Count differences between adjacent pixels instead of pixel values.",
          dest="diff", action="store_true", default=False )
parser.add_option("-D", "--differences",
          help="Count differences between adjacent pixels instead of pixel values.",
          dest="diffidx" )
parser.add_option("-2", "--2D",
          help="Make a 2D histogram showing two colour channels.",
          dest="colours" )
parser.add_option("-1", "--one-plot",
          help="Plot all the curves in a single figure.",
          dest="oneplot", action="store_true", default=False )
parser.add_option("-c", "--continuous",
          help="Plot a curve instead of a bar chart.",
          dest="cont", action="store_true", default=False )
(options,args) = parser.parse_args()

kw = {}
if options.diffidx:
   try:
      kw["diff"] = eval( options.diffidx )
   except:
      kw["diff"] = options.diffidx 
elif options.diff: kw["diff"] = True
if options.cont: kw["bar"] = False

def main():
  outfile =  options.outfile 
  L = []
  for infile in args:
    if options.outfile == None:
      (d,f,e) = fnsplit( infile )
      outfile = d + f + "-hist.pdf"
    L.append( np.array( Image.open(infile) ) )
    #X = imread( infile ) 
  if options.oneplot: imhist(outfile,L,**kw)
  elif options.colours != None:
     for X in L:
        imhist2d(outfile,X,options.colours,**kw)
  else:
     for X in L: imhist(outfile,X,**kw)

if __name__ == "__main__":
    main()
