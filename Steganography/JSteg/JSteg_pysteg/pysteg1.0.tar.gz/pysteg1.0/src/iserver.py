#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# Feature Extraction
# ==================
#
# ::

docstring = """
:Script:    iserver.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    2011: Hans Georg Schaathun <georg@schaathun.net>

iserver [-p port] -F fv -l label [-v verbosity] -o outdir -i indir 
       [-I infile|-R range] [-e iext] [-E oext]

   Run a server to feed parameters to the ifeatures.py script running
   in client mode.  If neither -I nor -R is given, it will loop 
   through all files in indir, and ask for output to a file in indir.
   File names must have extension iext (default ".pgm.jpg") and
   output files will have extension oext (default ".pgm.dat").

   port : port number
      specify a non-standard port to listen to.

   label : classification label (as for ifeatures.py)

   fv : feature vector type (as for ifeatures.py)

   range : images to process (python expression)
      This may be any python expression giving the base names 
      (without the .pgm.jpg extension) of images to process.
      For instance, this could be "xrange(0,500)".
 
   infile : file specifying images to process
      The file should be a list of base names (without the
      .pgm.jpg extension) of images to process, one file per line.

   Note that the server does not check for crashing clients.  If 
   clients are lost, one should generate a file listing missing
   files and run the server again with the -I option.
"""

import pysteg.cliserv.server as server
import optparse 
import os
from Queue import Queue

# Parse options
# -------------
#
#

parser = optparse.OptionParser()
parser.add_option("-p", "--port", 
          help="Port number", dest="port" )
parser.add_option("-F", "--feature-set", 
          help="Feature vector to extract",
          dest="fvtype" )
parser.add_option("-l", "--label", 
          help="Classification label",
          dest="label" )
parser.add_option("-v", "--verbose", 
          help="Verbosity level",
          dest="verbosity" )
parser.add_option("-o", "--outdir", 
          help="Directory for output files",
          dest="outdir" )
parser.add_option("-i", "--indir", 
          help="Directory for input files",
          dest="indir" )
parser.add_option("-I", "--infile", 
          help="Infile listing image numbers to process",
          dest="infile" )
parser.add_option("-R", "--range", 
          help="Python expression giving image numbers to process",
          dest="range" )
parser.add_option("-e", "--input-ext", 
          help="Filename extension for input",
	  default=".pgm.jpg", dest="iext" )
parser.add_option("-E", "--output-ext", 
          help="Filename extension for output",
	  default=".pgm.dat", dest="oext" )
(options,args) = parser.parse_args()

# Interpret options
# -----------------

if options.port != None: options.port = int(options.port)
if options.verbosity != None:
  verbosity = int(options.verbosity)
else: verbosity = 0
if options.label != None: label = int(options.label)
else: label = None

# Main Functionality
# ------------------

Q = Queue()
if options.infile != None:
   f = open( options.infile, "r" )
elif options.range != None:
   f = eval(options.range)
else:
   f = xrange(10001)
for i in f:
   if hasattr(i,"strip"): i = i.strip()
   jpg = options.indir  + "/" + str(i) + options.iext
   dat = options.outdir + "/" + str(i) + options.oext
   Q.put( ( jpg, dat, options.fvtype, label ) )
if options.infile != None: f.close()

kw = {}
if options.port != None: kw["port"] = options.port

S = server.serverThread(Q,**kw)
S.daemon = False
S.start()
