## $Id$
## -*- coding: utf-8 -*-

"""
Feature Selection using Information Theory.

This library includes the necessary functions to rank features for
machine learning using Mutual Information.  The theory mainly follows
Gavin Brown (2009).

It also includes other ML-related modules and packages, and should
be refactored as an ML package with subpackages including one for
information theory.

:Module:    itml
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml] $Id$"

# =======================
# The :mod:`itml` library
# =======================
#   
# .. automodule:: itml
#
# The functions included directly in the package are simple
# utilities likely to be used in most modules.
#
# ::

import numpy as np

from traceback import print_exc as pexc
import sys

def print_exc(e):
   "Print the exception e with call stack on standard out."
   return pexc(e,file=sys.stdout)

def cmp3(x,y,asc=False):
   """
   Comparison function for tuples, comparing the third element.
   NaN entries are sorted as the smallest element possible,
   and all NaN values are equal.
   """
   if np.isnan(y[2]) and np.isnan(x[2]): return 0
   elif np.isnan(y[2]): return -1
   elif np.isnan(x[2]): return +1
   elif asc: return cmp(x[2],y[2])
   else: return cmp(y[2],x[2])

def hstring(r):
   """
   Convert an (index,key,heuristic) triplet to a string, intended
   for printing.
   """
   (idx,k,h, x) = r
   return "%f\t%i\t%s" % (h,idx,k)

def array2list(C,S):
   C = map(list, list(C.transpose()) )
   S = map(list, list(S.transpose()) )
   return [ [0] + v for v in C ] + [ [1] + v for v in S ] 

def list2array(L):
   g = ( ( e[0], e[1:] ) for e in L )
   C = [ y for (x,y) in g if x == 0 ]
   S = [ y for (x,y) in g if x == 1 ]
   C = np.array( C ).transpose()
   S = np.array( S ).transpose() 
   print "[list2array]", C.shape, S.shape
   return (C,S)

def saveCSV(fn,L):
   """
   Save a feature set L to the given file fn in comma separated format.
   The feature set should be a list of lists where the first element of
   each list is the label.
   """
   f = open( fn, "w" )
   f.writelines( ( ", ".join( map(str,e) ) + "\n" for e in L ) )
   f.close()
def loadCSV(fn):
   """
   Load a feature set the given file in comma separated format.
   The result is a list of lists.  The first element on each line
   should be the class label, and becomes the first element of the
   constituent lists.
   """
   f = open( fn, "r" )
   l1 = ( s.split( "," ) for s in f )
   L = [ [int(e[0])] + map( float, e[1:] ) for e in l1 ]
   f.close()
   return L
def loadSVM(fn):
   f = open( fn, "r" )
   L = [ s.split() for s in f ]
   f.close()
   raise NotImplementedError, "Use comma-separated format"

# The modules and subpackages are organised in three groups (or chapters).
# Core elements include the definitions relating directly to feature
# selection.  The core elements depend on more general definitions to
# estimate probability density functions (KDE) and entropy, and this
# is organised in a separate chapter.  Finally, there are special modules
# to handle client-server parallellisation.
