## $Id$
## -*- coding: utf-8 -*-

"""
Boosting Feature Selection 

This library includes the necessary functions to select features for
machine learning using Boosting Feature Selection (BFS) following
Dong et al. (IWDW 2007).

:Module:    itml.bfs
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.bfs] $Id$"

# ===========================
# The :mod:`itml.bfs` library
# ===========================
#   
# .. automodule:: itml.bfs
#
# .. toctree::
#    :maxdepth: 2
#
#    bfselect.py.txt
#
# ::

