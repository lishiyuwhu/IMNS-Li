## $Id$
## -*- coding: utf-8 -*-

"""
Boosting features selection (BFS)

:Module:    itml.bfs.bfselect
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.bfs.bfselect] $Id$"

# #################
# itml.bfs.bfselect
# #################
#   
# .. automodule:: itml.bfs.bfselect
#
# ::

from .. import *
from ..select import abstractSelect
import numpy as np
#from itertools import imap

# The :class:`bfSelect` class
# ===========================
#
# .. autoclass:: fvSelect
#
# ::

class bfSelect(abstractSelect):
   """
   This class is designed neatly to collect all the intermediate calculations
   required to rank and select features.
   """

   def __init__(self,C,S,T=None, *a, **kw ):

      abstractSelect.__init__(self,C,S,T,*a,**kw)
      self.beta = np.zeros( self.dimension() )
      N = self.size()

# It is a bit uncertain how Dong et al use the weightings.
# Friedman et al. seem not to update an explicit distribution at all,
# so therefor we do not currently use the weights.
# Nevertheless, we define them as recommended in the original AdaBoost
# algorithm.
#
#   ::

      self.weight = np.ones( N ) / N
      print "[bfSelect] Completed construction"

      F = np.isnan(self.T)
      if np.any(F):
        print "[bfSelect] Attention.  NaN values found"
        print np.any(np.any(F,1) != np.all(F,1))
        self.T[F] = 0
        self.C[np.isnan(self.C)] = 0
        self.S[np.isnan(self.S)] = 0
      else:
        print "[bfSelect] OK.  No NaN values"

# The following three methods are used to calculate the individiual terms
# in the squared-error expression which is to be minimised.
#
#   ::

   def _bgamma(self,gamma):
      return self.T[gamma,:]
   def _Fclassify(self):
      return np.dot( self.beta, self.T )
   def _ylabel(self):
      return np.hstack( [ np.ones( self.C.shape[1] ),
                          (-1)*np.ones( self.S.shape[1] ) ] )

# The key method is one to run the minimisation and find beta for a given gamma.
# This involves solving
#
# .. math::
#    \min_\beta o_\gamma(\beta) \quad\text{where}\quad
#    o_\gamma(\beta) = 
#    \sum_i w_i\cdot [ y_i - F_{m-1}(x_i) - \beta\cdot b(x_i;\gamma) ] ^ 2
#
# where :math:`w_i` are the weights, 
# :math:`y_i` are the labels, and :math:`x_i` is the feature vector for 
# the :math:`i`th object.  Differentiating the operand, we get
#
# .. math::
#    o_\gamma' &=
#    - 2\sum_i w_i\cdot [ y_i - F_{m-1}(x_i) - \beta\cdot b(x_i;\gamma) ]
#             b(x_i;\gamma)
#    \\&=
#    - 2\sum_i w_i\cdot [ y_i - F_{m-1}(x_i) ] b(x_i;\gamma)
#    + 2\sum_i w_i\cdot\beta\cdot b(x_i;\gamma)^2
# 
# It is easily seen that the derivative is positive for large values 
# of :math:`\beta` and negative for large negative values.
# Thus the minimum will be found by solving :math:`o'_\gamma = 0`.
# The optimal beta is thus given by
#
# .. math::
#    \beta &=
#    \frac{2\sum_i w_i\cdot [ y_i - F_{m-1}(x_i) ] b(x_i;\gamma)}
#    {2\sum_i w_i\cdot\ b(x_i;\gamma)^2}
#
# The following method returns :math:`\beta` as defined above.
# 
#   ::

   def findBeta(self,gamma):
      y = self._ylabel()
      F = self._Fclassify()
      #wt = self.weight
      wt = 1
      W = y - F
      b = self._bgamma(gamma)
      assert y.shape == F.shape
      assert y.shape == b.shape

      A = sum( wt * W * b )

# When the features are scaled to zero mean and unit variance, 
# b**2 is always 1, being equal to the variance.
#
#   ::

      B = sum( wt * b**2 )
      beta = A/B
      return beta

   def getSE(self,gamma,beta):
      y = self._ylabel()
      L = len(y)
      F = self._Fclassify()
      b = beta*self._bgamma(gamma)
      T = y - F - b
      #wt = self.weight
      wt = 1
      return sum( wt * T**2 ) / L

# Feature Selection 
# -----------------
#
# The following method is an auxiliary used by :meth:`next` to 
# assemble all the information recorded per feature in the object.
#
#   ::

   def _getRankData(self,n,*a,**kw):
      """
      Return a tuple (n,k,h,beta) where n is the feature (:mod:`pysteg`)
      index, k is the feature key (name), h is its heuristic, and beta
      is the weighting :math:`\beta` to be used in the final classifier.
      """
      beta = self.findBeta(n)
      E = self.getSE(n, beta)
      print "[_getRankData] (%s) %s (%s)" % (n,E,beta)
      return ( self.getIndex(n), self._getKey(n), E, beta )

# .. automethod:: bfSelect._storeRank
# 
#   ::

   def _storeRank(self,R):

# The initial steps, storing the selection and selection heuristics 
# follows the abstract class except that we sort in ascending order.
#
#   ::

      self.heuristic.append( [ r[2] for r in R ] )
      R.sort( cmp=lambda x,y : cmp3(x,y,True) )
      S = R[0]
      self.selected.append( S )
      self.ranking.append(R)
      print "[_storeRank]", hstring(R[0])
      assert len( self.selected ) == len( self.heuristic )
      assert len( self.selected ) == len( self.ranking )

# We update the beta attribute by adding the newly selected feature with a
# coefficient of beta as calculated previously by the :math:`_getRankData`
# method.
#
#   ::
      
      idx = S[0] - 1
      beta = S[3]
      self.beta[idx] += beta

def mkSelect(L,**kw):
   if type(L) == str: L = loadCSV(L)
   (C,S) = list2array(L)
   return bfSelect(C,S,**kw)
