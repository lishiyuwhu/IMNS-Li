#! /usr/bin/env python
## -*- coding: utf-8 -*-
## $Id$

"""
Module for client object to help feature selection.

:Module:    itml.cliselect
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.cliselect] $Id$"

# ##############
# itml.cliselect
# ##############
#   
# .. automodule:: itml.cliselect
#
# ::

from . import *
from featureentropy import featureEntropy
import pickle
from mysocket import *

__all__ = [ "run" ]

def run(host=defaultHost,port=defaultPort,verbosity=1):
   print "[run] Starting %s:%i" % (host,port)
   cont = True
   count = 0
   while cont:
      sock = mySocket(host=host,port=port,verbosity=verbosity)
      cont = process(sock)
      count += 1
      print "[run] Completed task", count
   return count

def process( sock ):

# Message 1: we connect and send the hello string.
#
#   ::

   sock.connect()
   sock.send( reqString ) 
   R = True

# Message 2a-b: 
# The reply may be an instruction to terminate, in which case we return
# False.  Otherwise messages 2a is the length of message 2b, which in
# turn is a pickled object.
#
#   ::

   msg = sock.receive( )
   if msg == killString: return False
   elif msg[:2] != okPrefix:
      raise RuntimeError( "Protocol error" )
   else:
      msglen = int(msg[2:])
      msg = sock.receive( msglen )
      try:
        X = pickle.loads(msg)
      except Exception as e:
	 print_exc(e)
	 sock.send( errString )
	 raise e

# Pickled task received.  Calculate the result.

   result = calc(X)

# Message 3a-b: returning the pickled result object.

   submitmsg = pickle.dumps(result)
   sock.send( resLength(len(submitmsg)) )
   sock.send( submitmsg )

# Message 4: receiving acknowledgement and close down

   msg = sock.receive()
   if msg == killString: R = False
   elif msg != ackString:
      raise RuntimeError( "Protocol error" )
   sock.shutdown( socket.SHUT_RDWR )
   sock.close( )
   return R

def calc( task ):
   (n,C,S,T) = task
   (h1,h2) = featureEntropy(C,S,T,verbosity=2)
   return (n,h1,h2)

if __name__ == "__main__":
   run()
