## Id: eval.py 2175 2011-04-04 09:37:02Z georg 
## -*- coding: utf-8 -*-

"""
:Module:    itml.eval
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

This module provides the :class:`fvEval` class which organises a
set of pickled feature vector objects for analysis.  It can load
the pickled objects and convert them into other formats, such as
numpy arrays for use with other modules.  It also provides methods
to make scatter plots and histograms of the features.

This module, together with :mod:`plotting` is totally independent
of the rest of the :mod:`itml` package and should be moved into pysteg.
"""

print "[itml.eval] $Id$"

# #########
# itml.eval
# #########
#   
# .. automodule:: itml.eval
# 
# ::

import pysteg.tools as pt

from . import print_exc

# We use the :mod:`plotting` module.  No other module depends on it,
# so it may be merged into this one.
#
# ::

from .plotting import *

def vloadObject(v): return lambda x : pt.loadObject(x,v)

__all__ = [ "fvEval", "fvScatter" ]

# Additionally we need the :mod:`os` package to list directory contents,
# and the :mod:`numpy.random` module to select random objects.
# 
# ::

import os
import numpy.random as rnd
import numpy as np

# We use matplotlib for plotting.
# 
# ::

import matplotlib.pyplot as plt

# The :class:`fvEval` class
# =========================
# 
# .. autoclass:: fvEval
# 
# ::

class fvEval(object):
   """
   This class is used to hold sets of feature vectors for
   feature evaluation and selection.  It is less general
   than the :class:`testset` class.  Only binary classification
   problems are supported with no class skew.
   """

   def getverbosity(self): return self._verbosity

# Setting up the object
# ---------------------
# 
#   ::

   def is_oneclass(self):
      if hasattr(self,"oneclass"): return self.oneclass
      else: return False
   def __init__(self,cdir,sdir=None,N=None,
	        filelist=None,double=False,complete=True,
		oneclass=False,
		verbosity=None): 

      self.complete = complete
      self.double = double
      self.namelist = None
      self.subnamelist = {}
      self.clist = None
      self.slist = None
      self.ctestlist = None
      self.stestlist = None
      self.oneclass = oneclass
      if sdir == None:
	 assert isinstance(cdir,fvEval)
         self.cdir = cdir.cdir
         self.sdir = cdir.sdir
         self.oneclass = cdir.oneclass
         self.filelist = cdir.filelist
	 if N == None: self.trainsize = cdir.trainsize
	 else: self.trainsize = N
	 if verbosity == None: self._verbosity = cdir._verbosity
	 else: self._verbosity = verbosity

# First, set up the source directories and the list of images.
# To randomise the sample, the image list is shuffled.
# 
#      ::

      else: 
        self.cdir = cdir
        self.sdir = sdir
	if filelist == None: filelist = os.listdir(cdir)
        self.filelist = list(rnd.permutation(filelist))
        self.trainsize = N
	if self.complete: self.sfilelist = None
	else: self.sfilelist = list(rnd.permutation(os.listdir(sdir)))
	if N == None: self.trainsize = 500
	else: self.trainsize = N
	if verbosity == None: self._verbosity = 2
	else: self._verbosity = verbosity
  
# For the evaluation, we take N objects each from clean and from
# the stego collection.  The remaining images are retaining for 
# testing.  These object lists are calculated on the fly by the 
# following methods.
# 
#   ::

   def cfiles(self):
      N = self.trainsize
      if not self.complete:
         return [ self.cdir + "/" + f for f in self.filelist[:N] ]
      elif self.double:
         return [ self.cdir + "/" + f for f in self.filelist[:(2*N)] ]
      else:
         return [ self.cdir + "/" + f for f in self.filelist[:N] ]
   def sfiles(self):
      N = self.trainsize
      if self.is_oneclass(): return []
      elif not self.complete:
         return [ self.sdir + "/" + f for f in self.sfilelist[:N] ]
      elif self.double:
         return [ self.sdir + "/" + f for f in self.filelist[:(2*N)] ]
      else:
         return [ self.sdir + "/" + f for f in self.filelist[N:(2*N)] ]
   def ctest(self):
      if self.complete:
        n1 = 2*self.trainsize
        n2 = len(self.filelist)/2 + self.trainsize
        return [ self.cdir + "/" + f for f in self.filelist[n1:n2] ]
      else: return [ self.cdir + "/" + f for f in self.filelist[self.trainsize:] ]
   def stest(self):
      if self.complete:
        n2 = len(self.filelist)/2 + self.trainsize
        return [ self.sdir + "/" + f for f in self.filelist[n2:] ]
      else: return [ self.sdir + "/" + f for f in self.sfilelist[self.trainsize:] ]

# .. automethod:: fvEval.load
# 
# ::

   def load(self):
     "Load the features from the files selected in the constructor."
     if self.clist == None:
        self.clist = map( vloadObject(self._verbosity), self.cfiles() )
     self.namelist = self.clist[0].getNames()
     if self.slist == None:
        self.slist = map( vloadObject(self._verbosity), self.sfiles() )
   
   def _getGen(self,S,id=None):
      """
      Return an iterator over the objects returning feature vector node
      objects.  The parameter S spesifies "s" for stego or "c" for clean.
      This is a helper function for :meth:`getCover` and :meth:`getStego`.
      """
      if self.__getattribute__( S + "list" ) == None:
	 for f in self.__getattribute__( S + "files" )(): 
	    X = pt.loadObject(f,self._verbosity)
	    if self.namelist == None: self.namelist = X.getNames()

# If id is specified, we will extract subnodes from X to return
# a list.  We will also make sure that the key lists are stored.
# If the keys were not previously stored, we check that all the
# subnodes have the same keys.

	    if id != None:
	      X = [ X.getNode(i) for i in id ]
	      if not self.subnamelist.has_key( id[0] ):
		  tmp = X[0].getNames(True)
		  for x in X:
		     assert x.getNames(True) == tmp
		  for x in id: self.subnamelist[x] = tmp

# We can now be satisfied with the result and yield X.

	    yield X

# If the feature vectors have been preloaded, we get them from the
# clist/slist attributes.

      else:
	 assert id == None, \
	     "Getting subvector nodes is not supported with preloaded features"
	 print "[getCover] preloaded feature vectors"
	 for X in self.__getattribute__( S + "list" ):
	    if id != None: X = [ X.getNode(i) for i in id ]
	    yield X

   def getCover(self,*a,**kw): return self._getGen("c",*a,**kw)
   def getStego(self,*a,**kw): return self._getGen("s",*a,**kw)
   def testCover(self):
      if self.ctestlist == None:
	 for f in self.ctest(): yield pt.loadObject(f,self._verbosity)
      else:
	 for f in self.ctestlist: yield f
   def testStego(self):
      if self.stestlist == None:
	 for f in self.stest(): yield pt.loadObject(f,self._verbosity)
      else:
	 for f in self.stestlist: yield f

# Accessing feature vectors
# -------------------------
# 
#   ::
  
   def getData(self,id=None):
      """
      Return the feature vectors for the training set as two lists of lists.
      """
      return ( [ s.vector(id) for s in self.getCover() ],
               [ s.vector(id) for s in self.getStego() ] )
   def getArrays(self,id=None,transpose=True):
      """
      Return the feature vectors for the training set as two matrices.
      """
      (C,S) = self.getData(id)
      (C,S) = ( np.array(C), np.array(S) )
      if transpose: return ( C.transpose(), S.transpose() )
      else: return ( C, S )
   def getDataSets(self,id=None):
     """
     Return the training and test sets as two pairs of lists of feature
     vector lists.  The third element of the return tuple is the id 
     specified as an argument.
     """
     return ((self.getCover(),self.getStego()),
	     (self.testCover(),self.testStego()),id)

# .. automethod:: fvEval._getArrays
# 
# ::

   def _getArrays(self,scale=False):
     """
     Auxiliary method to create the three arrays of features
     needed to compute heuristics.
     """
     if scale: (C,S) = self.scaleArrays()
     else: (C,S) = self.getArrays()
     T = np.hstack([C,S])
     if self._verbosity > 3:
        print "[_getArrays]", C.shape, S.shape, T.shape
     return (C,S,T)

# Scaling
# -------
# 
# When the range of observations is narrow, we tend to get negative
# entropy.  It is also known that differential entropy is not invariant
# under continuous transformations.  The implication of this has not been
# analysed.  Scaling should offer a way to get entropies in a common
# range, but the effect on mutual information is not known.
# 
#   ::

   def scaleArrays(self):
      """
      Return arrays of scaled features as required for the heuristics
      calculation.
      """

# Collect the arrays.  We do not transpose to make it easier to
# do element-wise operations with vectors.
# 
#      ::

      (C,S) = self.getArrays(transpose=False)

# We are interested in the standard deviation and minimum across
# both classes, so we form the matrix T which we analyse.
# 
#      ::

      T = np.vstack( (C,S) )
      sigma = np.sqrt( np.var(T, axis=0 ) )
      sigma[sigma==0] = 1
      basept = np.mean(T, axis=0 )

# Debug info is included at this stage.
# 
#      ::

      if self._verbosity > 1:
        print len(sigma), len(basept), T.shape, C.shape, S.shape

# We divide by the standard deviation and subtract the mean,
# to get features with unit variance and zero mean.
# 
#      ::

      C -= basept
      S -= basept
      C /= sigma
      S /= sigma

# We need to transpose the matrices before we return, to be compatible
# with the gaussian KDE class.
# 
#      ::

      return ( C.transpose(), S.transpose() )


# Accessing metadata
# ------------------
# 
#   ::

   def listFeatures(self): return self.clist[0].listFeatures()
   def listnames(self): return self.clist[0].listnames()
   def iterNames(self): return self.clist[0].iterNames()

# Plotting
# --------
# 
# .. automethod:: fvEval.hist
# 
# ::
  
   def hist(self,idx,fn,scale=True,*a,**kw):
      if scale: (C,S) = self.scaleArrays()
      else: (C,S) = self.getArrays()

      if idx == None:
         (dim,N) = C.shape
         print "[hist] (dim,N) =", C.shape
         L = range(dim)
      elif hasattr(idx,"__iter__"):
         L = [ i - 1 for i in idx ]
      else: 
         L = None
         f = idx - 1
         if self._verbosity > 1: print "[hist]", type(idx), idx
         hist( C[f,:], S[f,:], fn, *a, **kw )

      if L != None:
         assert os.path.isdir(fn), \
               "When making multiple plots, a directory name must be given" 
         for f in L:
           fname = fn + "/hist" + str(f+1) + ".pdf"
           try:
             hist( C[f,:], S[f,:], fname, *a, **kw )
           except Exception as e:
             print_exc( e )
             print "[hist] Exception.  No plot generated.", fname

# .. automethod:: fvEval.ccscatter
#
# ::

   def ccscatter(self,id1,id2,fn="."):
      C = [ (X.vector(),Y.vector()) for (X,Y) in self.getCover([id1,id2]) ]
      S = [ (X.vector(),Y.vector()) for (X,Y) in self.getStego([id1,id2]) ]
      N = dimF(C)
      names = self.subnamelist[id1]
      if self._verbosity > 1:
         print "[ccscatter] id1", id1
         print "[ccscatter] id2", id2
         print "[ccscatter] Dimension", N
      f = []
      for i in xrange(N):
         f.append( plt.figure() )
         plt.hold( True )
	 (x,y) = getF(C,i)
         plt.scatter( x, y, s=1, c="r", linewidths=(0,), label="Cover" )
	 (x,y) = getF(S,i)
         plt.scatter( x, y, s=1, c="b", linewidths=(0,), label="Stego" )
         d0 = np.hstack([x,y])
         di = [ np.min(d0), np.max(d0) ]
         plt.plot( di, di, "y-" )
	 plt.title( str(i+1) + " " + str( names[i] ) )
	 plt.legend( loc="lower right" )
         fname = fn + "/cc" + str(i+1) + ".pdf"
         plt.savefig( fname )
         if self._verbosity > 1:
             print "[ccscatter]", fname
      return f

# .. automethod:: fvEval.scatterplot
#
# ::

   def scatterplot(self,fn,idx=None,id=None):
      """
      Make a scater plot of the distribution of a given feature for
      pairs of a clean image and and corresponding steganogram.
      """
      assert self.double
      (C,S) = self.getArrays(id,transpose=False)
      assert C.shape == S.shape
      if self._verbosity > 2:
         print "[scatterplot] array shape is", C.shape

      scatterarg = { "c" : "b", "s" : 1, "linewidths" : (0,) }

# The :param idx: parameter may be None or a list, to create
# multiple plots in one go.  The following hooks interpret these
# options.
# 
#   ::

      if idx == None:
         (N,dim) = C.shape
         L = range(dim)
      elif hasattr(idx,"__iter__"):
         L = [ i - 1 for i in idx ]

# If :param idx: is neither None, nor a list, it should be an integer index,
# and we make a plot for this image.  L is set to None to indicate that no
# list of indices should be processed.
# 
#   ::

      else: 
         L = None
         i = idx - 1
         if self._verbosity > 1:
           print "[scatterplot]", type(idx), idx
         x = C[:,i]
         y = S[:,i]
         f = plt.figure()
         plt.scatter( x, y, **scatterarg )
         plt.hold( True )
	 plt.xlabel( "Clean" )
	 plt.ylabel( "Stego" )
	 plt.title( str(idx) + " " + str( self.namelist[i] ) )
         plt.plot( x, x, "y-" )
         plt.savefig(fn)

# If L is now not None, it should be a list of indices to process.
# In this case :param fn: has to be a directory name, and the 
# filenames will be autogenerated based on the index.
# 
#   ::

      if L != None:
         assert os.path.isdir(fn), \
               "When making multiple plots, a directory name must be given" 
         f = []
         for i in L:
           (x,y) = (C[:,i], S[:,i])
           f.append( plt.figure() )
           plt.scatter( x, y, **scatterarg )
           plt.hold( True )
	   plt.xlabel( "Clean" )
	   plt.ylabel( "Stego" )
           d0 = np.hstack([x,y])
           di = [ np.min(d0), np.max(d0) ]
           plt.plot( di, di, "y-" )
	   plt.title( str(i+1) + " " + str( self.namelist[i] ) )
           fname = fn + "/scatter" + str(i+1) + ".pdf"
           plt.savefig( fname )
           if self._verbosity > 1:
              print "[scatterplot]", fname

# Finally, we generate some debug info and return a figure handler.
# 
#   ::

      if self._verbosity > 1:
         print "[scatterplot] done"
      return f

# File IO
# -------
#
#   ::

   def testCoverVectors(self,id=None):
      for v in self.testCover(): yield v.getVector(id) 
   def testStegoVectors(self,id=None):
      for v in self.testStego(): yield v.getVector(id) 
   def testVectors(self,id=None):
      for v in self.testCover(): yield v.getVector(id) 
      for v in self.testStego(): yield v.getVector(id) 
   def iterVectors(self,id=None):
      for v in self.getCover(): yield v.getVector(id) 
      for v in self.getStego(): yield v.getVector(id) 
   def getVectors(self,id=None):
      return list(iterVectors(id))
   def printCSV(self,fn,id=None):
      return saveCSV( fn, self.getVectors(id) )

# The :class:`fvScatter` class
# ============================
# 
# .. autoclass:: fvScatter
# 
# ::

class fvScatter(fvEval):
   """
   The :class:`fvScatter` class was introduced to support plotting of 
   scatter plots comparing steganograms and clean images with respect
   to a single feature.  It is no longer required, as one can simply 
   use the :class:`fvEval` class with double set to True.
   """

# The important difference between the constructors of :class:`fvEval` and
# :class:`fvScatter` is that the latter will always have double equal True,
# to use both a clean and a stego version of each image.
# We do also load the images immediately, to be done with it.
# 
#   ::

   def __init__(self,*a,**kw):
      fvEval.__init__(self,*a,**kw)
      self.double = True
      self.load()

# Auxiliary functions
# ===================
# 
# ::

def dimF(L):
   return len(L[0][0])
def getF(L,idx):
   X = [ x[idx] for (x,y) in L ]
   Y = [ y[idx] for (x,y) in L ]
   return (X,Y)
