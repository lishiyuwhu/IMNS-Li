## Id: eval.py 2175 2011-04-04 09:37:02Z georg 
## -*- coding: utf-8 -*-

"""
This module defines an auxiliary function for the :class:`fvSelect`
class.  It uses a minimum of dependencies to be useable in a client
script for parallel computation.

:Module:    itml.featureentropy
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.featureentropy] $Id$"

# itml.featureentropy
# ###################
#   
# .. automodule:: itml.featureentropy
#
# .. autofunction:: featureEntropy
#
# ::

from . import *
from .kdetools import xkde 
import numpy as np

def featureEntropy(C,S,T,exclude=None,independent=False,verbosity=3):
   """
   Return a pair :math:`( H(X), H(X|Y) )` where :math:`X` is
   the features and :math:`Y` is the class label, where the 
   features of the two classes are C and S respectively.
   The third argument, T, is the features of the union of
   the class.  It is assumed that there is no class skew.
   """

# We create a KDE object for the complete set, excluding outliers if
# required.  
#
#   ::
   
   print "[featureEntropy]", C.shape, S.shape, T.shape
   try:
     K = xkde(T,exclude=exclude)
   except Exception as e:
     print "[featureEntropy] Exception (kde(T))!  Returning NaN"
     print_exc( e )
     return (np.NaN,np.NaN)

# If the entropies for the class sets should be calculated independently,
# we do it as for T above.  Otherwise, we get the bandwidth matrix from
# K and use that.
#
#   ::

   try:
     if independent:
       KC = xkde(C,exclude=exclude)
       KS = xkde(S,exclude=exclude)
     else:
       H = K.getBandwidth()
       KC = xkde(C,bandwidth=H)
       KS = xkde(S,bandwidth=H)
   except Exception as e:
     print "[featureEntropy] Exception!  Returning NaN"
     print_exc( e )
     return (np.NaN,np.NaN)

# Now we can the mutual information using the entropy methods from the
# three KDE objects.
#
#   ::

   (h0,h1,h2) = (K.contEntropy(verbosity=verbosity),
	 KC.contEntropy(verbosity=verbosity),
	 KS.contEntropy(verbosity=verbosity) )
   print "[featureEntropy]", (h0,h1,h2)
   if len(C.shape) > 1:
     (n1,n2) = (C.shape[1], S.shape[1])
   else:
     (n1,n2) = (C.shape[0], S.shape[0])
   return ( h0, ( n1*h1 + n2*h2 ) / (n1+n2) )
