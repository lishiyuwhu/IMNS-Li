## $Id$
## -*- coding: utf-8 -*-

"""
Define additional tools for kernel density estimation, including
methods to estimate the entropy.

:Module:    itml.kdetools
:Author:    Hans Georg Schaathun
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.kdetools] $Id$"

# #######################
# KDE Additions and Tools
# #######################
# 
# .. automodule:: itml.kdetools
# 
# ::

import numpy as np
from .kde import gaussian_kde as gkde

# The main class
# ==============
#
# ::

class xkde(gkde):
   """
   Representation of a kernel-density estimate using Gaussian kernels,
   including methods to estimate entropy.
   """

# The constructor is completely overridden because other methods have
# changed their signatures.
#
#   ::
 
   def __init__(self,dataset,exclude=None,factor="scotts",bandwidth=None,
	 verbosity=2):

      self._verbosity = verbosity

# Firstly, store the dataset and its shape as in the :class:`gkde`
# constructor.  We use self.nprime to count the number of points
# used in the bandwidth calculation.
# 
#   ::

      self.dataset = np.atleast_2d(dataset)
      self.d, self.n = self.dataset.shape
      self.nprime = self.n

# Then we set the bandwidth using the relevant input arguments.
#
#   ::

      self.setBandwidthFactor( factor, recalculate=False )
      if bandwidth != None: self.setBandwidth( bandwidth=bandwidth )
      else: self.setBandwidth( exclude )


# We override :meth:`covariance_factor` because we do not use the
# full sample in the bandwidth calculation.  Therefore we use self.nprime
# in lieu of self.n.
#
#   ::

   def covariance_factor(self):
       """
       Calculate the scaling factor for the bandwidth matrix.
       This is intended for internal use only.
       """
       if callable(self._bwfactor): return self._bwfactor(self.nprime,self.d)
       else: return self._bwfactor

# Overriding the :meth:`setBandwidth` method is essential.  The new 
# bandwidth calculation is the main feature of the derived class.
#
#   ::

   def setBandwidth(self,exclude=None,*a,**kw):
      """Computes the covariance matrix for each Gaussian kernel using
      covariance_factor
      """

# If exclude is not given, we revert to the method of the parent class.
# We reset self.nprime just in case we are recalculating the bandwidth
# after having used a different bandwidth.
#
#   ::

      if exclude == None:
	 self.nprime = self.n
	 return gkde.setBandwidth(self,*a,**kw)

# Calculate the variance for each feature, and build the boolean
# matrix B indicating entries which at most equal to exclude times
# the standard deviation.  Squaring the data is faster, and thus
# preferred over calculating the standard deviation.
#
#   ::

      sigma2 = np.var( self.dataset, axis=1 )
      mu = np.mean( self.dataset, axis=1 )
      D = (self.dataset - mu) ** 2
      S = np.repeat(sigma2[:,np.newaxis],self.n,axis=1)
      B = ( D <= exclude * S )

# Now, we get the indices of all the data points with no feature
# exceeding exclude times the standard deviation, and include
# these points only when we calculate the covariance.
#
#   ::

      idx = [ i for i in xrange(self.n) if B[:,i].all() ]
      if self._verbosity > 0:
	 print "[setBandwidth] Excluding:", self.n - len(idx), \
	       (np.min(self.dataset,axis=1),
	        np.max(self.dataset,axis=1) ), self.covariance_factor()
      self.nprime = len(idx)
      cov = np.atleast_2d( np.cov(self.dataset[:,idx], rowvar=1, bias=False) )

# Check for NaN entries.  This should not happen, but in case it does,
# we provide verbose debug information.
#
#   ::

      if np.isnan(cov).any():
	 print "[setBandwidth] Covariance matrix contains NaN entries."
	 print "Original Covariance Matrix:", sigma2
	 print "Dataset:", self.nprime
	 print "Covariance Matrix with Exclusions:", cov
	 raise Exception, "Covariance matrix contains NaN entries."

# Now, we can use the parent class, feeding it the covariance matrix
# we have calculated.
#
#   ::

      gkde.setBandwidth(self,covariance=cov)

# Entropy Estimation
# ------------------
#
# There are several different formulæ for estimating entropy.
# Each of them is based on having an estimate of the PDF first, 
# for instance in the form of a kernel density estimate.
# 
# An intuitive estimate of the entropy 2 is to substitute the estimated density
# for the theoretical density in the formula for entropy. However, this
# is not quite the favoured method in the literature.
#
# A very simple estimate to calculate is that of Ahmad and Lin,
# which we implement below.
# Contrary to other methods, it requires no integration, and thus
# it avoids the challenge of finding the optimal way of numerical 
# integration for the given dimensionality and sample size.
# We implement it as follows.
#
# ::

   def ahmadlin(self,verbosity=0):
     """
     Estimate the entropy using the formula of Ahmad and Lin.
     """

# First we evaluate the estimated PDF at all the sample points.
#
#    ::

     y = self.evaluate(np.atleast_2d(self.dataset))
     if verbosity > 2:
       print "[ahmadlin]", len(y), np.var(self.dataset), np.max(y), np.min(y)

# Then we take the logarithm of all the evaluations and add up to
# get the estimated entropy r.
#
#   ::

     return - np.sum(np.log(y)) / self.n

   contEntropy = ahmadlin

# Functions
# =========
#
# ::

def contEntropy(X,*a,**kw):
   """
   Estimate the entropy of a probability distribution based on the given
   sample X.
   """
   return xkde(X,*a,**kw).contEntropy()

