#! /usr/bin/env python
## -*- coding: utf-8 -*-
## $Id$

"""
Sample implementation of K-means clustering.

:Module:    itml
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

import numpy as np
import numpy.random as rnd

print "[kmeans] $Id$"

def kmeans(X,K=2,eps=0.1):
   (N,m) = X.shape
   M = rnd.randn(K,m)
   while True:
      L = [ np.sum( (X - M[[i],:])**2, axis=1 ) for i in xrange(K) ]
      A = np.vstack( L )
      C = np.argmin( A, axis=0 )
      L = [ np.mean( X[(C==i),:], axis=0 ) for i in xrange(K) ]
      M1 = np.vstack(L)
      if np.sum((M-M1)**2) < eps: return (C,M1)
      else: M = M1
   raise Exception, "This line should be unreachable"

def getrnd(n,mean,var=1):
   N = len(mean)
   return rnd.randn(n,N) * var + mean

shapelist = [ "v", "o", "d", "8" ]
collist   = [ "r", "b", "g", "k" ]

def test():
   S = 30
   xl = [ np.array(x) for x in [ [ 3, 0 ], [ 0, 2 ], [ 0, 0 ] ] ]
   L  = [ getrnd( S, x, var=1 ) for x in xl ]
   X  = np.vstack( L )
   (C,M) = kmeans( X, 3 )
   plt.figure( figsize=(4,3) )
   for pc in range(3):
      for tc in range(3):
         idx = [ i for i in xrange(tc*S,(tc+1)*S) if C[i] == pc ]
	 y1, y2 = X[idx,0], X[idx,1]
         assert len(y1) == len(y2)
         if len(y1) > 0:
	   plt.scatter ( y1, y2, c=collist[tc], marker=shapelist[pc] )
   plt.savefig( "kmeans-test.pdf" )
	
def test2():
   collist   = [ "w", "k" ]
   shapelist = [ "s", "o" ]
   S = 45
   X1 = np.vstack( [ rnd.randn(S)*2, rnd.randn(S)/3-1.4 ] )
   X2 = np.vstack( [ rnd.randn(S)*2.5, rnd.randn(S)/2+1.4 ] )
   X  = np.vstack( [ X1.transpose(), X2.transpose() ] )
   print np.mean(X,axis=0), np.var(X,axis=0)
   (C,M) = kmeans( X, 2 )
   plt.figure( figsize=(4,3) )
   for pc in range(2):
      for tc in range(2):
         idx = [ i for i in xrange(tc*S,(tc+1)*S) if C[i] == pc ]
	 y1, y2 = X[idx,0], X[idx,1]
         assert len(y1) == len(y2)
         if len(y1) > 0:
	   plt.scatter ( y1, y2, c=collist[pc], marker=shapelist[tc] )
   plt.savefig( "kmeans-test2.pdf" )
	
if __name__ == "__main__":
   import matplotlib
   matplotlib.use( "Cairo" )
   import matplotlib.pyplot as plt
   plt.rcParams["font.size"] = 8
   test()
   test2()
