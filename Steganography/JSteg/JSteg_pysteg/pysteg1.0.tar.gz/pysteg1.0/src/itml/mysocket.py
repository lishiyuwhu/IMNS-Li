## $Id$
## -*- coding: utf-8 -*-

"""
A simple socket class to make send/receive a little bit easier.

:Module:    itml.mysocket
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.mysocket] $Id$"

# #############
# itml.mysocket
# #############
#   
# .. automodule:: itml.mysocket
#
# ::

import socket

# Defaults::

defaultPort=8910
defaultHost="hawker05"

# Constants::

MSGLEN     = 16
okPrefix   = "OK"
dummy      = "1234567890ABCDEF"
resAccept  = "ACCEPT RESULT >>"
reqString  = "REQUEST v0.1 >>>"
killString = "TERMINATE >>>>>>"
errString  = "ERROR >>>>>>>>>>"
ackString  = "ACK        CLOSE"
def okString(msglen):
   R = "OK%14i" % (msglen,)
   return R
def resLength(msglen):
   R = "RS%14i" % (msglen,)
   return R
# .. autoclss:: mySocket

class mySocket(object):
    """
    Class to handle a client socket, with some utility functions
    to handle send and receive.
    """

    def __init__(self, sock=None, host=defaultHost, port=defaultPort,
	         verbosity=2):
       if sock == None:
          self.sock = socket.socket( socket.AF_INET, socket.SOCK_STREAM)
       else: self.sock = sock
       self.host = host
       self.port = port
       self._verbosity = verbosity

    def close(self,*a,**kw): self.sock.close(*a,**kw)
    def shutdown(self,*a,**kw):
       try:
         R = self.sock.shutdown(*a,**kw)
       except Exception:
	  print "[shutdown] connection already terminated"
	  return None
       else:
	  print "[shutdown] connection shut down"
          return R
    def connect(self, host=None, port=None ):
       if host == None: host = self.host
       if port == None: port = self.port
       self.sock.connect((host, port))

    def send( self, msg ):
        totalsent = 0
	msglen = len(msg) 
	if self._verbosity > 0:
	   if msglen < 72: print "[send]", msg
	   else: print "[send] msglen =", msglen
        while totalsent < msglen:
	    sent = self.sock.send(msg[totalsent:])
            if sent == 0: raise RuntimeError("socket connection broken")
            totalsent += sent

    def receive( self, msglen=MSGLEN ):
        msg = ""
        while len(msg) < msglen:
	    chunk = self.sock.recv(msglen-len(msg))
	    if chunk == "": raise RuntimeError("socket connection broken")
	    if self._verbosity > 3:
	      if len(chunk) < 50:
	         print "[receive] received chunk: %s (of %i)" % (chunk,msglen)
	      else:
	         print "[receive] received chunk of length %i of %i" % (
		    len(chunk), msglen )
            msg = msg + chunk
	if self._verbosity > 0:
	  if msglen < 70: print "[receive]", msg
	  else: print "[receive] msglen =", msglen
        return msg
