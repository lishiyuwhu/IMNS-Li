## Id: eval.py 2175 2011-04-04 09:37:02Z georg 
## -*- coding: utf-8 -*-

"""
Plotting functions for features.

:Module:    itml.plotting
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.plotting] $Id$"

# #############
# itml.plotting
# #############
#   
# .. automodule:: itml.plotting
# 
# ::

from .kdetools import xkde 
from . import *
import numpy as np
import matplotlib.pyplot as plt

# These functions contain much of the essential functionality for 
# corresponding wrapper methods in the :class:`fvEval` class.
#
# .. autofunction:: hist
#
# :func:`hist`
# ------------
#
# ::

def hist(A,B,fn,bins=20,exclude=None,independent=False):
   print "[hist]", exclude, independent
   C = np.hstack((A,B))

# Firstly, we calculate the histogram, using the :mod:`numpy`
# functions.  We are not fully satisfied with the bin size
# calculation, but it works ok if the features have been scaled
# to unit variance and zero mean.
#
#   ::

   ## mu = np.mean(C)
   ## s = np.sqrt(np.var(C))
   ## binwidth = s / 8
   mu = 0
   binwidth = 0.05
   b = np.array( range(-50,51) )* binwidth + mu
   h1, b0 = np.histogram(A, bins=b )
   h2, b0 = np.histogram(B, bins=b )
   width = 0.40*(b[1]-b[0])
   print "[hist]", A.shape, B.shape, C.shape

# Secondly, we estimate the PDF-s, and evaluate the estimate
# on a suitable collection of x values.
# We use x points at the bin boundaries and the bin centres.
#
#   ::

   x = np.array( range(-175,176) )* binwidth/3 + mu
   ex = None
   try:
     fC = xkde(C,exclude)
     yC = fC(x)

# If independent KDE-s are asked for, we run the KDE for A and B
# as we did for C.  Otherwise, we get the bandwidth matrix created
# for C and reuse it for A and B.
#
#   ::

     if independent:
        yA = xkde(A,exclude=exclude)(x)
        yB = xkde(B,exclude=exclude)(x)
     else:
        H = fC.getBandwidth()
        yA = xkde(A,bandwidth=H)(x)
        yB = xkde(B,bandwidth=H)(x)

# Any exception is caught and printed.
# It will be reraised later, after printing the diagnostics.
#
#   ::

   except Exception as e:
     print_exc( e )
     print A, B, C
     print "[hist] Exception.  Could not estimate PDF."
     ex = e
   else:

# Then, we can start plotting:
#
#   ::

     fig = plt.figure()
     ax = fig.add_subplot(111)

# We use bar plots for the histogram:
#
#   ::

     p1 = ax.bar( b[:-1], h1, width, color='r' )
     p2 = ax.bar( b[:-1]+width, h2, width, color='b' )

# We scale the PDF to fit into the same scale as the histogram.
# We should add appropriate yticks on the right when we figure out how.
#
#  ::

     hmax = max( np.max(h1), np.max(h2) )
     ymax = np.max(yC)
     cfactor = hmax / ymax

# The regular plot() function gives the estimated PDF curves.
#
#   ::
  
     f0 = ax.plot( x, cfactor * yC, "g-" ) 
     ax.plot( x, cfactor * yA, "r-" ) 
     ax.plot( x, cfactor * yB, "b-" ) 

# We use x ticks from the histogram bins, and a legend:
#
#   ::

     ax.set_xticks(b[::8]) 
     ax.set_xticklabels(b[::8]) 
     ax.legend( (p1[0],p2[0],f0[0]), ("Clean", "Stego","Total") ) 

# We save the figure to the given file:
#
#   ::

     fig.savefig(fn)

# Finally, we need heavy diagnostic output for debugging::

   print (h1,h2,b)
   print "Clean (%i) mu = %f, sigma = %f" % (
         len(A), np.mean(A), np.sqrt(np.var(A)))
   print "Stego (%i) mu = %f, sigma = %f" % (
         len(B), np.mean(B), np.sqrt(np.var(B)))
   print "All (%i) mu = %f, sigma = %f" % (
         len(C), np.mean(C), np.sqrt(np.var(C)))
   l1 = len([ i for i in list(C) if i > 4*np.sqrt(np.var(C)) ])
   l2 = len([ i for i in list(C) if i < - 4*np.sqrt(np.var(C)) ])
   (m1,m2) = (max(C), min(C))
   print "[hist] %s.  %i (%f) %i (%f)" % (fn, l1, m1, l2, m2 )

# We reraise any exception after the general diagnostics have been
# printed::

   if ex != None: raise ex
   return (h1,h2,b)
