## $Id$
## -*- coding: utf-8 -*-

"""
Features selection using Information Theory.

:Module:    itml.select
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.select] $Id$"

# ###########
# itml.select
# ###########
#   
# .. automodule:: itml.select
#
# ::

from . import *
import numpy as np
from itertools import imap
from featureentropy import featureEntropy

# Abstract Class
# ==============
#
# ::

class abstractSelect(object):

   def __init__(self,C,S,T=None, names=None, verbosity=2, *a,**kw):

# The verbosity parameter decide how much debug information will be
# printed.
#
#   ::

      self._verbosity = verbosity

# Then we have all the matrices of features.
# If T is not specified, it can be calculated from C and S:
#
#   ::

      self.S = S
      self.C = C
      self.dim = S.shape[0]
      assert self.dim == C.shape[0], \
         "Input matrices must have the same dimensionality" 
      if T == None: self.T = np.hstack([C,S])
      else: self.T = T
      self.names = names

# We start with an empty set of selected features.
#
#   ::

      self.selected = []
      self.ranking = []
      self.heuristic = []

# Simple Accessor Methods
# -----------------------
   
   def dimension(self):
      "Return the dimensionality of the feature space."
      return self.dim
   def size(self):
      "Return the sample size."
      return self.T.shape[1]
   def __len__(self):
      "Return the number of currently selected features."
      return len(self.selected)

# Current Selection
# ^^^^^^^^^^^^^^^^^
#
# Observe that methods for internal use, starting with an underscore,
# use :mod:`numpy` indexing while the public methods use :mod:`pysteg`
# indexing.
# 
#   ::

   def getSelected(self):
      "Return the :mod:`pysteg` indices of the currently selected features."
      return [ r[0] for r in self.selected ]
   def _getSelectedIndices(self):
      "Return the :mod:`numpy` indices of the currently selected features."
      return [ r[0] - 1 for r in self.selected ]
   def _lastSelected(self):
      "Return the index of the last selected features."
      print "[_lastSelected]", len(self.selected)
      return self.selected[-1][0] - 1

   def getSelectedKeys(self):
      "Return the keys of the currently selected features."
      return [ r[1] for r in self.selected ]
   def getSelection(self):
      "Return the statistics of the currently selected features."
      return self.selected 


# Keys and Indexing
# ^^^^^^^^^^^^^^^^^
#
#   ::

   def _getKey(self,i):
      "Return the key of the i-th feature (:mod:`numpy` indexing)."
      if self.names == None: return i
      else: return self.names[i]
   def getIndex(self,i):
      "Return the :mod:`pysteg` index of the i-th feature."
      return i+1


# Feature Selection 
# -----------------
#
# .. automethod:: fvSelect.next
# 
# ::

   def next(self,*a,**kw):
      """
      Find a new feature to add to the selection.
      The statistics of the new feature is returned.
      This is an external method, using :mod:`pysteg` indices.
      """

# We generate the list of heuristics with respect to the existing 
# selection and store it using the auxiliary method.
#
#   ::

      R = map( self._getRankData, xrange(self.dimension()) )
      self._storeRank( R )
      return R[0]

#
# .. automethod:: fvSelect._storeRank
# 
#   ::

   def _storeRank(self,R):

# We keep three attributes of selection data.  The heuristic
# attribute keeps the heuristics in a list for lookup by feature
# index.  The selected attribute includes the data for the one
# feature selected.  Finally, the ranking attribute containes
# all the features sorted by heuristic.
#
#   ::

      self.heuristic.append( [ r[2] for r in R ] )
      R.sort( cmp=cmp3 )
      self.selected.append( R[0] )
      self.ranking.append(R)
      print "[_storeRank]", hstring(R[0])
      assert len( self.selected ) == len( self.heuristic )
      assert len( self.selected ) == len( self.ranking )


# .. automethod:: abstractSelect.select
# 
# ::

   def select(self,N=50):
      """
      Return a list of :param N: selected features based on 
      Information Theoretic measures.  This quite simply calls
      :meth:`next` N times.
      """
      for j in xrange(N): 
	 r = self.next() 
	 if self._verbosity > 0:
	    print "[select]", j
	    print hstring(r)
      return self.getSelection()


# File Output
# -----------
   
   def printRanking(self,fn,i=None):
      f = open( fn, "w" )
      if i == None: R = self.getSelection()
      else: R = self.ranking[i]
      for r in R: f.write( hstring(r) + "\n" )
      f.close()
   
   def printRankings(self,fnbase):
      for i in xrange(len(self)): 
	 fn = fnbase + str(i+1) + ".txt"
	 self.printRanking(fn,i)
   def printCSV(fn):
      return saveCSV( fn, array2list( self.C, self.S ) )



# The :class:`fvSelect` class
# ===========================
#
# .. autoclass:: fvSelect
#
# ::

class fvSelect(abstractSelect):
   """
   This class is designed neatly to collect all the intermediate calculations
   required to rank and select features.  We need to store entropies
   and conditional entropies for every individiual feature as well 
   as some pairs.
   """

# We have to conventions for indexing features.  The :mod:`numpy`
# module require indexing starting with zero, while the :mod:`pysteg`
# module use indices starting at one.  Internal methods  will use
# :mod:`numpy` indexing, although :mod:`pysteg` indexing is used
# in the stored ranking data.  Methods intended to be public will
# use :mod:`pysteg` indexing.
#
#   ::

   def __init__(self,C,S,T=None, 
	 exclude=None, independent=False, alg="JMI", 
	 *a,**kw):

      abstractSelect.__init__(self,C,S,T,*a,**kw)

# The exclude and independent parameters guide how the KDE-s are 
# calculated and used to estimate entropy.
#
#   ::

      self.exclude = exclude
      self.independent = independent

# The alg parameter allows selecting the algorithm.
# Some algorithms may take additional keyword parameters.
# The :math:`beta` and :math:`gamma` parameters are used in Gavin
# Brown's formula for feature selection heuristics.
#
#   ::

      self._alg = alg.upper()
      if self._alg == "FOU":
        if kw.has_key( "beta" ): self._beta = kw["beta"]
        else: self._beta = 1
        if kw.has_key( "gamma" ): self._gamma = kw["gamma"]
	else: self._gamma = 1

# We calculate the etropies of individual features straight away.
# Only :mod:`numpy` indexing is required here.
#
#   ::

      self.H = map( lambda (x,y,z) : self.featureEntropy( x,y,z ),
            imap( lambda j : ( C[j,:], S[j,:], T[j,:] ),
                  xrange( self.dimension() )  ) )
      print "[fvSelect] Completed construction"

# The :func:`featureEntropy` function require several configuration
# parameters taken from object attributes.  To get this conveniently 
# and consistently done, we make a wrapper method.
#
#   ::

   def featureEntropy(self,C,S,T):
      """
      This is a wrapper for :func:`featureEntropy`, using object
      settings for all the configuration arguments.  Only the
      feature matrices C, S, and T are given.
      """
      return featureEntropy( C, S, T,
	         exclude=self.exclude,independent=self.independent,
		 verbosity=self._verbosity )

# Simple Accessor Methods
# ------------------------
   
   def _getHeuristic(self,n,order=-1):
      """
      Return the heuristic of feature n for the selection of the
      order-th feature.  This is an internal method, using :mod:`numpy`
      indexing.
      """
      return self.heuristic[order][n]

# Entropy and Information
# ^^^^^^^^^^^^^^^^^^^^^^^
#
#   ::

   def _Entropy(self,i):
      "Return the estimated entropy of the i-th feature."
      if np.isnan( self.H[i][0] ): print "Entropy(i=%i) = NaN" % (i,)
      return self.H[i][0]
   def _conditionalEntropy(self,i):
      """
      Return the estimated conditional entropy of the i-th feature,
      conditioned on the class label.
      """
      if np.isnan( self.H[i][1] ):
	   print "conditionalEntropy(i=%i) = NaN" % (i,)
      return self.H[i][1]
   def _labelInformation(self,i):
      """
      Return the estimated mutual information between the i-th feature
      and the class label.  Internal method using :mod:`numpy` indexing.
      """
      return self._Entropy(i) - self._conditionalEntropy(i)

# Feature Selection 
# -----------------
#
# .. automethod:: fvSelect.itselect
# 
# ::

   def itselect(self,N=50): 
      "Alias for :meth:`select` as inherited from the abstract class."
      return self.select(N)

# Calculating the Heuristic
# -------------------------
#
# The heuristic to be calculated is given as
#
# .. math::
#       J_n &= I(X_n;Y) - \beta \sum_{i=1}^{N} I(X_n;X_i)
#                      + \gamma \sum_{i=1}^{N} I(X_n;X_i|Y)
#
# where :math:`X_i` is the :math:`i`th feature,
# :math:`Y` is the class label, and :math:`N` is the number
# of currently selected features.
# The rationale for this formula is as a first-order approximation
# of the conditional mutual information between the candidate
# feature :math:`X_n` and the class label :math:`Y`.
#
# .. math::
#           J_n\approx I(X_n;Y| X_1,\ldots,X_N).
#
# The formula can be rewritten as
#
# .. math::
#       J_n = H(X_n) - H(X_n|Y) 
#           &- \beta \sum_{i=1}^{N} ( H(X_n) + H(X_i) - H(X_n,X_i) )
#           \\&
#           + \gamma \sum_{i=1}^{N} ( H(X_n|Y) + H(X_i|Y) - H(X_n,X_i|Y) )
#
# This is calculated using the following method.
#
# .. automethod:: fvSelect._itheuristic
#
# ::

   def _itheuristic(self,n,h2=None,c2=None):
      """
      Calculate the heuristic of the n-th feature (:mod:`numpy` indexing)
      with respect to the currently selected features.  If the n-th feature 
      has already been selected, then -inf is returned.

      This is called by the :meth:`_getRankData` method if the FOU
      heuristic is chosen at instantiation.  It should not be called
      directly; at least it should not be called if the object
      is configured to use another heuristic.
      """

# When we select the first feature, this is straightforward as both
# the sums are empty.
#
#   ::

      if len(self) == 0: return self._labelInformation(n)
      else:

# OK, we have at least one previously selected feature.
# First, we find the last selected feature, and the previous
# heuristic.
#
#   ::

	 last = self._lastSelected()
	 if n == last: return (-np.inf)
	 A = self._getHeuristic(n)

# Secondly, we need to identify degenerate cases, where the
# previous round heuristic is not a real number.
#
#   ::

	 if np.isnan(A) or np.isinf(A):
	    print "[itheuristic] Shortcut: A =", A
	    return A
         elif n in self._getSelectedIndices():
	    print "[itheuristic] n previously selected and not detected.",\
		  "ERROR."
	    return (-np.inf)

# Having excluded all the degenerate cases, we now need to calculate
# mutual information.  The :meth:`_Entropy` and :meth:`conditionalEntropy`
# calls should be simple table lookups, not worth parallelising.  However,
# the :meth:`featureEntropy` call will require several KDE calculations.
# In order to parallise these calls, they should be made separately,
# with the result passed as the h2/c2 arguments.
#
#   ::

	 if h2 == None:
            (h2,c2) = self.featureEntropy(
	        self.C[[n,last],:], self.S[[n,last],:], self.T[[n,last],:] )

# Now we have all the terms for the heuristic, so let's calculate
# the return value, print, and return.
#
#   ::

         B = self._Entropy(n) + self._Entropy(last) - h2
         C = self._conditionalEntropy(n) + self._conditionalEntropy(last) - c2
         R = A - self._beta*B + self._gamma*C
         print "[itheuristic]", A, B, C
	 print "[itheuristic] %i (%i): %f" % (n,len(self)+1,R)
	 return R

   def _jmi(self,n,h2=None,c2=None):
      """
      Calculate the JMI heuristic of the n-th feature (:mod:`numpy` indexing)
      with respect to the currently selected features.  If the n-th feature 
      has already been selected, then -inf is returned.

      This is called by the :meth:`_getRankData` method if the JMI
      heuristic is chosen at instantiation.  It should not be called
      directly; at least it should not be called if the object
      is configured to use another heuristic.
      """

# When we select the first feature, we need to use a separate function
# for single-feature heuristics.  If feature number n is previously
# selected, we also need to return immediately.
#
#   ::

      if len(self) == 0: return self._labelInformation(n)
      elif n in self._getSelectedIndices():
	    print "[_jmi] (%s) previously selected." % (n,)
	    return (-np.inf)
      else:

# Now, we find the last selected feature.  We also need the previous
# heuristic, unless this is the second feature to be selected.
#
#   ::

	 last = self._lastSelected()
	 A = 0
	 if len(self) > 1: A = self._getHeuristic(n)

# The :meth:`featureEntropy` call will require several KDE calculations.
# In order to parallise these calls, they should be made separately,
# with the result passed as the h2/c2 arguments.  If the system is
# run sequentially, we may have to calculate h2/c2 now.
#
#   ::

	 if h2 == None:
            (h2,c2) = self.featureEntropy(
	        self.C[[n,last],:], self.S[[n,last],:], self.T[[n,last],:] )

# Now we have all the terms for the heuristic, so let's calculate
# the return value, print, and return.
#
#   ::

         B = h2 - c2
         R = A + B
	 print "[_jmi] (%d:%d) %s = %s+%s" % (n,len(self),R, A, B)
	 return R


# The following method is an auxiliary used by :meth:`next` to 
# assemble all the information recorded per feature in the object.
#
#   ::

   def _getRankData(self,n,*a,**kw):
      """
      Return a tuple (n,k,h) where n is the feature (:mod:`pysteg`)
      index, k is the feature key (name), and h is its heuristic.
      It can use different heuristics depending on which was selected
      at instantiation of the object.
      """
      if self._alg == "JMI": hval = self._jmi(n,*a,**kw)
      elif self._alg == "FOU": hval = self._itheuristic(n,*a,**kw)
      else: raise Exception, "Unknown algorithm (%s)" % (self._alg,)
      return (self.getIndex(n),self._getKey(n), hval, None )


def mkSelect(L,**kw):
   if type(L) == str: L = loadCSV(L)
   (C,S) = list2array(L)
   return fvSelect(C,S,**kw)

# Functions (legacy)
# ==================
#
# :func:`labelInformation`
# ------------------------
#
# ::

def labelInformation(C,S,T,*a,**kw):
   """
   Calculate the mutual information between the given features and the
   class label.  The parameters C and S are feature matrices for each
   class, and T is a combined feature matrix for both classes.

   (Not used.)
   """

# This is quite simple.  We get the entropy and the conditional
# entropy from :meth:`entropy` and return the difference.
#
#   ::

   (h0, h1) = entropy(C,S,T,*a,**kw)
   return h0 - h1

