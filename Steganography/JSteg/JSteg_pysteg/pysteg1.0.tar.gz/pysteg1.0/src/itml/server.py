## $Id$
## -*- coding: utf-8 -*-

"""
Module for a server object to help feature selection.

:Module:    itml.server
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.cliselect] $Id$"

# ###########
# itml.server
# ###########
#   
# .. automodule:: itml.server
#
# ::

from . import *
import pickle
from mysocket import *
import threading
import socket
import sys

class serverThread(threading.Thread):
   """
   A server thread listens to a port and spawns client threads to
   manage individual connections.
   """
   def __init__(self,fv,port=defaultPort):
      self.port = port
      self.fv = fv
      threading.Thread.__init__(self)
      self.daemon = True
   def run(self):
      sock = socket.socket( socket.AF_INET, socket.SOCK_STREAM)
      hostname = "0.0.0.0"
      sock.bind((hostname, self.port))
      sock.listen(5)
      cont = True
      count = 0
      print "[reqAccept] Listening ", hostname, self.port
      sys.stdout.flush()
      while cont:
        (clientsocket, address) = sock.accept()
        ct = clientThread(mySocket(clientsocket),self.fv)
        count += 1
        print "[reqAccept] Connection no. %i from %s" % (count, address )
        ct.start()
      print "[reqAccept] Completed %i connections" % (count,)

class taskerThread(threading.Thread):
   "Thread class to fill the task queue."
   def __init__(self,fv,Q=None):
      self.fv = fv
      if Q == None: (self.Q,tmp) = fv.getQ()
      else: self.Q = Q
      threading.Thread.__init__(self)
      self.daemon = True
   def run(self):
      for a in self.fv.getArgs(): self.Q.put(a,True)
      print "[taskerThread] completing"

class clientThread(threading.Thread):
   "A client thread is used to manage a single connection with a client."
   def __init__(self,sock,fv,verbosity=1):
      print "[clientThread] Starting"
      self.sock = sock
      self.fv = fv
      (self.taskQ,self.resultQ) = fv.getQ()
      threading.Thread.__init__(self)
      self.daemon = True
      self._verbosity = verbosity

   def run(self):
      print "[clientThread.run] Starting", self.name

# Message 1: receiving the Hello

      msg = self.sock.receive ()
      if msg != reqString:
        raise RuntimeError( "Protocol error" )

# Message 2a-b: sending a pickled object.

      job = self.taskQ.get(True)
      msg = pickle.dumps( job )
      L = len(msg)
      if self._verbosity > 2:
        print "[request] (%s) pickled length is %i" % (self.name,L)
      self.sock.send( okString( L ) )
      self.sock.send( msg )

# At this stage, we should be prepared for loss of connection.
# If this happens, we should detect it, requeue the job, and
# return.  TODO
#
# Message 3a-b: receiving pickled results

      msg = self.sock.receive()
      if msg == errString:
	 raise RunTimeError( "Client Reported Error" )
      elif msg == ackString:
	 raise RunTimeError( "Client Terminated without results" )
      elif msg[:2] != "RS":
	 raise RunTimeError( "Protocol Error" )
      msglen = int( msg[2:] )
      msg = self.sock.receive( msglen )
      try:
         R = pickle.loads(msg)
      except Exception as e:
         print_exc(e)
	 self.sock.send(errString)
	 raise e

# Message 4: Send acknowledgement and close.
# At this stage, the client should have the choice of terminating
# or looping again from the beginning without reconnecting.

      self.resultQ.put( R )
      print "[result] received and queued result"
      self.sock.send( ackString )
      self.sock.shutdown( socket.SHUT_RDWR )
      self.sock.close()
      return

class localThread(threading.Thread):
   "A local thread to perform entropycalculations."
   def __init__(self,sock,taskQ,resultQ):
      self.sock = sock
      self.taskQ = taskQ
      self.resultQ = resultQ
      threading.Thread.__init__(self)
      self.daemon = True

   def run(self):
      raise NotImplementedError
