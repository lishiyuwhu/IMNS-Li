## $Id$
## -*- coding: utf-8 -*-

"""
Features selection using Information Theory.

:Module:    itml.servselect
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.select] $Id$"

# ###############
# itml.servselect
# ###############
#   
# .. automodule:: itml.servselect
#
# ::

from . import *

# Imports for parallelism::

from . import server
from Queue import Queue

# .. autoclass:: servSelect
#
# ::

class servSelect(object):
   """
   This class is designed neatly to collect all the intermediate calculations
   required to rank and select features.  We need to store entropies
   and conditional entropies for every individiual feature as well 
   as some pairs.
   """

   def __init__(self,S, verbosity=2, port=None, *a,**kw):
      self._select = S
      self._verbosity = verbosity
      self.taskQ = Queue()
      self.resultQ = Queue()
      servkw = {}
      if port: servkw["port"] = port
      servTh = server.serverThread(self,**servkw)
      servTh.start()

# .. automethod:: servSelect.itselect
# 
# ::

   def select(self,N=50):
      """
      Return a list of :param N: selected features based on 
      Information Theoretic measures.  This quite simply calls
      :meth:`next` N times.
      """
      for j in xrange(N): 
	 r = self.pnext() 
	 if self._verbosity > 0:
	    print "[itselect]", j
	    print hstring(r)
      return self.getSelection()

   def itselect(self,*a,**kw): 
      print "Deprecation warning! itselect() -> select()"
      return self.select

# .. automethod:: servSelect.pnext
# 
# ::

   def pnext(self,*a,**kw):
      "Parallel version of :meth:`next`.  See this."

# For the first selection, we use the single-thread implementation. 
#
#   ::

      if len(self._select) == 0: return self._select.next()

# In order to parallelise this, we will need to set up two queues;
# one for input and one for output, for the :func:`featureEntropy`
# function.  Two threads are used; one to create the task queue and
# one to handle client connections.
#

      taskTh = server.taskerThread(self)
      taskTh.start()

# Now, the threads will live their own lives, and we will focus
# on processing results from resultQ and genereate the ranking.
# We initialise the ranking as a list of None objects, and
# keep a count of remaining entries to calculate.
#
#
#   ::

      R = [ None for i in xrange(self.dimension()) ]
      count = self.dimension()

# We loop until the count is zero, getting results from the queu
# and use it to calculate rank data.  

      while count > 0:
	 (n,h2,c2) = self.resultQ.get()
	 R[n] = self._getRankData( n, h2, c2 )
	 print "[pnext] Calculated rank for feature", n
	 count -= 1
      assert R.count(None) == 0

# If we risk losing clients, it could be an idea to use a timeout
# on the :meth:`get` call, and check if the task list is empty.
# If the task list is found empty twice, after a reasonable timeout,
# tasks corresponding to all the missing results may be requeued.
#
# Finally, store and return as in the non-parallel version.
#
#   ::

      self._storeRank( R )
      return R[0]

   def getQ(self):
      return (self.taskQ,self.resultQ)

   def getArgs(self):
      last = self._select._lastSelected()
      for n in xrange(self.dimension()): 
	 yield ( n, self._select.C[[n,last],:], self._select.S[[n,last],:],
	            self._select.T[[n,last],:] )

# Wrapper Methods for :class:`fvSelect`
# -------------------------------------
   
   def getSelection(self,*a,**kw):
      return self._select.getSelection(*a,**kw)
   def _getRankData(self,*a,**kw):
      return self._select._getRankData(*a,**kw)
   def _storeRank(self,*a,**kw):
      return self._select._storeRank(*a,**kw)
   def dimension(self,*a,**kw):
      return self._select.dimension(*a,**kw)
   def printRanking(self,*a,**kw):
      return self._select.printRanking(*a,**kw)
   def printRankings(self,*a,**kw):
      return self._select.printRankings(*a,**kw)
