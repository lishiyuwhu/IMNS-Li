## $Id$
## -*- coding: utf-8 -*-

"""
Information Measures.

This module includes the necessary functions to estimate Entropy and
Mutual Information of Continuous Variables.
"""

print "[itml.shannon] $Id$"

# ###############################
# The :mod:`itml.shannon` library
# ###############################
#
# .. automodule:: itml.shannon
#   
# :Module:    itml.shannon
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
#
# Entropy Estimation consists of two steps
# 1. Estimating the probability density function.
# 2. Calculating empirical entropy based on the estimated density function.
# 
# Step 1 can be solved by kernel density estimation which is a very popular
# method in the literature.  It is implemented in scipy with a Gaussian
# kernel, and we will use this implementation for simplicity.  It is @
# imported as :class:`kde` so that it may easily be replaced later, if
# desired.
#
# ::

from scipy.stats import gaussian_kde as kde
import numpy as np
import sys

#
# The :class:`scipy.stats.gaussian_kde` class requires input as a
# 2-D array where each column is one observation.  Consequently, we
# use the same array representation in this module.
#
# An intuitive way to solve Step 2 is to substitute the estimated density
# for the theoretical density in the formula for entropy. However, this
# is not quite the favoured method in the literature.
#
# A very simple estimate to calculate is that of Ahmad and Lin.
# Contrary to other methods, it requires no integration, and thus
# it avoids the challenge of finding the optimal way of numerical 
# integration for the given dimensionality and sample size.
# We implement it as follows.
#
# ::

def ahmadlin(X,verbosity=0):
   """
     Estimate the entropy using the formula of Ahmad and Lin.
   """

# The :class:`kde` class is used to estimate a probability density 
# function.  If there are numerical problems with the input matrix
# X, this will cause an error or exception.  We catch this to investigate.
# 
#    ::

   try:
      f = kde(X)
   except Exception as e:
      print "Exception in ahmadlin():", e, type(e)

      # A common problem is 0 entropy because all observations are equal.
      # In this case the solution is obvious.
      #
      # ::

      if ( np.max(X) == np.min(X) ):
	 print "Singular matrix; all feature values are equal.  Entropy is 0."
	 return 0

      # If we don't have a solution, we print the input matrix X for
      # debugging purposes and reraise the exception.
      #
      # ::

      print "X =", X
      sys.stdout.flush()
      raise e

# Based on the estimated probability density f, we can calculate
# empirical entropy using the Ahhad-Lin formula.
#
#    ::

   else:

     y = f.evaluate(X)
     if verbosity > 2:
       print "[ahmadlin]", np.var(X), np.max(y), np.min(y)
     s = np.log(y)
     r = - sum(s)/len(s)

     # We print diagnostic output only if there was no exception,
     # as s would not be defined otherwise.
     #
     # ::

     if verbosity > 3:
       print "[ahmadlin]", X.shape, len(s), r

   # Finally, we return::

   return r

contEntropy = ahmadlin

#
# A typical problem in relation to ranking features for machine learning
# will be to estimate the mutual information I(X;Y) where X is a vector
# of continuous features and Y is {0,1} label.
#
# ::

def labelInformation(X,Y):
   """
     Calculate the mutual information I(X;Y) where Y is a list of 0,1 labels
     and X is an array of continuous values on the usual format.
   """

# First the hard part, the conditional entropy H(X|Y).
# We start by creating lists of indices for each possible label::

   l = len(Y)
   L0 = [ i for i in xrange(l) if Y[i] == 0 ]
   L1 = [ i for i in xrange(l) if Y[i] == 1 ]
   assert l == len(L0) + len(L1), "Labels should be 0 and 1"

# Now we can calculate H(X|Y=0) and H(X|Y=1), and H(X|Y) will be a weighted
# average of these two::

   h0 = contEntropy(X[:,L0]) # H(X|Y=0) 
   h1 = contEntropy(X[:,L1]) # H(X|Y=1)
   ch = len(L0)*h0 + len(L1)*h1
   ch /= l

# Finally we calculate H(X), take the difference H(X) - H(X|Y), and return::

   h = contEntropy(X)   # H(X)
   return h - ch

#
# References
# ==========
#
# Eggermont and LaRiccia 1999
#
# Mokkadem 1989
#
# Ahmad and Lin 1989
