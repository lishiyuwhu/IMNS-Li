#! /usr/bin/env python
## -*- coding: utf-8 -*-
## $Id$

from __future__ import division

# Importing future division means that division (/) of two integers
# is floating point rather than integer division.  To get integer
# division one will have to use // instead.

"""
Self-organising maps

:Module:    itml.som
:Date:      $Date$
:Revision:  $Revision$
:Author:    Kyle Dickerson <kyle.dickerson@gmail.com> Jan 15, 2008
            © 2011: Hans Georg Schaathun <georg@schaathun.net>
:Credits:   Also using code and ideas of Paras Chopra <paras1987@gmail.com>
:Licence:   Licenced and released under GNU GPL by Kyle Dickerson
"""

print "[itml.som] $Id$"

# ####################
# Self organising maps
# ####################
#
# .. automodule:: itml.som
#
# This module combines ideas from several source files of Kyle Dickerson
# and Paras Chopra.  The original code was found at:
#   http://www.paraschopra.com/sourcecode/SOM/index.php
# This version attempts to use scipy/numpy matrix operations as much
# as possible, because I find that easier to read.  Your mileage may
# vary, and Paras Chopra's original code does not use scipy.
#
# If you do use this code for something, please let me (us?) know,
# I'd like to know if has been useful to anyone.
#
# Imports
# =======

import sys
import scipy
import matplotlib.pyplot as plt
import numpy as np
import numpy.random as rnd

def norm(A): return np.sqrt( np.sum( A**2, axis=2 ) )

# The SOM class
# =============

class SOM:

    def __init__(self, height=10, width=10, FV_size=10,
	         labeldim=0, learning_rate=0.005):
        self.height   = height
        self.width    = width
        self.FV_size  = FV_size  # Dimension of the feature space
        self.labeldim = labeldim  # Dimension of the feature space
        self.radius   = (height+width)/3
        self.learning_rate = learning_rate

# We use two matrices to hold the feature nodes (nodes) and the
# corresponding classification (prediction) label nodes (lnodes).
#
#   ::

        self.nodes    = rnd.randn( height, width, FV_size ) 
        self.lnodes   = rnd.randn( height, width, labeldim ) 

    def _isnan(self):
       return np.isnan(self.nodes).any() or np.isnan(self.lnodes).any() 

# ::

    def train(self, train_vector=[], label_vector=[], iterations=1000, shuffle=True ):
        """
	train_vector: [ FV0, FV1, FV2, ...] -> [ [...], [...], [...], ...]
	label_vector: [ L0, L1, L2, ...] -> [ [...], [...], [...], ...]
        Vectors may be a list of lists and will be converted to a list 
	of scipy arrays.
	"""
	print "[SOM.train] Starting"
        train_vector = [ scipy.array(v) for v in train_vector ]
        label_vector = [ scipy.array(y) for y in label_vector ]
        dataset = zip(train_vector,label_vector)
	if shuffle: rnd.shuffle(dataset)
        time_constant = iterations/scipy.log(self.radius)
        delta_nodes = np.zeros( ( self.height, self.width, self.FV_size ) )
        delta_labels = np.zeros( ( self.height, self.width, self.labeldim ) )
        
        for i in xrange(1, iterations+1):

# The nodes are only updated at the end of the round, after all input objects
# have been processed.  We use the two matrices delta_nodes and delta_labels 
# to store the accumulated modifaction to be applied to the the node weights
# and node labels at the end of the round.  Obviously, these matrices must
# be intialised to 0.
# 
#   ::

            delta_nodes.fill(0)
            delta_labels.fill(0)

# The neighbourhood :math:`N_c` is a sphere with radius radius_decaying.
# The influence is scaled by dividing by rad_div_val.
#
#   ::

            radius_decaying = self.radius*scipy.exp(-1.0*i/time_constant)
            rad_div_val = 2 * radius_decaying * i

# The learning rate :math:`\alpha(t)` is given by learning_rate_decaying.
#
#   ::

            learning_rate_decaying = \
		  self.learning_rate*scipy.exp(-1.0*i/time_constant)

# Now, print some diagnostic output before we start looping over input
# objects.
#
#   ::

            sys.stdout.write( "\rTraining Iteration: "
		            + str(i) + "/" + str(iterations))
            sys.stdout.flush()
            
	    for (v,y) in dataset:
                best = self.best_match( v )
                for loc in self.find_neighborhood(best, radius_decaying):


# First, we set the scaling factor inf_lrd (in two steps), and check
# that we do not get a NaN for any reason.
# 
#   ::

                    influence = scipy.exp( (-1.0 * (loc[2]**2)) / rad_div_val )
                    inf_lrd = influence*learning_rate_decaying

		    if np.isnan(influence): raise RuntimeError, "influence is NaN"
		    if np.isnan(inf_lrd): raise RuntimeError, "inf_lrd is NaN"

# Then, we calculate the delta values for the current node.
#
#    ::
                    
                    delta_nodes[loc[0],loc[1]] += \
			  inf_lrd * ( v - self.nodes[loc[0],loc[1]] )
                    delta_labels[loc[0],loc[1]] += \
			  inf_lrd * ( y - self.lnodes[loc[0],loc[1]] )

# Now, the round is complete and we double check that we have not got a
# NaN value in the delta matrices.
#
#   ::

            if np.isnan(delta_nodes).any():
               sys.stdout.write("\n")
	       print v
	       print y
	       raise RuntimeError, "NaN occured in delta_nodes"
            if np.isnan(delta_labels).any():
               sys.stdout.write("\n")
               print v
               print y
               raise RuntimeError, "NaN occured in delta_labels"

# After processing all the input, we update the nodes.
#
#   ::

            self.nodes += delta_nodes
            self.lnodes += delta_labels

# The method is complete.  Terminate the output line.
#
#   ::

        sys.stdout.write("\n")
    
    def find_neighborhood(self, pt, dist):
        """
        Returns a iterator over points which live within 'dist' of 'pt'
        Uses the Chessboard distance
        pt is (row, column)
	"""
        min_y = max(int(pt[0] - dist), 0)
        max_y = min(int(pt[0] + dist), self.height)
        min_x = max(int(pt[1] - dist), 0)
        max_x = min(int(pt[1] + dist), self.width)
        for y in range(min_y, max_y):
            for x in range(min_x, max_x):
                dist = abs(y-pt[0]) + abs(x-pt[1])
                yield (y,x,dist)
    
    def best_match(self, target_FV):
        """
	Returns location of best match, uses Euclidean distance
        target_FV is a scipy array
	"""
        loc = scipy.argmin(((self.nodes - target_FV)**2).sum(axis=2))
	r = int( loc / self.width )
	c = int( loc % self.width )
        return (r, c)

    def FV_distance(self, FV_1, FV_2):
        """
	returns the Euclidean distance between two Feature Vectors
        FV_1, FV_2 are scipy arrays
	"""
        return (sum((FV_1 - FV_2)**2))**0.5

    def colourplot(self, filename=None):
       "Plot a visual representation of the self-organised map."
       assert self.labeldim <= 3, \
		       "This plot assumes labels of dimension 3 or less."
       from PIL import Image
       img = Image.new("RGB", (self.width, self.height))
       for r in range(self.height):
          for c in range(self.width):
             img.putpixel( (c,r), tuple((self.lnodes[r,c,:]*255+128).astype(int)) )
       img = img.resize((self.width*10, self.height*10),Image.NEAREST)
       if filename != None:
               print "Saving Image:", filename
	       img.save( filename )
       return img

    def uMatrixPlot(self, filename=None):
       "Plot a visual representation of the uMatrix."
       from PIL import Image
       img = Image.new("L", (self.width, self.height))
       U = self.uMatrix()
       mx = np.max(U)
       U /= mx
       U *= 255
       U = U.astype(int)
       for r in range(self.height):
          for c in range(self.width):
             img.putpixel( (c,r), U[r,c] )
       img = img.resize((self.width*10, self.height*10),Image.NEAREST)
       if filename != None:
          print "Saving Image:", filename
	  img.save( filename )
       return img
       "Return the u-matrix of the SOM, as a numpy floating point array."
    def uMatrix(self, neighbourhood=4):
       if neighbourhood == 8:
	   raise NotImplementedError
       elif neighbourhood != 4:

# First, calculate the distance between neigbour pairs of nodes.
#
#   ::

	   raise TypeError, "Neigbourhood must be 4 or 8."
       hz = norm(self.nodes[:,1:,:] - self.nodes[:,:-1,:])
       vt = norm(self.nodes[1:,:,:] - self.nodes[:-1,:,:])

# Now, we generate an array R for the return value, and set
# each entry equal to the sum of distances to all the neighbours
# of the corresponding node.
#
#   ::

       R = np.zeros( self.nodes.shape[:2] )
       R[1:,:]  += vt
       R[:-1,:] += vt
       R[:,1:]  += hz
       R[:,:-1] += hz

# Finally we divide each entry to get the average of the neighbour
# distances.  Corners are divided by 2, edges by 3, and interior
# elements by 4.  Then we can return.
#
#   ::

       R[0,1:-1]    /= 3
       R[-1,1:-1]   /= 3
       R[1:-1,0]    /= 3
       R[1:-1,-1]   /= 3
       R[1:-1,1:-1] /= 4
       R[0,0]   /= 2
       R[0,-1]  /= 2
       R[-1,0]  /= 2
       R[-1,-1] /= 2
       return R

# ::

class node(object):
    def __init__(self):
	self.contents = {}
    def get(self,Y):
	if self.contents.has_key( Y ): return self.contents[Y] 
	else: return 0
    def add(self,Y):
	if not self.contents.has_key( Y ): self.contents[Y] = 0
	self.contents[Y] += 1

markerDict = {
  (-1,-1, 0) : { "marker" : "s", "edgecolors" : "r", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (-1,-1,+1) : { "marker" : ">", "edgecolors" : "r", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (-1,+1, 0) : { "marker" : "s", "edgecolors" : "k", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (-1,+1,+1) : { "marker" : ">", "edgecolors" : "k", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (+1,-1, 0) : { "marker" : "d", "edgecolors" : "r", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (+1,-1,+1) : { "marker" : "<", "edgecolors" : "r", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (+1,+1, 0) : { "marker" : "d", "edgecolors" : "k", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (+1,+1,+1) : { "marker" : "<", "edgecolors" : "k", "facecolors" : "none",
     "linewidth" : (0.1,) },
  (-1, 0,-1) : { "marker" : "+",
     "edgecolors" : "b", "facecolors" : "b", "c" : "b",
     "linewidth" : (0.2,) },
  (+1, 0,-1) : { "marker" : "x", "c" : "b", 
     "edgecolors" : "b", "facecolors" : "b", "c" : "b",
     "linewidth" : (0.2,) },
      }


class SOMclassifier(object):
    def __init__(self,som):
        self.som = som
	self.nodes = {}
    def addobject(self,X,Y):
	L = self.som.best_match(X)
	if not self.nodes.has_key(L): self.nodes[L] = node()
	self.nodes[L].add( Y )
    def classify(self,FV,PV):
        FV = [ scipy.array(v) for v in FV ]
	for (X,Y) in zip(FV,PV): self.addobject(X,Y)

    def plot(self,filename=None,markers=markerDict):
	fig = plt.figure()
	plt.hold(True)
	for k in markers.keys():
	    K = self.nodes.keys()
            K = [ L for L in K if self.nodes[L].get(k) > 0 ] 
            print "[plot]", k, len(K)
	    if len(K) > 0:
	      X = [ x for (x,y) in K ]
	      Y = [ y for (x,y) in K ]
              s = [ 3+2*self.nodes[L].get(k) for L in K ]
	      plt.scatter(X,Y,s=s,**markers[k])
        if filename != None:
            print "Saving Image:", filename
	    plt.savefig( filename )
	return fig

