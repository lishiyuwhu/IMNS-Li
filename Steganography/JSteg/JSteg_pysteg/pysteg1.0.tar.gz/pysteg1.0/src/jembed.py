#! /usr/bin/env python
## -*- coding: utf-8 -*-
# $Id$

# Embedding in JPEG
# =================
#
# :Script:    jembed.py
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

from optparse import OptionParser
from pysteg.jpeg import jpeg
from pysteg.jsteg import rndembed
from pysteg.jsteg.exceptions import *
import numpy.random as rnd
from pysteg.tools import fnsplit

import shutil

# Argument Parsing
# ----------------

parser = OptionParser()

parser.add_option("-N", "--message-length", help="Message length (bytes)",
          dest="msglength" )
parser.add_option("-o", "--outfile", help="Output (stego) file",
          dest="outfile" )
parser.add_option("-d", "--output-dir", help="Output directory",
          dest="dir" )
parser.add_option("-c", "--cover-dir", help="Cover image directory",
          dest="cdir" )
parser.add_option("-f", "--stego-fraction", help="Fraction of steganograms",
          default=1, dest="frac" )
parser.add_option("-r", "--random-order",
          help="Consider input files in random order",
          dest="rndorder", default=False, action='store_true' )
parser.add_option("-t", "--test", help="Test extraction",
          dest="test", default=False, action='store_true' )
parser.add_option("-A", "--algorithm", help="The algorithm to be used.",
          dest="alg", default="f5" )

(options,args) = parser.parse_args()

frac = float(options.frac)

if ( len(args) > 1 ) & ( options.outfile != None ):
  raise Exception, "Cannot use multiple input files and a single output."

# Definitions
# -----------

R = []

def jemb(infile,outfile):
  fail = False
  msglength = int(options.msglength)
  im = jpeg ( infile ) 
  D = rndembed( im, msglength, options.alg, options.test )
  if options.test: (D,C,K,M) = D
  im.save( outfile )

  if options.test:
    im = jpeg( outfile, key=K )
    S = C(im.getsignal()) 
    Mhat = S.msgExtract()
    D["Result"] = M.isequal(Mhat)
    if D["Result"]:
      print "Test SUCCESSFUL"
    else:
      print "ERROR: extracted message does not match."
  if fail: 
    return None
  else:
    return D

# The main function
# -----------------

def main():
  
  if options.rndorder:
    rnd.seed()
    fl = rnd.permutation(args)
  else: fl = args
  
  print len(fl)
  
  L = int( len(fl)*frac )
  
  if options.dir == None: 
    pref = "stego-"
    cpref = options.cdir
  elif options.cdir == None:
    if options.frac < 1: pref = options.dir + "/stego-"
    else: pref = options.dir + "/"
    cpref = options.dir + "/"
  else:
    pref = options.dir + "/"
    cpref = options.cdir + "/"
  
  for infile in fl[:L]:
    print infile
    if options.outfile == None:
      (d,i,e) = fnsplit( infile )
      outfile = pref + i + e
    else:
      outfile = options.outfile
    D = jemb(infile,outfile)
    if D != None:
      R.append( ( infile, D["Used"], D["Length"], float(D["Used"])/D["Length"] ) )
  
  if cpref != None:
    for infile in fl[L:]:
      shutil.copy(infile, cpref)
    
  for i in R:
    print "%s: Used %i/%i coefficients (ratio %f)." % (i[0],i[1],i[2],i[3])

if __name__ == "__main__": main()
