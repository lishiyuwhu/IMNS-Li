#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

docstring="""
Draw coefficient histograms for JPEG images.

:Script:    jhist.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

from pysteg.jpeg import *
from pysteg.tools import fnsplit
import matplotlib
import matplotlib.pyplot as plt

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-o", "--outfile",
        help="Output filename for the historgram.",
        dest="outfile" )
parser.add_option("-y", "--ylim",
        help="Set limits on the Y axis.  (-y0 uses twice the height of -1.)",
        dest="ylim" )
(options,args) = parser.parse_args()

def yfmt(x): return '$%2.1fM' % (x/1000)

matplotlib.rcParams["font.size"] = 8

def main():
  for infile in args:
    if options.outfile == None:
      (d,f,e) = fnsplit( infile )
      outfile = d + f + "-hist.pdf"
    J = jpeg( infile ) 
    (h,e) = J.hist()
    h = h.astype( float ) ;
    e[0] = -9
    e = e[:-1]
    print h
    print e
    plt.figure( figsize=( 2.55, 2.5 ) )
    plt.bar(e,h/1000,align="center")
    if options.ylim != None:
      if options.ylim == int(0):
        i0 = 2*h[len(h)/2 - 1]
      else:
        i0 = int(options.ylim)
      plt.ylim(0,i0)
    plt.savefig( outfile )
    plt.close()

if __name__ == "__main__":
    main()
