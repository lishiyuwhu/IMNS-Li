#! /usr/bin/env python
## -*- coding: utf-8 -*-

docstring="""
Count non-zero AC coefficients in JPEG images.

:Script:    jstat.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

from optparse import OptionParser
from numpy import mean, var
from pysteg.jpeg import jpeg
from PIL import Image

parser = OptionParser()

parser.add_option("-C", "--calibrated", 
          help="Output file for calibrated pixmap.",
          dest="calfile" )
parser.add_option("-c", "--nzcount", help="Count non-zero AC coef.",
          dest="nzcount", default=False, action='store_true' )
(opt,args) = parser.parse_args()



R = []

for f in args: 
   J = jpeg(f)
   if opt.calfile:
      im = J.getCalSpatial()
      Image.fromarray( im ).save( opt.calfile )
   R.append( (f, J.nzcount()) )

for (f,c) in R: print f, c, "bpac."

R0 = [ c for (f,c) in R ]

print "Mean = %f; variance = %f" % ( mean(R0), var(R0) )
