#! /usr/bin/env python
## -*- coding: utf-8 -*-
# $Id$

# Blockiness Demo
# ===============
#
# :Script:    kerdemo.py
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

import matplotlib
matplotlib.use( "Cairo" )
import matplotlib.pyplot as plt

from optparse import OptionParser
from pysteg.sim.dim import dim, dimadj, dim1, dim2
from copy import deepcopy

# Argument Parsing
# ----------------

parser = OptionParser()

parser.add_option("-s", "--msg-step", help="Message length step size.",
          dest="msgstep", default=64 )
parser.add_option("-o", "--outfile", help="Output file",
          dest="outfile" )
parser.add_option("-m", "--multi-feature",  
         help="More than one feature is used..",
          dest="multi", default=False, action="store_true" )
parser.add_option("-F", "--feature", help="The algorithm to be used.",
          dest="feature", default="hcfcom" )
parser.add_option("-A", "--algorithm", help="The algorithm to be used.",
          dest="alg", default="lsbpm" )
parser.add_option("-a", "--all-algorithms", help="Try every algorithm.",
          dest="allalg", action="store_true", default=False )
parser.add_option("-C", "--compare-algorithms",
          help="Compare all algorithms.",
          dest="compare", action="store_true", default=False )
parser.add_option("-c", "--calibration",
          help="Compare with blockiness for calibrated images.",
          dest="cal", action="store_true", default=False )

(opt,args) = parser.parse_args()

kw = {}
kw1 = { "msgstep" : int(opt.msgstep) }
if opt.feature: kw1["feature"] = opt.feature

# The main function
# -----------------

def main():
  
  fl = args
  plt.rcParams["font.size"] = 8
  plt.rcParams["legend.fontsize"] = 8
  plt.figure( figsize=(4.5,2.75) )
  plt.xlim(0,1.0)
  plt.xlabel( "Message length" )

  A = [ "+", "x", "o", "*", "d" ]
  B = [ "-", ":", "-.", "--" ]
  idx = 0
  
  for infile in fl:
    if opt.compare: im = dim1 ( infile, **kw1 ) 
    elif opt.multi: im = dim2 ( opt.alg, infile, **kw1 ) 
    elif opt.feature == "adjacency":
       im = dimadj ( opt.alg, infile, **kw1 ) 
    else: im = dim ( opt.alg, infile, **kw1 ) 
    if opt.cal: kw["mode"] = "cal"
    if opt.allalg:
      im.fplot("k-","lsb",**kw)
      im.fplot("k:","lsbpm",**kw)
    else:
       im.fplot("k"+B[idx%4],**kw)
    idx += 1
  #if opt.allalg: plt.xlim(0,1.5)
  #if opt.cal: plt.xlim(0,1.5)
  if opt.cal: plt.legend( loc="center left" )
  else: plt.legend( loc="upper right" )
  if opt.outfile != None:
    plt.savefig(opt.outfile, bbox_inches="tight", pad_inches=.2  )

if __name__ == "__main__": main()
