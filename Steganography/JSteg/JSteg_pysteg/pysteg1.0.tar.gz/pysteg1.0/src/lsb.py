#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# LSB Embedding
# =============
#
# :Script:    lsb.py
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

"""
  Quick script to embed messages in images using LSB embedding
  in the spatial domain.  It includes several features to produce
  additional output for diagnostics or demos, including LSB plane
  plots for visual steganalysis.
"""

import sys
sys.path = sys.path + [ "../../Packages", "..", "." ]

from pysteg.tools import *
# pysteg.tools import the following two
import numpy.random as rnd
#import numpy as np
from pysteg.ssteg.lsb import *
from pysteg.ssteg.lsb import str2bit,bit2str
import shutil
import os

from numpy import array
from pysteg.imtools import imsave
from PIL import Image

# Parse options
# -------------

import optparse 
parser = optparse.OptionParser()
parser.add_option("-o", "--outfile",
          help="Output generated steganogram to specified filename.",
          dest="outfile" )
parser.add_option("-i", "--indir",
          help="Input directory.  Use all files therein.",
          dest="indir" )
parser.add_option("-f", "--stego-fraction", help="Fraction of steganograms",
          default=1, dest="frac" )
parser.add_option("-T", "--message-file", 
          help="Embed message from given file.",
          dest="msgfile" )
parser.add_option("-x", "--repeat", 
          help="Embed message REPEAT times.",
          dest="repeat" )
parser.add_option("-X", "--extract", 
          help="Extract message.",
          dest="extract", action="store_true", default=False )
parser.add_option("-m", "--message-length", 
          help="Length of any embedded message in bits.",
          dest="msglength" )

parser.add_option("-M", "--message-rate", 
    help="Length of any embedded message as a fraction of the image size.",
    dest="msgrate" )
parser.add_option("-d", "--output-dir", help="Output directory",
          dest="dir" )
parser.add_option("-c", "--cover-dir", help="Cover image directory",
          dest="cdir" )

# Flags
# ^^^^^


parser.add_option("-k", "--use-key", help="Use a random key",
          dest="key", default=False, action='store_true' )
parser.add_option("-r", "--rotated", 
    help="Embed in left-hand columns instead of top rows (assuming no key).",
    dest="rotate", default=False, action='store_true' )
parser.add_option("-R", "--random-order",
          help="Consider input files in random order",
          dest="rndorder", default=False, action='store_true' )
parser.add_option("-O", "--output",
          help="Output generated steganogram to generated filename(s).",
          dest="out", default=False, action='store_true' )
parser.add_option("-l", "--lsb-plots", 
          help="Make lsb-plots of the the images",
          dest="lsbplot", default=False, action='store_true' )
parser.add_option("-L", "--lsb-plot-only", 
          help="Only make an lsb-plot (no embedding)",
          dest="lsbonly", default=False, action='store_true' )
parser.add_option("-b", "--bitplane", 
          help="Make a plot of a given bit plane.",
          dest="bitplane" )
parser.add_option("-A", "--algorithm", 
          help="Algorithm, either lsb (replacement) or lsbpm (matching).",
          dest="alg", default="lsb" )
parser.add_option("-7", "--reset-lsb", 
          help="Set LSB-s to 0.",
          dest="lsbreset", default=False, action='store_true' )

# Currently unused
# ^^^^^^^^^^^^^^^^

parser.add_option("-v", "--verbose", 
          help="Verbosity level", default=0, dest="verbosity" )

(options,args) = parser.parse_args()
frac = float(options.frac)
verbosity = int(options.verbosity)

if options.indir:
   filelist = [ options.indir + "/" + f for f in os.listdir( options.indir) ]
else: filelist = args


# Main loop
# ---------

def stego(infile,outfile):
  global options
  print infile, "->", outfile
  (d,f,e) = fnsplit( infile )
  # Cover image
  im = Image.open( infile )
  print im.mode
  X = array( im )
  #X = X[:,:,[1,2,0]]

# Message

  if options.msgfile != None:
    M = str2bit( txtread( options.msgfile ) )
  elif options.msglength == None:
    if options.msgrate == None:
      msglength = X.size/2
    else:
      msglength = np.floor( X.size * float(options.msgrate) )
    print "Message length:", msglength
    M = rndbits( msglength ) 
  else:
    M = rndbits( int(options.msglength) ) 
  if options.repeat != None:
    x = int(options.repeat)
    M = np.hstack( [ M for i in xrange(x) ] )

# Key

  if options.key:
    rnd.seed()
    key = rnd.get_state()
  else: key = None

# Embedding and extraction

  if options.alg == "lsb":
    Y = lsbembed( X, M, key=key, rotate=options.rotate )
  elif options.alg == "lsbpm":
    Y = lsbembed( X, M, key=key, rotate=options.rotate, replace=False )
  else: raise Exception, "Unknown algorithm"
  E = lsbextract( Y, key=key, length=len(M), rotate=options.rotate )
  print "X", type(X), X.dtype
  print "Y", type(Y), Y.dtype
  print "E", type(E), E.dtype
  print "Test:", np.sum(abs(E-M)), "errors"

# Plot LSB planes

  if options.lsbplot:
    s = np.floor(np.sqrt(len(M)))
    imsave( 255* np.reshape(M[:s**2],(s,s)), d+f+"-m"+e, "L" )
    imsave( 255*(X%2), d + f + "-lsb" + e, "L" )
    if options.outfile != None:
      (d0,f0,e0) = fnsplit( options.outfile )
      slf = d0 + f0 + "-lsb" + e0
    else: slf = d + f + "-stego-lsb" + e
    imsave( 255*(Y%2), slf, "L" )
    print np.sum(X%2), X.size
    print np.sum(Y%2), Y.size

# Save the steganogram

  if outfile == None and options.out:
    outfile = d + f + "-stego" + e
  if outfile != None:
    im = Image.fromarray( Y )
    print "[stego] Saving to", outfile
    im.save( outfile )
    # imsave( Y, outfile, "RGB" )

def getpref(options):
   if options.dir == None: 
      pref = "stego-"
      cpref = options.cdir
   elif options.cdir == None:
      if frac < 1:
        pref = options.dir + "/stego-"
        cpref = options.dir + "/"
      else:
        pref = options.dir + "/"
	cpref = None
   else:
      pref = options.dir + "/"
      cpref = options.cdir + "/"
   return (pref,cpref)
def getoutfile(infile,options):
  (pref,cpref) = getpref(options)
  if options.outfile == None:
    (d,i,e) = fnsplit( infile )
    outfile = pref + i + e
  else:
    outfile = options.outfile
  if verbosity > 1:
    print "[getoutfile] %s (%s)" % (outfile,infile)
  return outfile

def main():
  if options.lsbreset:
    print "[lsb.py] options.lsbreset"
    for infile in filelist:
      assert options.outfile != None
      outfile = options.outfile
      X = array( Image.open( infile ) )
      X -= X%2
      Image.fromarray( X ).save( outfile )
      print infile, X.shape
  if options.bitplane != None:
    bp = int(options.bitplane)
    for infile in filelist:
      if options.outfile == None:
        (d,f,e) = fnsplit( infile )
        outfile = d + f + "-bit" + str(bp) + e
      else:
        outfile = options.outfile

# This should work with palette images (GIF)
# -- pylab.imread() would convert palette images to RGB

      X = np.array( Image.open( infile ) )
      b = 8 - bp
      print infile, X.shape
      imsave( 255*((X>>b)%2), outfile, "L" )
  elif options.lsbonly:
    print "[lsb.py] options.lsbonly"
    for infile in filelist:
      if options.outfile == None:
        (d,f,e) = fnsplit( infile )
        outfile = d + f + "-lsb" + e
      else:
        outfile = options.outfile

# This should work with palette images (GIF)
# -- pylab.imread() would convert palette images to RGB

      X = np.array( Image.open( infile ) )
      print infile, "->", outfile, X.shape, X.dtype
      print set((255*(X%2)).flatten())
      imsave( 255*(X%2), outfile, "L" )
  elif options.extract:
    print "[lsb.py] options.extract"
    X = array( Image.open( filelist[0] ) )
    if options.msglength != None:
      print options.msglength
      E = lsbextract( X, length=int(options.msglength), rotate=options.rotate )
    else:
      print "No message length", options.msglength
      E = lsbextract( X, rotate=options.rotate )
    S = bit2str(E) 
    print S
  elif frac == 1:
    print "[lsb.py] frac = 1"
    for infile in filelist:
      stego( infile, getoutfile(infile,options) )
  else:
    print "[lsb.py] default"
    if options.rndorder:
      rnd.seed()
      fl = rnd.permutation(filelist)
    else: fl = filelist
    L = int( len(fl)*frac )
    for infile in fl[:L]:
      D = stego( infile, getoutfile(infile,options) )
    if cpref != None:
      for infile in fl[L:]:
        print infile, cpref
        shutil.copy(infile, cpref)
    
if __name__ == "__main__":
    main()
