#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# Make Dataset
# ============

docstring = """
:Script:    mkdataset.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>

This is designed to work with somplot.py.
"""

import optparse 
import pysteg.tools as pt
import numpy as np

# Parsing Options
# ---------------

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

# The following are core options, fully supported and validated.
#
# ::

# File name options::

  parser.add_option("-i", "--infile",
            help="""Dataset input file.""",
            dest="infile" )
  parser.add_option("-o", "--outfile",
            help="""Dataset output file.""",
            dest="outfile" )
  parser.add_option("-m", "--modelfile",
            help="""Scaling model output file.""",
            dest="modelfile" )
  parser.add_option("-T", "--testset",
            help="""Input file for the test set.""",
            dest="testset" )

# Subvector selection::

  parser.add_option("-f", "--feature-set", 
            help="Feature set identifier (e.g. Fridrich, Markov, CP)",
            dest="id" )
  parser.add_option("-F", "--selection", 
            help="""
	    Use the feature selection from the give file, which should be
	    a pickled fvSelect object.
	    """,
            dest="select" )
  parser.add_option("-N", "--dimension", 
            help="""Use the top N features.""",
            dest="dim" )

# Other options::

  parser.add_option("-z", "--no-scaling", 
            help="Do not scale the features",
            default=True, dest="scaling", action="store_false" )
  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            default=0, dest="verbosity" )

  (opt,a) = parser.parse_args()

# Some options need to be converted to appropriate data types::

  opt.verbosity = int(opt.verbosity)

  return (opt,a)

# Function definitons
# ===================

def loadfeatures(infile,id):
   f = open( infile, "r" )
   L = [ eval(line) for line in f ]
   f.close()
   (X,Y) = [], []
   for (k,d,r) in L:
      N = [ pt.loadObject( d + str(i) + ".pgm.dat" ).vector(id) for i in r ] 
      X.extend( N )
      Y.extend( [ k for i in N ] )
   return (X,Y)

def scale(X,sigma=None,basept=None):
   X = np.array( X )
   if sigma == None: 
     assert basept == None
     sigma = np.sqrt( np.var(X, axis=0 ) )
     sigma[sigma==0] = 1
     basept = np.mean(X, axis=0 )
   X -= basept
   X /= sigma
   return (X, sigma, basept)

# The actual work
# ===============
#
#   ::


if __name__ == '__main__':
   (opt,args) = parseArgs()
   (X,Y) = loadfeatures( opt.infile, opt.id )
   if opt.scaling: (X,sigma,basept) = scale(X)
   DS = { "FV" : X, "PV" : Y }
   if opt.modelfile != None: pt.saveObject( (sigma,basept), opt.modelfile )
   if opt.testset != None:
     (X1,Y1) = loadfeatures( opt.testset, opt.id ) 
     if opt.scaling: (X1,sigma,basept) = scale(X1,sigma,basept)
     DS["FV1"] = X1
     DS["PV1"] = Y1

   if opt.outfile != None:
        pt.saveObject( DS, opt.outfile )
