#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

from PIL import Image
import pywt
import numpy as np
from pylab import imshow
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from pysteg.wtools.dwtview import *

from optparse import OptionParser
parser = OptionParser()
parser.add_option("-L", "--level",
          help="Number of decomposition layers length",
	  default=1,
          dest="level" )
parser.add_option("-o", "--outfile",
          help="Output file name",
          dest="outfile" )
(options,args) = parser.parse_args()

for imfile in args:
  im = Image.open( imfile )
  #im0 = im.convert('YCbCr')
  #(Y,Cb,Cr) = im0.split()
  Y = im.convert('L')
  I = np.array( Y )
  
  #g = cm.get_cmap('gray')
  #imshow(I,cmap=g)
  
  H = pywt.wavedec2( I, 'haar', level=int(options.level) ) 
  Hi = wtview(H)
  print np.min(Hi), "...", np.max(Hi)
  imh = Image.fromarray( Hi, 'L' ) 
  if options.outfile != None:
    imh.save( options.outfile )
  else:
    imh.save( 'dwt-' + imfile )

