#! /usr/bin/env python
# $Id$

docstring = """
:Script:    mkplot.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    2011: Hans Georg Schaathun <georg@schaathun.net>
"""

# NB! Import matplotlib and call matplotlib.use() before anything else,
# to avoid pyplot being loaded forcing a default backend.
import matplotlib
#matplotlib.use( "Cairo" )
matplotlib.use( "PDF" )
import matplotlib.pyplot as plt
matplotlib.rcParams["font.size"] = 8

import pysteg.tools as pt
from svm.svmtest import mkdataset
import copy

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-d", "--hist-default",
          help="Output file for histogram with default parameters.",
          dest="h1file", default="hist-default.pdf" )
parser.add_option("-o", "--hist-optimal",
          help="Output file for histogram with optimised parameters.",
          dest="h2file", default="hist-optimal.pdf" )
parser.add_option("-r", "--roc-file",
          help="Output file for ROC plot.",
          dest="rocfile", default="roc.pdf" )
parser.add_option("-R", "--simple-roc-file",
          help="Output file for simple ROC plot.",
          dest="simplefile", default="roc1.pdf" )
parser.add_option("-F", "--feature-vector",
          help="ID for the feature vector to use.",
	  dest="fv" )
# Currently unused
parser.add_option("-v", "--verbose", 
          help="Verbosity level", dest="verbosity" )

(opt,args) = parser.parse_args()

assert len(args) == 1, "One and only one input file should be given."

fvset = pt.loadObject( args[0] )

T = mkdataset(fvset.getCover(),fvset.getStego(),id=opt.fv)
T.write("train.txt")
S1 = mkdataset(fvset.testCover(),fvset.testStego(),id=opt.fv)
S1.write("test.txt")

smod = T.mkscalemodel()
T.scale(smod)
S1.scale(smod)

model1 = T.train()
T.gridsearch()
model2 = T.train()

S2 = copy.copy(S1)
acc1 = S1.predict(model1)
acc2 = S2.predict(model2)
print "[runsvm] Accuracy", acc1, acc2
print "[runsvm] ROC (AUC)", S1.mkauc(), S2.mkauc()

S2.rocplot( line="k-", figsize=(2.6,2.4) )
if opt.simplefile:
    plt.savefig( opt.simplefile, bbox_inches="tight", pad_inches=0.2 )
S1.rocplot( fill="#A0A0A0",ufill=True,dline="k--",line="k:",addto=True)
plt.xlim( 0, 1 )
plt.savefig( opt.rocfile, bbox_inches="tight", pad_inches=0.2 )

plt.figure( figsize=(5,3) )
S1.histplot(opt.h1file,nbin=18,addto=True)
plt.cla()
plt.clf()
plt.figure( figsize=(5,3) )
S2.histplot(opt.h2file,nbin=18,addto=True)
