#! /usr/bin/env python
# $Id$

docstring = """
:Script:    mkroc.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    2011: Hans Georg Schaathun <georg@schaathun.net>

Script to compare ROC plots of multiple feature vectors.
To plot a single classifier, use the mkplot.py script.
"""

# NB! Import matplotlib and call matplotlib.use() before anything else,
# to avoid pyplot being loaded forcing a default backend.
import matplotlib
#matplotlib.use( "Cairo" )
matplotlib.use( "PDF" )
import matplotlib.pyplot as plt
matplotlib.rcParams["font.size"] = 8

import pysteg.tools as pt
from svm.svmtest import mkdataset
import copy
from svm.roc import rocplot

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-i", "--input",
          help="Input file.",
          dest="infile", default="roc.pdf" )
parser.add_option("-r", "--roc-file",
          help="Output file for ROC plot.",
          dest="rocfile", default="roc.pdf" )
parser.add_option("-R", "--new-technique",
          help="Use new function for ROC plots.",
          dest="newtech", default=False, action="store_true"  )
parser.add_option("-C", "--confidence",
          help="Mark confidence intervals.",
          dest="conf", default=0  )
# Currently unused
parser.add_option("-v", "--verbose", 
          help="Verbosity level", dest="verbosity" )

(opt,args) = parser.parse_args()

fvset = pt.loadObject( opt.infile )

plt.figure( figsize=(3.5,3.2) )
plt.hold( True )
plt.xlabel( "False Positive Rate" )
plt.ylabel( "Detection Rate" )

lp = [ "k:", "k-", "k--", "k-." ]
idx = 0

for fv in args:
  T = mkdataset(fvset.getCover(),fvset.getStego(),id=fv)
  S1 = mkdataset(fvset.testCover(),fvset.testStego(),id=fv)
  
  smod = T.mkscalemodel()
  T.scale(smod)
  S1.scale(smod)

  T.gridsearch()
  model = T.train()
  acc1 = S1.predict(model)

  print "[runsvm] Accuracy", acc1, "; ROC (AUC)", S1.mkauc()

  kw = { "line" : lp[idx],
	"label" : fv, }
  if opt.newtech:
     kw["errorbars"] = int(opt.conf)
     rocplot( S1.getscores(), plt=plt, **kw )
  else:
     S1.rocplot( addto=True, **kw )
  idx += 1
  idx %= len(lp)

plt.ylim( 0, 1 )
plt.xlim( 0, 1 )
plt.legend( loc="lower right" )
plt.savefig( opt.rocfile, bbox_inches="tight", pad_inches=0.2 )
