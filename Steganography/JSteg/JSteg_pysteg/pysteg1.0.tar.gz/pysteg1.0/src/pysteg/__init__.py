## $Id$
## -*- coding: utf-8 -*-

"""
Steganography and Steganalysis.

:Module:    pysteg
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net> 

The package is mainly a collection of subpackages and modules 
addressing separate issues of steganography and steganalysis,
including steganographic embedding, steganalysis, and image
processing.

The tools are designed for research.  Thus the embedding routines
focus on the embedding of random data.
The package has evolved over time and the different subpackages
are at different stages of in their life cycles.
The most notable subpackages are as follows:

Subpackages
===========

* :mod:`jpeg`     - load and process JPEG images without decompressing
* :mod:`jsteg`    - steganography in the JPEG domain
* :mod:`ssteg`    - steganography in the spatial domains
* :mod:`features` - steganalysis (feature extraction)
* :mod:`sql`      - a database system to store and process features

Modules
=======

* :mod:`imtools`  - auxiliary functions for image processing
* :mod:`tools`    - auxiliary functions which do not fit elsewhere
* :mod:`tsteg`    - a testing function for the jsteg subpackage
"""

