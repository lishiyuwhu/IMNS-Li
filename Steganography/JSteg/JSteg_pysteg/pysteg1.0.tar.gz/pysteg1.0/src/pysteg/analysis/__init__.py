## $Id$
## -*- coding: utf-8 -*-

"""
Package for feature extraction functions for steganalysis.
Simple implementation is used, quite possibly at the expence
of computational efficiency.  It should be deprecated in favour
of :mod:`pysteg.sql` and :mod:`pysteg.features`.

:Module:    pysteg.analysis
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2009-2010: University of Surrey, UK
            © 2011: Høgskolen i Ålesund, Norway
:Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-11)
 
Subpackages
-----------

The subpackages provide feature extraction functions for different
domains.

* jfeatures -- for the JPEG domain
* sfeatures -- for the spatial domain
* wfeatures -- for the wavelet domain
* dct -- for the DCT domain

Submodules
----------

The submodules set up the generic data structure in the
:mod:`featuretree` module and provides some
auxiliear functions in :mod:`misc`.

The most fundamental submodule is :mod:`featuretree`, defining
the basic data structure for feature vectors.  We describe
this first.
"""

print "[pysteg.analysis] $Id$"
