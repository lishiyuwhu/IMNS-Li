##  $Id$
## -*- coding: utf-8 -*-

# ##########################
# pysteg.analysis.dct.common
# ##########################
#
# .. module:: pysteg.analysis.dct.common
#   
# :Module:    pysteg.analysis.dct.common
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net> 2010
#


from ...jpeg.dct import bdct, ibdct
from ...jpeg.base import acMask
import numpy as np

__all__ = [ "llfeature" ]

mask = acMask(16,16)

def getmb(I):
  (x,y) = I.shape
  x -= x%16
  y -= y%16
  D = bdct(I[:x,:y])
  (d1,d2) = D.shape 
  for i in xrange(0,d1,16):
    for j in xrange(0,d2,16):
      #print (i,j)
      M = D[i:(i+16),j:(j+16)]
      yield M[mask].flatten()

def llfeature(I):
  """
  Return the DCT feature of Lie and Lin.
  Note that the current version crops the image to get dimensions
  divisible by 16 fitting perfectly into the macro block structure.
  """
  #for i in getmb(I): print i
  return np.var( [ 1/np.mean(np.abs(M)) for M in getmb(I) ] )
