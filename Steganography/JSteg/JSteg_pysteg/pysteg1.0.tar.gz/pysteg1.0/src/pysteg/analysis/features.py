## $Id$
## -*- coding: utf-8 -*-

"""
Specific feature vector tree using all features implemented.

Using the tree structure implemented in the features module,
the classes in this module will build a tree populating it with
all the known features from a given image.
"""

print "[pysteg.analysis.features] $Id$"

# *******************************
# The Steganalysis Feature Vector
# *******************************
#
# :Module:    pysteg.analysis.features
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2011: Høgskolen i Ålesund, Norway
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-11)
#
# .. automodule:: pysteg.analysis.features
#
# ::

from ..jpeg import jpeg
import numpy as np
from PIL import Image

# The :mod:`featurevector` module provides the datastructure to be
# used.
#
# ::

import featurevector as fv

# The other subpackages provide different feature vectors
# and the methods to extract them.  We have to include all of them.
#
# ::

import jfeatures.extract as jx
from wfeatures import farid, cfmoments, wam, novel as hgs
# from sfeatures import dm, avcibas, markov as spmarkov, ge
from sfeatures import avcibas, markov as spmarkov, ge, emfeatures as em, ac
from sfeatures import ale, harmsen, sullivan, bsm
import dct

def colVector(file,*a,**kw):
   """
   Return a feature vector object holding all the implemented
   features for colour images.
   """
   R = fv.baseVector(file,*a,**kw)
   im = Image.open( file )
   print "colVector()", type(im), "v%i" % (R.getVerbosity(),)
   cextract( R, im )
   print "[colVector] Complete. Total %i features" % (len(R),)
   return R

def deepVector(file,*a,**kw):
   """
   Return a feature vector object for a grayscale image of
   arbitrary depth.  This can be used, for instance, to
   test raw sensor data which are typically 12 or 14 bits.
   """
   R = fv.baseVector(file,*a,**kw)
   im = Image.open( file )
   print "deepVector()", type(im), "v%i" % (R.getVerbosity(),)

   I = np.array( im )
   S = I.shape
   if len(S) == 2: print "Loaded image %ix%i grayscale" % S
   else: print "Loaded image %ix%i with %i colour channels" % S

   #v = R.getVerbosity()
   label = R.getlabel()

   V = R.add( spmarkov.dmFeatures(I,label=label) )
   for k in V.featureDic.keys():
      R.featureDic[k] = ( V.getname(), k, )
   print "[deepVector] Complete. Total %i features" % (len(R),)
   return R


def baseVector(file,*a,**kw):
   """
   Return a feature vector object holding all the implemented
   features for uncompressed grayscale images.
   """
   R = fv.baseVector(file,*a,**kw)
   im = Image.open( file )
   print "baseVector()", type(im), "v%i" % (R.getVerbosity(),)
   bextract( R, im )
   print "[baseVector] Complete. Total %i features" % (len(R),)
   return R

def bextract(R,im):
    "Extract the features.  (Auxiliary called from the constructor.)"
    I = np.array( im )
    S = I.shape
    if len(S) == 2: print "Loaded image %ix%i grayscale" % S
    else: print "Loaded image %ix%i with %i colour channels" % S

    v = R.getVerbosity()
    label = R.getlabel()

    R.add( hgs.hgsVector(I,"HGS",label=label,verbosity=v) )
    print "HGS complete. Total %i features" % (len(R))
    R.add( em.emVector(I,"EM-108",label=label,verbosity=v) )
    print "EM-108 complete. Total %i features" % (len(R))
    R.add( ac.acVector(I,label=label,verbosity=v) )
    print "AC-10 complete. Total %i features" % (len(R))
    R.add( bsm.bsmVector(I,label=label,verbosity=v) )
    print "BSM complete. Total %i features" % (len(R))
    R.add( wam.wamVector(I,label=label,verbosity=v) )
    print "WAM complete. Total %i features" % (len(R))
    R.add( sullivan.ssisVector(I,label=label,verbosity=v) )
    print "SMCM-130 complete. Total %i features" % (len(R))
    R.add( ale.aleVector(I,label=label,verbosity=v) )
    print "ALE-10 complete. Total %i features" % (len(R))
    R.add( farid.faridFeatures(I, label=label ) )
    print "Farid complete. Total %i features" % (len(R))
    R.add( cfmoments.cfmVector(I,label=label) )
    print "CF-Moments complete. Total %i features" % (len(R))

# 2. 10-set of Avcibas (only 9 meaningful features for grayscale)
#
#     ::

    R.addLeaf( avcibas.iqFeatures(im), ("avcibas",) )
    print "Avcibas complete. Total %i features" % (R.len())

# 3. (162+686)-set per colour channel of Pevny, Bas and Fridrich,
# plus home-grown variations.
#
#     ::

    V = R.add( spmarkov.dmFeatures(I,label=label) )
    print "SPAM complete. Total %i features" % (len(R))
    # self.addLeaf( dm.dmvector(I), ("DM-162",) )
    for k in V.featureDic.keys():
      R.featureDic[k] = ( V.getname(), k, )

# 4. The Lie-Lin features.
#
#     ::

    R.addLeaf( [ ge.ge(I) ], ("Lie-Lin","GE",) )
    R.addLeaf( [ dct.llfeature(I) ], ("Lie-Lin","DCT",) )
    print "Lie-Lin complete. Total %i features" % (len(R))
    return R

# Features from Colour Images
# ===========================
#
# ::

def cextract(R,im):
   """
   Extract features for a colour image and insert them into
   the given feature vector.
   """
   I = np.array( im )
   S = I.shape
   assert len(S) == 3, "I need a three-channel colour image"
   print "Loaded image %ix%i with %i colour channels" % S
   label = R.getlabel()

   R.add( wam.wamVector(I,label=label) )
   print "WAM complete. Total %i features" % (len(R))
   R.add( harmsen.harVector(I,label=label) )
   print "Harmsen features complete. Total %i features" % (len(R))

   return R

# Features from JPEG Images
# =========================
#
# ::

def featureVector(file,*a,**kw):
   "Create a feature vector object for a JPEG image."

# A JPEG feature vector is based on a regular :func:`baseVector` object,
# adding additional features using the :mod:`jfeatures` package.
# Only the Y component is used.
#
#   ::

   R = baseVector(file,*a,**kw)
   jx.extract(R,jpeg(file),R.label)
   print "[featureVector] Complete. Total %i features" % (len(R))
   return R
