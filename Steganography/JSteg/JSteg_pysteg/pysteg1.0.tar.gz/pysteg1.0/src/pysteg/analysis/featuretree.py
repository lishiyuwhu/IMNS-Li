## $Id$
## -*- coding: utf-8 -*-

print "[pysteg.analysis.featuretree] $Id$"
 
"""
Generic classes for feature vectors.

The module provides the general classes needed for the hierarchical
tree structure of feature vectors.  The structure should be built
such that each feature sets known from the literature is recognised
as a subtree.  This makes it easy to extract subtrees to duplicate
classifier systems from the literature.
"""

# ********************************
# The feature vector datastructure
# ********************************
#   
# :Module:    pysteg.analysis.featuretree
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2009-2010: University of Surrey, UK
#             © 2011: Høgskolen i Ålesund, Norway
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-11)
# 
# .. automodule:: pysteg.analysis.featuretree
# 
# The basic data structure for feature vectors is provided in
# :mod:`pysteg.analysis.featuretree`.
# The feature vectors are organised hierarchically in a tree,
# making it easy to extract subsets corresponding to subtrees.
# This module creates the generic base classes for feature vectors.
# Other modules derive classes including feature extraction methods.
# 
# The following three classes are provided.
# 
# .. autoclass:: fv
# 
# .. autoclass:: leaf
# 
# .. autoclass:: node
#
#   ::

import pickle

# The abstract class
# ==================
# 
# ::

import numpy as np
from copy import copy, deepcopy

class fv(object):
  "The abstract base class for all feature vector trees."
  label = None
  name = None
  featureDic = { }
  _verbosity = 0
  filename = None
  def __init__(self,name=None,label=None,verbosity=0):
    assert self.label == None or label == None or self.label == label
    assert self.name == None or name == None or self.name == name
    self.label = label
    self.name = name
    if self.label == None:
      print "Warning!  No label."
      print type(self), self.name
    elif type(self.label) == str:
      self.label = int(self.label)
    if self.name == None:
      print "Warning!  No name."
      print type(self)
    self._verbosity = verbosity
  def getlabel(self): return self.label
  def getname(self): return self.name
  def setname(self,name): 
    self.name = name
    return self
  def getFileName(self): return self.filename
  def setlabel(self,label): self.label = label
  def setverbosity(self,v): self._verbosity = v
  def getVerbosity(self): return self._verbosity 

# Return a feature vector as a list.  If id is given, it specifies
# a subset of features to include; otherwise all the features are 
# included.  This must be implemented for each derived class::

  def vector(self,id=None):
    raise NotImplementedError, "fv is not intended for instantiation"

# Usually, vector() will not be called externally.  Instead getVector()
# is used, including the label as well as the features::

  def getVector(self,id=None):
    assert self.label != None
    if self._verbosity > 0:
      print "[getVector] entering (verbosity %i) %s" % (self._verbosity,id)
    R = [self.label] + self.vector(id)
    if self._verbosity > 1:
       print "[getVector] %i features" % (len(R)-1,)
    return R

# The following two methods mimics the interface of :class:`testset`,
# generating singleton lists.
#
#   ::

  def getVectors(self,*a,**kw): return [self.getVector(*a,**kw)]
  def getNames(self,*a,**kw):
     """
     Return a list of all the keys (names) of the features in the vector.
     This is simply the generator returned by :meth:`iterNames`,
     converted to a list.
     """
     return list(self.iterNames(*a,**kw))

# Other abstract methods::

  def iterNames(self):
    raise NotImplementedError, "fv is not intended for instantiation"
  def __len__(self):
    raise NotImplementedError, "fv is not intended for instantiation"
  def len(self): return len(self)

# Difference Vector
# -----------------
#
#   ::

  def __sub__(self,right):
    D = deepcopy(self)
    D.subtract(right)
    return D

# The leaf node class
# ===================
# 
# ::

class leaf(fv):
  "A leaf node for the feature vector tree."
  def __init__(self,V,namelist=None,*a,**kw):
    fv.__init__(self,*a,**kw)
    self.features = V
    if namelist != None: 
       if hasattr(V,"flatten"): L = len(V.flatten())
       else: L = len(V)
       assert L == len(namelist),\
	     "Number of names and number of features do not match"
    self.namelist = namelist
  def subtract(self,right):
    """
      Subtract the feature vector given as an argument in place.
      This is primarily used as a helper method for the __sub__()
      method.
    """
    for i in xrange(len(self.features)):
      if isinstance(self.features[i],np.unsignedinteger):
        self.features[i] = int(self.features[i]) - right.features[i]
      else: self.features[i] -= right.features[i]

# The vector() method for leaf nodes is fairly straight forward,
# with no recursion.  However, a leaf node can be a vector,
# holding a list of features, or a scalar which has to be wrapped
# in a list.
# 
#   ::

  def vector(self,id=None):

# The parameter is necessary to be compatible with the standard interface.
# It should always be either None or an empty tuple.
# 
#     ::

    """Return the features as a list."""
    if self._verbosity > 4:
      print "[leaf.vector]", self.getname(), id

# Firstly, if the id is a tuple of one element, we should return
# only one element from the leaf node vector.  The following approach
# is crude, but it avoids handling all the special cases twice.  Instead,
# we rely on the handling for the general case.
#
#   ::

    if isinstance(id,tuple):
       if len(id) == 1:
	  F = self.vector()
	  if self.namelist == None: N = id[0]
	  else: N = self.namelist.index( id[0] )
          return [ F[N] ]
       elif len(id) > 1:
	  raise Exception, "Seeking a multi-step key in a leaf node"
    else:
       assert id == None, \
	  "Calling vector in a leaf, the key should be either a tuple or None"

# Unless a single feature was requested, id should be either None or an
# empty tuple.  Now, we need to consider the many different kinds of features
# this node may hold.
#
#   ::

    if type(self.features) == list:

# We have a list of features.  This should be a list of scalars.
# However, due to a bug in early versions of the HGS features,
# the elements may be 2x2 correlation coefficient arrays.
# Here c[0,1]=c[1,0] and c[1,1]=c[0,0]=1.  Thus we keep only one
# of the entries in this event.
#
#       ::

      if self._verbosity > 2:
        print "[vector]", self.name, "leaf node list", type(self.features[0])
      if isinstance(self.features[0],np.ndarray):
        print "[vector]", self.name, "leaf node with list of arrays"
        return [ c[0,1] for c in self.features ]
      else:
        return self.features

# If we have an array, it will have the :method:`flatten` to
# convert it to a list.  
#
#   ::

    elif hasattr(self.features,"flatten"):
      return list(self.features.flatten())

# Lists and scalars are straight-forward.
#
#   ::

    elif isinstance(self.features,list): return self.features
    elif isinstance(self.features,float): return [self.features]
    elif isinstance(self.features,int): return [self.features]

    # Finally, it might be something we have not prepared for::

    else:
      raise Exception, "cannot handle features of type %s"  \
            % (type(self.features),)

# List keys
# ---------
#
# ::

  def listnames(self,ind="",no=0):
    R = no + self.len()
    print ind,  "%i..%i\t %s" % (no+1,R,self.getname(),)
    if self.namelist != None:
      for i in self.namelist:
        no += 1
        print ind+"  ", i, no
    else: no += self.len()
    return no


  def iterNames(self):
    """
    Make an iterator returning the keys (names) of all the 
    features in the vector.
    """
    nm = self.getname()
    if self.namelist != None: 
       for n in self.namelist: yield (nm,n)
    elif self.len() == 1:
       yield (nm,)
    else:
       for i in xrange(self.len()): yield (nm,i)

# ::

  def __len__(self):
    "Return the number of features in the node."
    if hasattr(self.features,"size"): return self.features.size
    elif isinstance(self.features,float): return 1
    elif isinstance(self.features,int): return 1
    else: return len(self.features)

# The node class
# ==============
#   
# ::

class node(fv):
  "An internal node for the feature vector tree."
  def __init__(self,*a,**kw): 
    fv.__init__(self,*a,**kw)
    self.list = []
    self.index = {}
  def setlabel(self,label):
    """Change the classification label of the feature vector."""
    for v in self.list: v.setlabel(label)
    self.label = label
  def setverbosity(self,v):
    """Change the verbosity level of the object."""
    self._verbosity = v
    for n in self.list: n.setverbosity(v)
  def __len__(self):
    return sum( [ v.len() for v in self.list ] )

# List keys
# ---------
#
# The following method is used to print the names/keys of
# each feature in the vector with numbers, in a hiararchical format.
#
#   ::

  def listnames(self,ind="",no=0):
    print ind, "%i.. \t%s" % (no+1,self.getname(),)
    for i in self.list: 
      no = i.listnames(ind+"  ",no)
    return no

# The final methods produce iterators of all the keys.
#
#   ::

  def iterNames(self,skip=False):
    """
      Return an iterator of the identifiers of each individual
      feature.
    """
    for i in self.list: 
       for x in i.iterNames():
	  if skip: R = x
	  else: R = (self.getname(),) + x
	  yield R
  def listFeatures(self):
    """
      Return an iterator of the identifiers of each individual
      feature with associated index number.
    """
    i = 0
    for x in self.iterNames():
      i += 1
      yield (i,x)
    if self._verbosity > 1:
      print "[listFeatures] complete"

# Adding nodes
# ------------
# 
# ::

  def add(self,V,name=None):
    """Add a node V as a child."""
    if self.index.has_key(name): raise Exception, "key already exists"
    assert isinstance(V,fv), "Trying to add non-node object as a node"
    if name == None: name = V.getname()
    assert V.getname() == name, "Adding node at a key not matching its name"
    self.list.append(V)
    self.index[name] = V
    return V
  def getcreate(self,name):
    """
      Return the child of the given name, creating it if necessary.
    """
    if self.index.has_key(name): return self.index[name]
    else: return self.add(node(name=name,label=self.label),name)
  def addLeaf(self,V,id,namelist=None):
    """
      Add a feature vector V with the id.  V may be either a leaf object,
      or a list or other object convertible as leaf(V).
    """
    if len(id) == 1:
      if type(V) != leaf:
	 V = leaf(V,name=id[0],label=self.label,namelist=namelist)
      else: assert leaf.getlabel() == self.getlabel()
      self.add(V,id[0])
    else:
      N = self.getcreate(id[0])
      N.addLeaf(V,id[1:])

  def getNode(self,id=None):
     """
     Return the node with the given id (key).  The returned object
     should be of class :class:`node`.  It acts recursively, and
     may fail if it reaches a :class:`leaf`.
     """
     if id == None: return self
     if len(id) == 0: return self
     while id[0] == None: id = id[1:]
     if len(id) == 1: return self.index[id[0]]
     return self.index[id[0]].getNode(id=id[1:])

# Returning Features
# ------------------
# 
# ::

  def vector(self,id=None):
    """
    Return a vector containing the feature set id (e.g. "Pevny-Fridrich").
    The id can be a tuple identifying a single component, or a list
    of tuples to include several components.  If the id is a single
    element i it may be given as a scalar, i.e. (i) is equivalent to i.
    If id=None all components are included.
    """
    if self._verbosity > 4:
      print "[node.vector] entering", self.getname(), id, type(self)

# The id may be a list or a tuple.
# A tuple describes the path from the root, to a particular node.
# Each element is the name of one node on the path.
# A list indicates a sequence of independent nodes, and means that
# each element should be looked up independently as an id and
# the results concatenated.
# 
# Recursion is an important element of this method.
# A tuple-id may contain a list as one of its elements, indicating
# that multiple nodes, descending from that point, must be looked
# up and concatenated.
# 
# *Case 1*
# First of all, if no id is given, or the special string "tutti"
# is used, all features should be included.  This is simple::

    if id == "tutti" or id == [ "tutti" ] or id == None \
       or id == ():
      R = []
      if self._verbosity > 4:
        print "[node.vector] Tutti", self.getname(), id
      for l in self.list: R.extend( l.vector() )
      return R

# *Case 2*
# The list id case is handled easily with a loop, calling
# the method recursively for each element::

    elif isinstance(id,list): 
      R = []
      if self._verbosity > 2:
        print "[node.vector] list of length", len(id)
      for i in id: R.extend( self.vector(id=i) )
      return R


# *Case 3*
# The featureDic attribute may indicate a list of aliases for id-s.
# This is often used to have a short hand id for a list of nodes.
# If id exists in this list, we expand the alias and recurse. 
#
#    ::

    elif self.featureDic.has_key( id ):
      if self._verbosity > 2:
        print "[node.vector] using featureDic", id, type(self)
      return self.vector(id=self.featureDic[id])

# *Case 4 (Tuple)*
# If id is a tuple, we look up the first element in the index,
# which may exist either in the featureDic or in the index.
# If it exists in both, index takes presedence.  The featureDic
# entry is likely inherited from the class and supposed to apply
# at the root only.
#
#    ::

    elif isinstance(id,tuple):

# First of all, the key sometimes include dummy None entries at the
# start; we need to strip these.
#
#   ::

      while id[0] == None: id = id[1:]
      if self._verbosity > 2:
         print "[node.vector] Tuple", id, type(self)

# If the first element of the key is in the index, we look up this
# entry and call its :meth:`vector` with the remainder of the key
# as an argument.
#
#   ::

      if self.index.has_key( id[0] ):
        if self._verbosity > 5: print self.index
        return self.index[id[0]].vector(id[1:])

# If the first element is in featureDic, we look up its vector.
# This should only happen as the last element of the key, so
# the remaining key elements should be an empty tuple.
#
#    ::

      elif self.featureDic.has_key( id[0] ):
         if self._verbosity > 2:
           print "[node.vector] using featureDic", id, type(self)
	 assert len(id) == 1, \
	       "Pseudo-keys should only be used as the last element of a tuple"
         return self.vector(id=self.featureDic[id[0]])

# Just as a sanity check, if neither of the two subcases above applied,
# then we have an error.
#
#   ::

      else:
        raise Exception, "First key element (%s) not found" % (str(id[0]),)


# *Case 5 (Scalar)*
# If id is a scalar, we can simply look it up and return its vector::

    else:
      if self._verbosity > 2:
        print "[node.vector] Scalar", id, type(self)
      return self.index[id].vector()

# Difference Vector
# -----------------
#
#   ::

  def subtract(self,right):
    """
      Subtract the feature vector given as an argument in place.
      This is primarily used as a helper method for the __sub__()
      method.
    """
    K = self.index.keys() 
    for k in K:
      self.index[k].subtract( right.index[k] )

# File IO
# -------
#
#   ::

  def dump(self,file=None,protocol=2):
    """
      Save the feature vector in binary format (pickle)
      to the given filename file.  If no filename is
      provided, the source filename stored in the object
      is used with a ".fv" extension.
    """
    if file == None:
       if self.filename == None:
          raise Exception, "Missing filename"
       else: file = self.filename + ".fv"
    f = open ( file, "wb" )
    pickle.dump( self, f, protocol=protocol )
    f.close()
