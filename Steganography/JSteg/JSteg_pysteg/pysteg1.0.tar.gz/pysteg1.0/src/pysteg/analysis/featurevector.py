## $Id$
## -*- coding: utf-8 -*-

"""
Feature vector class for steganalysis, adding some general features
to the :mod:`featuretree` module.
   
:Module:    pysteg.analysis.featurevector
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Høgskolen i Ålesund, Norway
:Author:    Hans Georg Schaathun <georg@schaathun.net> (11)
"""

print "[pysteg.analysis.featurevector] $Id$"

# *******************************
# The Steganalysis Feature Vector
# *******************************
# 
# .. automodule:: pysteg.analysis.featurevector
# 
# The :mod:`featuretree` module provides the datastructure to be 
# used.  
#
# ::

from featuretree import node
from jfeatures.pevny import L2 as localfreq

def l5(m):
   return [ ( "Pevny", m, "local", x, -5 ) for x in localfreq ] \
    + [ ( "Pevny", m, "local", x, 5 ) for x in localfreq ]

# It is important to minimise the number of modules loaded, as this
# module is imported whenever a pickled object is restored from file.
# The different methods required to create the object are put in other
# files which then become superfluous.
#
# ::

class baseVector(node):
  "Class to hold a feature vector for uncompressed grayscale images."

# The featureDic attribute contains a dictionary of pseudo-keys,
# mapping them to full keys describing their position in the tree.
# This is done to support intuitive and standard vectors, where they
# are burried deep in the tree, or possible spread across multiple
# branches.
#
# ::

  featureDic = {

# Pevny's features set, complete as proposed::

    "PEV-219" :   [ ("Pevny", "PEV-219") ],
    "NCPEV-219" : [ ("Pevny", "NCPEV-219") ],
    "CPEV-219" : [ ("Pevny", "CPEV-219") ],
    "CCPEV-219" : [ ("Pevny", "NCPEV-219"),
                    ("Pevny", "CPEV-219") ],
    "CCPEV-438" : [ "CCPEV-219" ],
    "PEV-220" : [ "PEV-219", "JPEG non-zero" ],

# Pevny's averaged Markov features::

    "PM-81" :   [ ("Pevny", "PEV-219", "Markov") ],
    "NCPM-81" :   [ ("Pevny", "NCPEV-219", "Markov") ],
    "CPM-81" :   [ ("Pevny", "CPEV-219", "Markov") ],
    "CCPM-162" : [ "NCPM-81", "CPM-81" ],


# The other features of Pevny::

    "CPEV-138" : [ ("Pevny", "CPEV-219", "global" ),
                  ("Pevny", "CPEV-219", "local" ),
                  ("Pevny", "CPEV-219", "Blockiness" ),
		  ("Pevny", "CPEV-219", "Variation" ),
		  ("Pevny", "CPEV-219", "Cooccurrence" ) ],
    "NCPEV-138" : [ ("Pevny", "NCPEV-219", "global" ),
                  ("Pevny", "NCPEV-219", "local" ),
                  ("Pevny", "NCPEV-219", "Blockiness" ),
		  ("Pevny", "NCPEV-219", "Variation" ),
		  ("Pevny", "NCPEV-219", "Cooccurrence" ) ],
    "PEV-138" : [ ("Pevny", "PEV-219", "global" ),
                  ("Pevny", "PEV-219", "local" ),
                  ("Pevny", "PEV-219", "Blockiness" ),
		  ("Pevny", "PEV-219", "Variation" ),
		  ("Pevny", "PEV-219", "Cooccurrence" ) ],
    "CCPEV-138" : [ "NCPEV-138", "CPEV-138" ],
    "CCPEV-276" : [ "CCPEV-138" ],

# HCF features::

    "HCF-390" : [ "HCF", "JHCF" ],
    "HCF-39" : [ ("HCF","HCF-39",) ],
    "HCF-78" : [ ("HCF","HCF-39",), ("HCF","Pred. Error",), ],

# WAM features::

    "WAM3-27" : [ ("WAM-27","WAM(3)-27",) ],
    "WAM7-27" : [ ("WAM-27","WAM(7)-27",) ],
    "WAMB-27" : [ ("WAM-27","WAM(B)-27",) ],
    "WAM(3)-27" : [ ("WAM-27","WAM(3)-27",) ],
    "WAM(7)-27" : [ ("WAM-27","WAM(7)-27",) ],
    "WAM(B)-27" : [ ("WAM-27","WAM(B)-27",) ],

# Other features::

    "CMA" : [ ("DM","1st order","CMA"), ("DM","2nd order","CMA") ],
    "SPAM" : [ ("DM","1st order","SPAM"), ("DM","2nd order","SPAM") ],
    "CMA1-162" : [ ("DM","1st order","CMA") ],
    "CMA2-686" : [ ("DM","2nd order","CMA") ],
    "SPAM1-162" : [ ("DM","1st order","SPAM") ],
    "SPAM2-686" : [ ("DM","2nd order","SPAM") ],
    "BSM-12" : [ ("BSM","BSM-12",) ],
    "BSM-18" : [ ("BSM","BSM-18",) ],
    "AC-10" : [ ("AC","AC-10",) ],
    "AC-4" : [ ("AC","AC-4",) ],
    "CCCP-54" : [ "CP-27", "CCP-27" ],
    "CCM-486" : [ "Markov", "CalMarkov" ],
    "EM-54" : [ ("EM-108", "EM-54") ],

# The following pseudo-keys are defined to fuse a large set of features::

    "classic" : [ "AC", "SMCM-130",
      "WAM(3)-27", "HCF", "avcibas", "ALE-10", "EM-108", "Farid", "SPAM" ],
    "tutti" : [ "HGS", "AC", "SMCM-130",
      "WAM(3)-27", "HCF", "avcibas", "ALE-10", "EM-108", "Farid", "SPAM" ],
    "jtutti" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", "HCF-390",
      "AC", "SMCM-130",
      "WAM(3)-27", "HCF", "avcibas", "ALE-10", "EM-108", "Farid", "SPAM" ],
    "j2tutti" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", "HCF-390",
      "AC", "WAM(3)-27", "HCF", "ALE-10", "EM-108", "Farid", "SPAM" ],
    "j3tutti" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", "HCF-390",
      "AC", "WAM(3)-27", "ALE-10", "Farid", "SPAM" ],
    "j4tutti" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", "HCF-390" ],
    "j5tutti" : [ "j7tutti", "Farid" ],
    "j6tutti" : [ "j5tutti", "WAM(3)-27", "ALE-10" ],
    "j7tutti" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", "HCF-390",
	  "SPAM" ],
    "jpeg" : [ "CCPEV-438", "Fridrich", "Markov", "CCCP-54", ],

# Finally, we have introduced a few new pseudo-keys to test specific
# fusion combinations::
    "SPAM2-54" : [ "SPAM2-27", "SPAMD-27" ],
    "SPAM2-250" : [ "SPAM2-125", "SPAMD-125" ],
    "SPAM2-343" : [ ("DM","2nd order","SPAM","hv") ],
    "SPAM2-125" : [ ("DM","2nd order","SPAM","hv",49*x+7*y+z)
	    for x in range(1,5) for y in range(1,5) for z in range(1,5) ],
    "SPAMD-125" : [ ("DM","2nd order","SPAM","dm",49*x+7*y+z)
	    for x in range(1,5) for y in range(1,5) for z in range(1,5) ],
    "SPAMD-27" : [ ("DM","2nd order","SPAM","dm",49*x+7*y+z)
	    for x in [2,3,4] for y in [2,3,4] for z in [2,3,4] ],
    "SPAM2-27" : [ ("DM","2nd order","SPAM","hv",49*x+7*y+z)
	    for x in [2,3,4] for y in [2,3,4] for z in [2,3,4] ],
    "SPAM2-64" : [ ("DM","2nd order","SPAM","hv",49*x+7*y+z)
	    for x in [1,2,4,5] for y in [1,2,4,5] for z in [1,2,4,5] ],
    "EMP-54" : [ ("EM-108", "Pred.Error") ],
    "S001"  : [ "SPAM2-686", "EM-108" ],
    "S002"  : [ "SPAM2-686", "EM-108", "WAM(3)-27" ],
    "S003"  : [ "BSM-12", "AC-10" ],
    "S004"  : [ "EM-54", "ALE-10", "BSM-12", "AC-10", "WAM(3)-27" ],
    "S005"  : [ "EM-108", "ALE-10", "BSM-12", "AC-10", "WAM(3)-27" ],
    "S006"  : [ "SPAM2-343", "EMP-54" ],
    "S007"  : [ "EMP-54", "ALE-10", "BSM-12", "AC-10", "WAM(3)-27" ],
    "S008"  : [ "EMP-54", "SPAM2-64" ],
    "S009"  : [ "SPAM2-250", "EM-108", "WAM(3)-27" ],
    "S010"  : [ "SPAM2-27", "EMP-54" ],

    "NCB-2" : [ ("Pevny", "NCPEV-219", "Blockiness" ) ],
    "CB-2" : [ ("Pevny", "CPEV-219", "Blockiness" ) ],
    "DCB-2" : [ ("Pevny", "PEV-219", "Blockiness" ) ],
    "CCB-4" : [ "NCB-2", "CB-2" ],
    "T9B" : [ "T9NC", "NCB-2" ],
    "T9B2" : [ "T9NC", "CCB-4" ],

    # JPEG
    "PEV-L5"    : l5("PEV-219"),
    "NCPEV-L5"  : l5("NCPEV-219"),
    "CPEV-L5"  : l5("CPEV-219"),
    "CCPEV-L5"  : [ "PEV-L5", "CPEV-L5" ],
    "T-PEVWAM3" : [ "PEV-219", "WAM3-27" ],
    "T-PEVWAM7" : [ "PEV-219", "WAM7-27" ],
    "T-PEVWAMB" : [ "PEV-219", "WAMB-27" ],
    "T-PEVCP" : [ "NCPEV-219", "CP", "Fridrich" ],
    "T-PEV-300" : [ "PEV-138", "NCPM-81", "CPM-81" ],
    "T-PEV-192" : [ "PEV-138", "CCCP-54" ],
    "T-PVM" : [ "PEV-138", "Markov" ],
    "T-PEV-219" : [ "PEV-138", ( "DCM-243", "m" ) ],
    "T-PEV-381" : [ "PEV-138", "DCM-243" ],
    "T-762" : [ "CCM-486", "CCPEV-276" ],
    "T-536" : [ "CCM-486", "TCCCM-50" ],
    "T-519" : [ "Markov", "CCPEV-276" ],
    "T-293" : [ "Markov", "TCCCM-50" ],
    "T3HCF" : [ "JHCF", "CCM-486", "TCCCM-50" ],
    "T3HCF1" : [ "JHCF", "TCCCM-50" ],
    "T3HCF2" : [ "JHCF", "CCM-486" ],
    "T5HCF" : [ "JHCF", "CCPEV-438" ],
    "T5HCFNC" : [ "JHCF", "NCPEV-219" ],
    "HGS-131" : [ "NCPM-81", "TCCCM-50" ],  "T4-131" : [ "HGS-131" ],
    "HGS-178" : [ "T6NC", "CCPEV-L5" ],     "T8CC" : [ "HGS-178" ],
    "HGS-180" : [ "T6NC", "CCPEV-L5", ( "Pevny", "NCPEV-219", "Variation" ),
         ( "Pevny", "CPEV-219", "Variation" ) ],
    "T9CC"    : [ "HGS-180" ],
    "HGS-162" : [ "T6NC", "NCPEV-L5", ( "Pevny", "NCPEV-219", "Variation" ),
         ( "Pevny", "CPEV-219", "Variation" ) ],
    "T9NC"    : [ "HGS-162" ],
    "HGS-160" : [ "T6NC", "NCPEV-L5" ], "T8NC" : [ "HGS-160" ],
    "HGS-142" : [ "NCPM-81", "TCCCM-50", ( "Pevny", "PEV-219", "global" ) ],
    "T6NC"    : [ "HGS-142" ],

    "T7" : [ "NCPM-81", "TCCCM-50", "WAM7-27" ],
    "T8X" : [ "T6CC", "CCPEV-L5" ],
    "T8DC" : [ "T6NC", "PEV-L5" ],
    "T9X" : [ "T6CC", "CCPEV-L5", ( "Pevny", "NCPEV-219", "Variation" ),
         ( "Pevny", "CPEV-219", "Variation" ) ],
    "T9NN" : [ "T6NC", "NCPEV-L5", ( "Pevny", "PEV-219", "Variation" ) ],
    "T10X" : [ "T8CC", ( "DCM-243", "m", (-1,0) ) ],
    "T10Y" : [ "T8CC", ( "DCM-243", "m", (-1,0) ),
         ( "Pevny", "CPEV-219", "Variation" ) ],
    "T10Z" : [ "T8CC",
	 ( "Markov", "m", (-1,0) ), ( "CalMarkov", "m", (-1,0) ),
         ( "Pevny", "CPEV-219", "Variation" ) ],
    "T6NC2" : [ "NCPM-81", "TCCCM-50", ( "Pevny", "PEV-219", "global" ),
	    ( "Pevny", "PEV-219", "local" ) ],
    "T6CC" : [ "CCPM-162", "TCCCM-50", ( "Pevny", "PEV-219", "global" ) ],
    "T6CC2" : [ "CCPM-162", "TCCCM-50", ( "Pevny", "PEV-219", "global" ),
	    ( "Pevny", "PEV-219", "local" ) ],
    "T4HCF" : [ "JHCF", "NCPM-81", "TCCCM-50" ],
    "HGS-212" : [ "CCPM-162", "TCCCM-50" ],  "T4CC" : [ "HGS-212" ],
    "T4A131" : [ "PM-81", "TCCCM-50" ],
    "TDCCM-25" : [ ("Pevny", "PEV-219", "Cooccurrence" ) ],
    "TNCCM-25" : [ ("Pevny", "NCPEV-219", "Cooccurrence" ) ],
    "TCCCM-50" : [ ("Pevny", "NCPEV-219", "Cooccurrence" ),
                   ("Pevny", "CPEV-219", "Cooccurrence" ) ],
    "T2-293" : [ "TCCCM-50", "DCM-243", ],
  }
  def __init__(self,file,*a,**kw):
    node.__init__(self,*a,**kw)
    self.filename = file
