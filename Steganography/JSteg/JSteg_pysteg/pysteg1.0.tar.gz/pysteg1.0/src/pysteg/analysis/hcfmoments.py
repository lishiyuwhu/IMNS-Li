## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.hcfmoments
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2009-2010: University of Surrey, UK
:Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-10)

Functions to calculate the HCF features due to Yun Q Shi's group.
This module comprises general functions which can be used both for
the Wavelet domain and for the JPEG domain.
"""

# ##########################
# pysteg.analysis.hcfmoments
# ##########################
# 
# .. automodule:: pysteg.analysis.hcfmoments
 
from ..wtools import getWavelet
import numpy as np
import scipy as sp
from scipy import histogram as hist
import pywt
from featuretree import node

__all__ = [ "predImage", "predError", "cfmFeatures", "hcfGenVector",
            "charFunction", "hcfmoments" ]

def predImage(I):
  """
    Calculate the prediction image x-hat.
  """
  x = I[:-1,:-1]
  rt = I[1:,:-1]
  lt = I[:-1,1:]
  dg = I[1:,1:]
  mn = np.min(np.array([rt,lt]),0)
  mx = np.max(np.array([rt,lt]),0)
  R = rt + lt - dg
  S = ( dg <= mn )
  L = ( dg >= mx )
  R[S] = mx[S]
  R[L] = mn[L]
  return R

def predError(I):
  """
    Return the prediction error image as used by
    Shi, Xuan, Zou, Gao, Yang, Zhang, Chai, Chen, & Chen  (2005).
  """
  return I[:-1,:-1] - predImage(I)

def charFunction(C):
  "Return the characteristic function of C (positive frequencies only)."
  H = sp.fft(C)
  n = len(H) / 2 + 1

# According to /help numpy.fft/, H[0] is the zero frequency 
# which we do not need.  The next n elements are positive
# frequencies and the last n elements are negative frequencies.
# If len(H) is odd, the middle element is both positive and negative.
# This gives the following return value.
#
# ::

  return H[1:n]

def hcfmoments(h,order=[1,2,3]):
  """Calculate the HCF moments of the given orders, given a histogram h."""
  hcf = np.abs( charFunction(h) )
  S = np.sum(hcf)
  N = len(hcf)
  return [ sum( [ (float(k)/(2*N))**i*hcf[k] for k in xrange(N) ] ) / S
           for i in order ]


def cfMoments(C,order=[1,2,3],bins=None):
  "Calculate the moments of the HCF of C."
  if not isinstance(order,list): order = [order]
  R = []
  C = C.flatten()
  if bins == None: bins = max(C) - min(C) + 1
  h = hist(C, bins )[0]
  R.extend( hcfmoments(h,order) )
  return R

def cf2(C):
  """
    Return the absolute value of the 2D characteristic function of C
    (positive frequencies only).
  """
  R = abs(np.fft.fft2(C))
  print type(R), R.shape
  n0 = R.shape[0] / 2 + 1
  n1 = R.shape[1] / 2 + 1
  R = R[1:n0,1:n1]
  h = np.sum( R, axis=0 )
  v = np.sum( R, axis=1 )
  S = np.sum(h)
  return (h/S,v/S)

def hcf(C,order=[1,2,3],bins=None,dir=["h","v","d"]):
  """
    Calculate the moments of the second order HCF-s of C.
  """
  if not isinstance(order,list): order = [order]
  R = []
  if dir == None: return cfMoments(C,order=order,bins=bins)
  elif isinstance(dir,list): 
    for d in dir: R.extend( hcf(C,order,bins,dir=d) )
    return R
  if dir == "v": C = (C[:-1,:].flatten(),C[1:,:].flatten())
  elif dir == "h": C = (C[:,:-1].flatten(),C[:,1:].flatten())
  elif dir == "d": C = (C[:-1,:-1].flatten(),C[1:,1:].flatten())
  else: raise Exception, "Unknown direction"
  if bins == None: bins = np.max(C) - np.min(C) + 1
  (h,v) = cf2( np.histogramdd(C, bins )[0] )
  Nh = len(h)
  Nv = len(v)
  for i in order:
    R.append( sum( [ (float(k)/(2*Nh))**i*h[k] for k in xrange(Nh) ] ) )
    R.append( sum( [ (float(k)/(2*Nv))**i*v[k] for k in xrange(Nv) ] ) )
  return R

def cfmFeatures(I,classification=None,name="haar",order=[1,2,3],level=3,
                dir=None,*a,**kw):
  """
    Calculate the HCF Moments features of the image I.
    Optionally a wavelet name can be given as well.
  """
  w = getWavelet( name )
  if classification == None: R = []
  else: R = [classification]
  R.extend( hcf(I, order=order, dir=dir) )
  for i in xrange(level):
    H = pywt.dwt2( I, w )
    for h in [H[0]] + list(H[1]):
      R.extend( hcf( h,order=order,dir=dir ) )
    I = H[0]
  return R

class hcfGenVector(node):
  """
    An object holding a full feature vector for HCF-39.
  """
  def __init__(self,I,name="HCF",wavelet="haar",
         order=[1,2,3],level=3,dir=None,*a,**kw):
    """
      Calculate the CF moments features of the image I.
    """
    node.__init__(self,name,*a,**kw)
    assert len(I.shape) == 2, "Assumes one colour channel only"
    print "__init__", name, self.len()

    self.addLeaf( hcf(I, order=order, dir=dir), ("Spatial",) )

    w = getWavelet( wavelet )
    for i in xrange(level):
      H = pywt.dwt2( I, w )
      R = []
      for h in [H[0]] + list(H[1]):
        R.extend( hcf(h, order=order, dir=dir) )
      self.addLeaf( R, ("Level %i" %(i+1,),) )
      I = H[0]
    return 
