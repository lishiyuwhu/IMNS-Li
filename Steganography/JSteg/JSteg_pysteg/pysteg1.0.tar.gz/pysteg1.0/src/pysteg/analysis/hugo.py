## $Id$
## -*- coding: utf-8 -*-

"""
Feature vector designed to attack HUGO.
"""

# ************************
# The Hugo Attack Features
# ************************
#   
# :Module:    pysteg.analysis.hugo
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey, UK
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2010)
# 
# .. automodule:: pysteg.analysis.hugo
#
# We need two sibling modules imported: :mod:`featuretree` is for the
# parent class and :mod:`features` is the class for the child nodes
# of the tree.
# 
# ::
 
from featuretree import node
from features import baseVector
import featurevector as fv

# The :mod:`os` module is used to execute external programs,
# and the :func:`fnsplit` function is used to split the directory
# and the filename from a path name.::

import os
from ..tools import fnsplit

# The following function is used to join feature vector ID-s;
# an ID within a subtree can be joined with the ID of the subtree
# to give a global ID::

def joinid(a,b):
  if not isinstance(a,tuple): a = (a,)
  if not isinstance(b,tuple): b = (b,)
  return a + b

# The :class:`hugoVector` class
# =============================

class hugoVector(node):
  "Class to hold a feature vector detecting HUGO."

# The parameters for the Hugo simulator are stored here for easy
# reference.  We may want to make them configurable at a later stage.
#
#   ::

  alpha = 0.4
  tmpdir = "/tmp/"

# We make a local featurDic dictionary to give direct access to
# all ID-s in the standard feature vector.
#
#     ::

  featureDic = {}
  for k in fv.baseVector.featureDic.keys():
      id = fv.baseVector.featureDic[k]
      featureDic[k] = [ joinid("base", i) for i in id ]
      featureDic["HC-" + k] = [ joinid("base", i) for i in id ] \
           + [ joinid("cal", i) for i in id ]
  featureDic["HC-Farid"] = [ ("base","Farid",), ("cal","Farid",) ]
  featureDic["HC-SPAM"] = [ ("base","SPAM",), ("cal","SPAM",) ]
  featureDic["Farid"] = [ ("base","Farid",) ]
  featureDic["SPAM"] = [ ("base","SPAM",) ]
  featureDic["WAM-27"] = [ ("base","WAM-27",) ]

# Constructor
# -----------
#
#   ::

  def __init__(self,file,*a,**kw):
    node.__init__(self,*a,**kw)

# The following is trivial initialisation and diagnostic print-out.
#
#     ::

    self.filename = file
    print "hugoVector() v%i" % (self._verbosity,)

# Adding the standard features is straight forward.
#
#     ::

    self.add( baseVector( file, label=self.label, verbosity=self._verbosity,
              name="base" ) )
              

# Finally, we need to make the calibrated image using an external call
# to the Hugo simulator, and add a second feature vector based on this.
#
# The external command hugo_simulator embeds random data using Hugo.
# We can call this with the :func:`os.system` function.
#     ::

    if self._verbosity > 0: xarg = "-V"
    else: xarg = ""
    os.system( 'hugo_simulator -a %f -i "%s" -O "%s" %s' % (
                self.alpha, file, self.tmpdir, xarg) )

# The hugo_simulator command stores the steganogram in the given
# directory, using the same filename as the cover image.  We need
# to strip the filename from the path name to reconstruct a path name
# for the steganogram.
#     ::

    (d,b,e) = fnsplit(file)
    hugofile = self.tmpdir + b + e
    self.add( baseVector( hugofile, label=self.label, 
                  verbosity=self._verbosity, name="cal" ) )

# To remove the auxiliary file, we simply use rm and the :func:`os.system`
# call.
#     ::

    os.system( 'rm -f "%s"' % (hugofile,) )
