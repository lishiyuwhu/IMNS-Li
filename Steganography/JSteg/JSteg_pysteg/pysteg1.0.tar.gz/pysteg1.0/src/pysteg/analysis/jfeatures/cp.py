##  $Id$
## -*- coding: utf-8 -*-

"""
The CP features of Ainuddin Abdul Wahab.

:Module:    pysteg.analysis.jfeatures.cp
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[pysteg.analysis.jfeatures.cp] $Id$"

# ############################
# pysteg.analysis.jfeatures.cp
# ############################
#
# .. automodule:: pysteg.analysis.jfeatures.cp

from fridrichbase import BRindex
import numpy
from ..featuretree import node

__all__ = [ "cpCount", "cpFeatures", "cp54" ]

def cpTriplets(C,T):
  """
    Given a triplet of frequencies T, and a JPEG coeffient matrix C,
    return a matrix with one row per 8x8 block containing the 
    coefficients corresponding to the frequencies in T.
  """
  s = numpy.size(C)/64
  return numpy.array( [ [ BRindex(C,r,i,j) for (i,j) in T ]
                  for r in range(s) ] )

def cpEvents(C,T):
  M = cpTriplets(C,T)
  return numpy.sign( M[:,1:3] - M[:,0:2] )

def cpCount(C,T):
  """
    Return 9 CP features based on the triplet T of frequencies.

    The result is returned as a 3x3 matrix J[a,b] = P(B|A) where
      a=0 is A=(x<y); a=1 is A=(x=y); a=2 is A=(x>y)
      b=0 is A=(y<z); b=1 is A=(y=z); b=2 is A=(y>z)
    NB!  Can create NaN through division by a zero prior probability.
  """
  M = cpEvents(C,T)
  (l,w) = numpy.shape(M)
  J = numpy.zeros((3,3),dtype=float)
  A = numpy.zeros((3),dtype=int)
  for i in range(l):
    (a,b) = M[i,:] + 1
    assert a >= 0 and a < 3
    assert b >= 0 and b < 3
    A[a] = A[a] + 1
    J[a,b] = J[a,b] + 1
  for a in range(3):
    for b in range(3):
      J[a,b] = J[a,b] / A[a]
  return J

# The following are lists of triplets for calculating the CP features.
# T27 is used for CP-27::

T27 = [ ( (1,0), (2,0), (3,0) ),
        ( (1,1), (2,2), (3,3) ),
        ( (0,1), (0,2), (0,3) ) ]

# T54 is used for the original CP-54::

TX54 = [ ( (4,0), (5,0), (6,0) ),
        ( (4,4), (5,5), (6,6) ),
        ( (0,4), (0,5), (0,6) ) ]
T54 = T27 + TX54

# There are additional sets which should be added at this point.
#
# ::

def cpFeatures(C,Tlist=T27):
  """
    Return a list of the CP features of Ainuddin's.

    By default, the 27-feature set is returned, but the optional
    argument Tlist can be set to any list of frequency triplets for
    other feature sets.
  """
  if hasattr(C,"getCoefMatrix"): C = C.getCoefMatrix()
  R = []
  for T in Tlist: R = R + list( cpCount(C,T).flatten() )
  return R

cp54 = lambda(C) : cpFeatures(C,T54)

def cpNode( C, name="CP-27", label=None, *a, **kw ):
    """
    Create a feature vector node for the conditional probability (CP-27) features.
    """
    R = node( name=name, label=label, *a, **kw )
    R.addLeaf( cpCount(C, ( (1,0), (2,0), (3,0) ) ), ("v",) )
    R.addLeaf( cpCount(C, ( (1,1), (2,2), (3,3) ) ), ("d",) )
    R.addLeaf( cpCount(C, ( (0,1), (0,2), (0,3) ) ), ("h",) )
    return R
