##  $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.jfeatures.extract
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

This module defines a function to create a feature vector
using the hierarchical tree structure of the :mod:`featuretree`.
It includes all the implemented features from the JPEG domain.
"""

print "[pysteg.analysis.jfeatures.extract] $Id$"

# #################################
# pysteg.analysis.jfeatures.extract
# #################################
# 
# .. automodule:: pysteg.analysis.jfeatures.extract
# 
# We need to import all the essential definitions from all the other
# submodules::

from time import clock
from fridrichbase import *
from cp import cpNode
from markov import markovNode
import pevny 
import fridrich
from fridrich import norm
from numpy import array
from jhcf import jhcfVector


def extract(node,J,label=None):
    """
    Extract all the JPEG-based features from the JPEG object J,
    and add them to the feature vector node.

    Only the grayscale ("Y") component is used for feature
    extraction.  The source papers do not consider colour
    images specifically, and some research would be needed to
    determine exactly how to deal with it in each case.
    """
    C1 = J.getCoefMatrix()
    C2 = J.getCalibrated()
    S = J.getSpatial()
    S2 = J.getCalSpatial()
  
    T = { "START" : clock() }

# Pevny-Fridrich
#     ::

    node.add( pevny.pevVector(J, label=label) )
    node.addLeaf( [ list( C1.flatten() <> 0 ).count( True ) ],
      ("JPEG non-zero",) )

  
# CP (3x  3x3 matrices)
#
#    ::

    cp1 = cpNode(C1, name="CP-27", label=label )
    cp2 = cpNode(C2, name="CCP-27", label=label )
    node.add( cp1 )
    node.add( cp2 )
    node.add( (cp1 - cp2).setname( "DCCP-27" ) )
    T["CP"] = clock()
    print "CP:", T["CP"] - T["START"]
  
# Markov (4x  9x9 matrices)
#
#    ::

    m1 = markovNode(C1, name="Markov", label=label )
    m2 = markovNode(C2, name="CalMarkov", label=label )
    node.add( m1 )
    node.add( m2 )
    node.add( (m1 - m2).setname( "DCM-243" ) )
    T["Markov"] = clock()
    print "Markov:", T["Markov"] - T["CP"]
  
# Fridrich
#
#    ::

    tb = max( [ max(abs(C1.flatten())), max(abs(C2.flatten())) ] )
    h1 = array( jpegHistogram( C1, T=tb ), dtype=float )
    h2 = array( jpegHistogram( C2, T=tb ), dtype=float )
    print "h1: %s; h2: %s;" % (h1.shape, h2.shape, ),
    node.addLeaf( norm( h1/norm(h1,1) - h2/norm(h2,1), alpha=1 ),
            ("Fridrich","Histogram") )
    R = h1[(tb-5):(tb+6)] - h2[(tb-5):(tb+6)]
    print "R: %s; tb=%i" % ( R.shape, tb )

    B = blockiness( S, alpha=[1,2] ) - blockiness( S2, alpha=[1,2] ) 
    node.addLeaf( abs(B), ("Fridrich","Blockiness") )
    T["Blockiness"] = clock()
    print "Blockiness:", T["Blockiness"] - T["Markov"]
  
    V = variation(C1) - variation(C2)
    node.addLeaf( abs(V), ("Fridrich","Variation") )
    T["Variation"] = clock()
    print "Variation:", T["Variation"] - T["Blockiness"]
  
# Co-occurrence
#
#    ::

    cm = cooccurrenceMatrix(C1,C2,T=2)
    node.addLeaf( fridrich.cooccurrenceFeatures(cm,2), 
           ("Fridrich","Co-occurrence") )
    T["Co-occurrence"] = clock()
    print "Co-occurrence:", T["Co-occurrence"] - T["Variation"]
  
# Local Histogram
#
#    ::

    tb = max( [ max(abs(C1.flatten())), max(abs(C2.flatten())) ] )
    h1 = array( localHistogram( C1, tb ), dtype=float )
    h2 = array( localHistogram( C2, tb ), dtype=float )
    h = h1 - h2
    L1 = [ (1,2), (2,1), (1,3), (2,2), (3,1) ]
    L2 = L1 + [ (1,4), (2,3), (3,2), (4,1) ]
    node.addLeaf(
        [ norm( fridrich.freqHist(h1,ij) - fridrich.freqHist(h2,ij), alpha=1 ) 
        for ij in L1 ],
        ("Fridrich","localHist") )
    node.addLeaf( [
        norm( fridrich.dualHist(h1,tb+val) 
           - fridrich.dualHist(h2,tb+val), alpha=1 )
        for val in range(-5,6)
      ], ("Fridrich","dualHist") )
    T["lHist"] = clock()
    print "lHist:", T["lHist"] - T["Co-occurrence"]

# JHCF
#     ::

    node.add( jhcfVector(C1, label=label) )
