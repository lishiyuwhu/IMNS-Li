##  $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.jfeatures.fridrich
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net> 

Calculation of Fridrich's original, so-called feature-based
feature set (23 features).
"""

print "[pysteg.analysis.jfeatures.fridrich] $Id$"

# ##################################
# pysteg.analysis.jfeatures.fridrich
# ##################################
#
# .. automodule:: pysteg.analysis.jfeatures.fridrich

__all__ = [ "fridrichFeatures", "norm" ]

from numpy import array,shape
from fridrichbase import *
from ...tools import norm

def gHist(C1,C2):
  T = max( [ max(abs(C1.flatten())), max(abs(C2.flatten())) ] )
  h1 = array( jpegHistogram( C1, T ), dtype=float )
  h2 = array( jpegHistogram( C2, T ), dtype=float )
  return norm( h1/norm(h1,1) - h2/norm(h2,1), alpha=1 )

def freqHist(h,frequency):
  """
    Return the normalised histogram for the given frequency.
    The first input h should be a local histogram matrix as returned
    by localHistogram().
  """
  (i,j) = frequency
  # R = array( [ h[r,i,j] for r in range(-T,T+1) ] )
  R = h[i,j,:]
  n = norm(R)
  if n != 0: R = R / norm(R)
  return R

def dualHist(h,val):
  """
    Return the normalised, so-called dual histogram for the given value
    val.  The first input h should be a local histogram matrix as returned
    by localHistogram().
  """
  # R = array( [ [ h[val,i,j] for i in range(8) ] for j in range(8) ] )
  R = h[:,:,val].flatten()
  n = norm(R)
  if n != 0: R = R / norm(R)
  return R

def lHist(C1,C2):
  """
    Calculate all the local histogram coefficients underlying
    Fridrich's 23-feature set.
  """
  T = max( [ max(abs(C1.flatten())), max(abs(C2.flatten())) ] )
  h1 = array( localHistogram( C1, T ), dtype=float )
  h2 = array( localHistogram( C2, T ), dtype=float )
  return [
      norm( freqHist(h1,ij) - freqHist(h2,ij), alpha=1 )
      for ij in [ (1,2), (2,1), (2,2), (1,3), (3,1) ]
    ] + [
      norm( dualHist(h1,T+val) - dualHist(h2,T+val), alpha=1 )
      for val in range(-5,6)
    ]

def cooccurrenceFeatures(cm,T=1):
  return [
    cm[T-1,T-1],
    sum( cm[T-i,T-j] for (i,j) in [ (0,1), (1,0), (-1,0), (0,-1) ] ),
    sum( cm[T-i,T-j] for (i,j) in [ (1,1), (1,-1), (-1,1), (-1,-1) ] )
  ]

def cFeatures(C1,C2):
  return cooccurrenceFeatures(cooccurrenceMatrix(C1,C2,T=1))

def fridrichFeatures(J,cal=None,pixmap=None,channel="Y",verbose=False):
  """
    Return the Feature Vector of Fridrich's so-called feature-based
    steganalysis.

    The first input can either be a jpeg object J, or a JPEG
    coefficient matrix J.  In the latter case, cal must be given
    as well, as the coefficient matrix of the calibrated image.
  """
  if hasattr(J,"getCoefMatrix"): 
    C1 = J.getCoefMatrix(channel)
    C2 = J.getCalibrated(channel)
    S = J.getSpatial(channel)
    S2 = J.getCalSpatial(channel)
  else:
     raise Exception, "JPEG object required as input"

# Global Histogram (1 feature)::

  if verbose: print "START global histogram"
  g = gHist(C1,C2)
  if verbose:
    print "g =", g
    print type(g)

# Local Histograms (5+11 features)::

  if verbose: print "START local histogram"
  L = lHist(C1,C2)
  if verbose:
    print "L =", L
    print type(L)

# Blockiness (2 features)::

  if verbose: print "START blockiness"
  B = abs( blockiness( S, alpha=[1,2] ) - blockiness( S2, alpha=[1,2] ) )
  if verbose:
    print "B =", B
    print type(B)

# Variation (1 feature)::

  if verbose: print "START variation"
  V = abs(variation(C1) - variation(C2))
  if verbose:
    print "V =", V
    print type(V)

# Co-occurrence (3 features)::

  if verbose: print "START co-occurrence"
  cf = cFeatures(C1,C2)
  if verbose:
    print "cf =", type(cf)
    print cf

  return [ g ] + list(L) + list(B) + [ V ] + cf
