##  $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.jfeatures.fridrichbase
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

Package for feature extraction functions for steganalysis.
Simple implementation is used, quite possibly at the expence
of computational efficiency.
"""

print "[pysteg.analysis.jfeatures.fridrichbase] $Id$"

# ######################################
# pysteg.analysis.jfeatures.fridrichbase
# ######################################
#
# .. automodule:: pysteg.analysis.jfeatures.fridrichbase

__all__ = [
  "blockiness", 
  "variation", "cooccurrenceMatrix", "cooccurrence",
  "localHistogram", "jpegHistogram"
]

from scipy import histogram
import numpy as np
from numpy import array,ceil,floor

# Blockiness

def absdiff(a,b): return abs(float(a)-float(b))

def blockiness0(X,alpha=1):
  "Calculate the blockiness feature given a pixmap matrix X."
  print X.shape
  X = X.astype(float)
  print X[7:-8:8,:].shape, X[8:-7:8,:].shape
  A1 = np.abs(X[7:-8:8,:] - X[8:-7:8,:])**alpha 
  A2 = np.abs(X[:,7:-8:8] - X[:,8:-7:8])**alpha 
  B = np.sum(A1.flatten()) + np.sum(A2.flatten())
  S = A1.size + A2.size
  print S
  return B / S

def blockiness(X,alpha=1,**kw):
  """Calculate the blockiness feature according to Fridrich,
  given a pixmap matrix X."""
  if not isinstance(alpha,list):
     return blockiness0(X,alpha,**kw)
  else: 
     return np.array( [ blockiness0(X,a,**kw) for a in alpha ] )

# 2nd Order Features (Variation and Co-occurrence)

def BRindex(C,r,i,j):
  assert isinstance(r,int)
  (M,N) = array(np.shape(C)) / 8
  B = ( r % M, r / M ) 
  return C[B[0]*8 + i, B[1]*8 + j ]

def BCindex(C,r,i,j):
  assert isinstance(r,int)
  (M,N) = array(np.shape(C)) / 8
  B = ( r / N, r % N ) 
  return C[B[0]*8 + i, B[1]*8 + j ]

def auxVariation(C,r,i,j):
  return abs(BCindex(C,r,i,j)-BCindex(C,r+1,i,j)) + \
         abs(BRindex(C,r,i,j)-BRindex(C,r+1,i,j))

def variation(C):
  """
    Calculate the variation feature according to Fridrich,
    given a JPEG matrix C.
  """
  bc = np.size(C)/64  # Block count
  return sum ( [ float( auxVariation(C,r,i,j) )
            for i in range(8)
            for j in range(8)
            for r in range(bc-1) ] ) / (2*bc)

def cooccurrence(C,T=1):
  """
    Calculate the co-occurrence coefficients for (s,t), -T <= s,t <= T.
    The result is returned as a dictionary.
  """
  R = np.zeros((2*T+1,2*T+1))
  for i in range(8):
    for j in range(8):
      for r in range(np.size(C)/64-1):
        s = BCindex(C,r,i,j)
        t = BCindex(C,r+1,i,j)
	if abs(s) <= T and abs(t) <= T: R[T+s,T+t] = R[T+s,T+t] + 1
        s = BRindex(C,r,i,j)
        t = BRindex(C,r+1,i,j)
	if abs(s) <= T and abs(t) <= T: R[T+s,T+t] = R[T+s,T+t] + 1
  return R / ( np.size(C)/32 )

def cooccurrenceMatrix(C1,C2,T=2):
  """
    Return a callibrated co-occurrence matrix as
    used by Pevny and Fridrich.
  """
  return cooccurrence(C1,T) - cooccurrence(C2,T)

# Histograms

def auxLH(C,i,j,T):
      T = int(T)
      h = histogram( C[i::8,j::8].flatten(),
             array( [ float(i) - 0.5 for i in range(-T,T+2) ] ) )
      return h[0]

def localHistogram(C,T=5):
  """
    Return a localised, three-dimensional histogramme.
    The return value R is a dictionary, so that R[(d,i,j)]
    is the number of coefficients of frequency (i,j) and value d.
    This is the basis for both the frequency-wise histogram and
    the so-called dual histogram of Fridrich.

    The optional parameter calibrated can be the coefficient matrix
    of the calibrated image, in which case the calibrated histogram
    is calculated.

    The result is returned as a matrix R[i,j,r] where (i,j) is
    the frequency, and r-T is the coefficient value.  This is
    not as userfriendly as it should be, as the calling routine
    needs to store T to offset the value when referenced.
  """
  R = array( [ [ auxLH(C,i,j,T) for j in range(8) ] for i in range(8) ] )
  # R[i,j,r] is # of (r+T)-value coefs in position (i,j)
  # -- Not userfriendly at all, as T must be stored by the calling
  # -- routine to interpret the indices
  return R

def jpegHistogram(C,calibrated=None,T=5):
   """
    Return the histogram of the given coefficient matrix for
    values -T..T.

    The optional parameter calibrated can be the coefficient matrix
    of the calibrated image, in which case the calibrated histogram
    is calculated.
   """
   T = int(T)
   h = histogram( C, array( range(-T,T+2) ) - 0.5 )[0]
   if calibrated != None:
     h = h - histogram( calibrated, array( range(-T,T+2) ) - 0.5 )[0]
   return h
