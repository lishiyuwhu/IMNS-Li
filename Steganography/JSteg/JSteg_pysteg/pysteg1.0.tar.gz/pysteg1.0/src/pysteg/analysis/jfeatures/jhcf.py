##  $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.jfeatures.jhcf
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <georg@schaathun.net> 2010

Features due to Yun Q Shi's group, using moments of the
characteristic functions in the wavelet domain.
"""

# ##############################
# pysteg.analysis.jfeatures.jhcf
# ##############################
#   
# .. automodule:: pysteg.analysis.jfeatures.jhcf
#
# ::

from ..featuretree import node
from ..hcfmoments import *
import numpy as np

__all__ = [ "jhcfVector" ]

def jPredError(I):
  """
    Return the prediction error image for the JPEG matrix.
  """
  return I[:-1,:-1] - predJPEG(I)

def predJPEG(I):
  """
    Calculate the prediction image x-hat (for JPEG Images).
  """
  R = predImage(I)
  x = I[:-1,:-1]
  X0 = ( x == 0 )
  R[X0] = 0
  return R

def jhcfVector(im,name="JHCF",label=None,*a,**kw):
   """
   Calculate the CF moments features of the image I and
   return a :class:`node` object.
   (This uses the cfmFeatures() function.)
   """
   J = abs(im)
   R = node(name,label=label,*a,**kw)
   R.addLeaf( cfmFeatures(J), ("JHCF-39",) )
   R.addLeaf( cfmFeatures(jPredError(J)), ("JHCF(PE)-39",) )
   for d in ["h","v","d"]:
      R.addLeaf( cfmFeatures(J,dir=d), ("JHCF2D-234",d,) )
   print "[jhcfVector]", name, len(R)
   return R
