##  $Id$
## -*- coding: utf-8 -*-

"""
Markov model based features according to Shi et al.

:Module:    pysteg.analysis.jfeatures.markov
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net> 
"""

print "[pysteg.analysis.jfeatures.markov] $Id$"

# ################################
# pysteg.analysis.jfeatures.markov
# ################################
#   
# .. automodule:: pysteg.analysis.jfeatures.markov
#
# ::

import numpy as np
from ..markov import *
from ..featuretree import node

__all__ = [ "markovTPM" ]

def markovTPM(C,dir,T=4):
  """
    Return the transition probability matrix given a JPEG object
    or JPEG matrix C, for the given direction dir.
    The result is returned in matrix format.
  """
  if hasattr(C,"getCoefMatrix"): C = C.getCoefMatrix()
  return diffTPM(np.abs(C),dir,T)

def markovNode(C,name,label=None,*a,**kw):
   R = node( name=name, label=label, *a, **kw )
   for dir in [ "h", "v", "d", "m" ]:
      R.addLeaf ( markovTPM(C,dir), id=(dir,),namelist=TPMnames()  )
   return R
