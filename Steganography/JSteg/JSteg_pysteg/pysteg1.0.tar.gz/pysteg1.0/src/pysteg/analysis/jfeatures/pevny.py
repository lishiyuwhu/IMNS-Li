##  $Id$
## -*- coding: utf-8 -*-

"""
Calibrated features according to Pevny and Fridrich.

:Module:    pysteg.analysis.jfeatures.pevny
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <georg@schaathun.net>
"""

print "[pysteg.analysis.jfeatures.pevny] $Id$"

# ###############################
# pysteg.analysis.jfeatures.pevny
# ###############################
#
# .. automodule:: pysteg.analysis.jfeatures.pevny

from fridrichbase import *
from ..featuretree import node,leaf
from numpy import array
from markov import markovTPM, TPMnames

__all__ = [
  "pevVector"
]

# L1 is the set of frequencies used for the histogram h::

L1 = [ (1,2), (2,1), (1,3), (2,2), (3,1) ]

# L2 is the set of frequencies used for the dual histogram g::

L2 = L1 + [ (1,4), (2,3), (3,2), (4,1) ]

def markov(C,channel="Y"):
  return sum( [ markovTPM(C,dir) for dir in [ "v", "h", "d", "m" ] ] ) / 4

# .. autofunction:: ncpev
# 
# ::

def ncpev(J,name="NCPEV-219",T=5,L=L2,label=None,*a,**kw):
    "Create a feature vector object for PEV-219, NCPEV-219, or CCPEV-438."
    R = node(name,label=label,*a,**kw)
    R.featureDic["local5"] = \
	  [ (idx,-5) for idx in L2 ] + [ (idx,5) for idx in L2 ] 

# If the input is a JPEG object, we extract the coefficient matrix
# and decompressed image using inherent methods.
#     ::

    if hasattr(J,"getCoefMatrix"): 
      C = J.getCoefMatrix(channel)
      S = J.getSpatial(channel)

# Otherwise, the input should be a pair (C,S) where C is the coefficient
# matrix and J is a decompressed image.
#
#   ::

    else:
      (C,S) = J

# The different features are calculated and added using other functions,
# in a straight-forward fashion.
#     ::

    R.addLeaf( jpegHistogram( C, T ), ("global",),
	  namelist=range(-T,1+T) )

    R.add( mkLocal( C, L, T, label=label ) )

    R.addLeaf( list(blockiness(S,alpha=[1,2])), ("Blockiness",) )
    R.addLeaf( [variation(C)], ("Variation",) )

    R.add( mkCM(C,T=2,label=label) )
    R.addLeaf( list( markov(C).flatten() ), id=("Markov",),
               namelist=TPMnames() )

    return R

def mkCM( C, T, label=None ):
   """
   Create a feature vector :class:`node` containing the cooccurrence
   features.
   """
   cm = cooccurrence( C, T ) 
   rng = range(-T,T+1) 
   nl = [ (i,j) for i in rng for j in rng ]
   R = leaf( cm.flatten(), namelist=nl, name="Cooccurrence", label=label )
   return R

def mkLocal( C, L, T, label=None ):
   """
   Create a feature vector :class:`node` containing the local histogram
   features.
   """
   R = node( name="local", label=label )
   rng = range(-T,T+1) 
   h = localHistogram( C, T ) 
   for (i,j) in L:
      R.addLeaf( [ h[i,j,r] for r in rng ], ((i,j),), namelist=rng )
   return R

# .. autofunction:: pevVector
# 
# ::

def pevVector(J,name="Pevny",label=None,*a,**kw):
  """
  A feature vector for a collection of related feature vectors
  using calibration, such as for PEV-219, NCPEV-219, and CCPEV-438.
  """
  R = node(name,label=label,*a,**kw)
  assert hasattr(J,"getCoefMatrix"), "Input image is not a JPEG object."
  R.featureDic["CCPEV-438"] = [ "NCPEV-219", "CPEV-219" ]

  channel = "Y"

# The original and calibrated coefficient matrices are extracted from
# the JPEG object.
#     ::

  C1 = J.getCoefMatrix(channel)
  C2 = J.getCalibrated(channel)

# The decompressed and calibrated pixmaps are extracted from
# the JPEG object.
#     ::

  S1 = J.getSpatial(channel)
  S2 = J.getCalSpatial(channel)

# NCPEV-219 is calculated from the original and calibrated images.
#     ::

  F1 = ncpev((C1,S1), label=label )
  F2 = ncpev((C2,S2), "CPEV-219", label=label )

# CCPEV-438 consists of the two feature sets F1 and F2.
#     ::

  R.add( F1 )
  R.add( F2 )

# The original PEV-219 is calculated as the difference of F1 and F2.
#     ::

  R.add( (F1 - F2).setname( "PEV-219" ) )
  return R
