## $Id$
## -*- coding: utf-8 -*-

# #######################
# pysteg.analysis.moments
# #######################
#   
# :Module:    pysteg.analysis.moments
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2009-2010: University of Surrey, UK
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-10)
# 
# .. automodule:: pysteg.analysis.moments
 
import numpy as np

def centralMoment(M,order):
  if type(order) != list: order = [order]
  M = M.flatten()
  M -= np.mean(M)
  N = M.size
  return [ np.sum(M**k)/N for k in order ]
