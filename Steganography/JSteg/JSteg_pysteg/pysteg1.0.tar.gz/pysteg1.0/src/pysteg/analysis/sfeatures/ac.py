##  $Id$
## -*- coding: utf-8 -*-

"""
Calculate the Autocorrelation features of Yadollahpour and Naimi (2009).

:Module:    pysteg.analysis.sfeatures.ac
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <georg@schaathun.net>
"""

# ############################
# pysteg.analysis.sfeatures.ac
# ############################
#   
#
# .. automodule:: pysteg.analysis.sfeatures.ac

import numpy as np
from ..featuretree import node

__all__ = [ "acVector" ]

def acfeature(A,idx=(1,0)):
   return correlate( 2*(A%2).astype(int) - 1, idx=idx )

def correlate(A,B=None,idx=(0,0)):
  if B == None: B = A
  else: assert A.shape == B.shape, "Requires arrays of equal size" 
  (M,N) = A.shape
  (x,y) = idx
  X = A[x:,y:] 
  Y = B[:M-x,:N-y] 
  R = np.sum(X*Y)
  print "[correlate]", idx, "returning", R
  return R

class acVector(node):
  "An object holding an autocorrelation feature vector."
  idxs = reduce ( list.__add__,
                  [ [((i,j),) for j in xrange(4-i) ] for i in xrange(4) ] )
  xidx = [ ((3,1),), ((1,3),) ]

# All the id-s in the featureDic lists are tuples of a single tuple.
# This is necessary to avoid the co-ordinate pairs to be interpreted
# as a multi-step id in the vector() method.
#
#   ::

  featureDic = {
    "AC-4" : [ ((1,1),), ((2,1),), ((1,2),), ((3,1),) ],
    "AC-10" : idxs,
  }
  def __init__(self,I,name="AC",idx=None,*a,**kw):
    """
      Calculate the autocorrelation features of the image I.
    """
    node.__init__(self,name,*a,**kw)
    assert len(I.shape) == 2, "Assumes one colour channel only"
    print "__init__", name, self.len()
    self.dict = {}
    L = (I%2).astype(int) * 2 - 1
    for id in self.idxs + self.xidx:
      self.addLeaf( correlate( L, idx=id[0] ), id )
    return 
