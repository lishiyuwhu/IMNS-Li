##  $Id$
## -*- coding: utf-8 -*-

# #############################
# pysteg.analysis.sfeatures.ale
# #############################
#   
# .. module:: pysteg.analysis.sfeatures.ale
#   
# :Module:    pysteg.analysis.sfeatures.ale
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>
#
# ::

from ..featuretree import node
from ..markov import cooccurrence
import numpy as np

# 1D ALE features
# ===============

def alepts(h,S):
   """
   Return a list of local extrema on the histogram h
   restricted to the set S.
   """
   return [ x for x in S if (h[x] - h[x-1])*(h[x] - h[x+1]) > 0 ]
def alef1(h,E):
   "Calculate the ALE feature based on the list E of local extrema."
   return sum( [ abs(2*h[x] - h[x-1] - h[x+1]) for x in E ] )
def ale1d(I):
   """Return the first-order ALE features f_1 and f_2."""
   h = np.histogram(I.flatten(),bins=list(xrange(257)))[0]
   E1 = alepts(h,xrange(3,253))
   f1 = alef1(h,E1)
   E2 = alepts(h,[1,2,253,254])
   f2 = alef1(h,E2)
   return [f1,f2]
def ale0(I):
   """Return the original ALE feature f_0."""
   h = np.histogram(I.flatten(),bins=list(xrange(257)))[0]
   E0 = alepts(h,xrange(1,255))
   f0 = alef1(h,E0)
   return f0

# 2D ALE features
# ===============

def andf(x,y):
   return x&y

def ale2d(I,dir):
  h = cooccurrence(I,dir)[0]
  A = h[1:-1,1:-1]
  AT = [h[:-2,1:-1],h[2:,1:-1],h[1:-1,:-2],h[1:-1,2:]]
  T  = reduce( andf, [ ( A < x ) for x in AT ] )
  T |= reduce( andf, [ ( A > x ) for x in AT ] )
  T &= T.transpose()
  X = sum( np.abs(4*A[T] - sum( [ x[T] for x in AT ] )) )
  (M,N) = h.shape
  assert M == N
  d = sum( [ h[k,k] for k in xrange(M) ] )
  return [X,d]

# The ALE feature vector
# ======================

class aleVector(node):
  """An object holding an ALE-10 vector. """
  def __init__(self,I,name="ALE-10",*a,**kw):
    node.__init__(self,name,*a,**kw)
    self.addLeaf( ale1d(I), ("1D",) )
    for dir in [ "h", "v", "d", "m" ]:
      self.addLeaf( ale2d(I,dir), ("2D (%s)" % (dir,),) )
    return
