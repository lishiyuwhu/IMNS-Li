##  $Id$
## -*- coding: utf-8 -*-

"""
  Feature extraction according to
  Avcibas, Memon and Sankur: `Steganalysis Using Image Quality Metrics'
  IEEE Trans. Image Proc. vol. 12(2) February 2003 pp 221+.
"""

# #################################
# pysteg.analysis.sfeatures.avcibas
# #################################
#
# .. automodule:: pysteg.analysis.sfeatures.avcibas
#   
# :Module:    pysteg.analysis.sfeatures.avcibas
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>


import numpy as np
import scipy as sp
from PIL import ImageFilter,Image
from tools import *
from ...imtools import dct2, idct2

stdLambda = 0.01

#__all__ = [ "iqFeatures", "iqFeatureNames" ]

# Filtering operations::

def filt(sigma=0.5,mask=3):
  """
    Create the kernel (numpy array) for the Gaussian smoothing 
    operation used by Avcibas et al.
  """
  K = 1/(2*sp.pi*sigma**2)
  assert mask % 2 == 1
  mx = int(mask/2)
  return np.array( [ [ K*sp.exp( -(m**2+n**2)/(2*sigma**2) )
     for m in xrange(-mx,mx+1) ]
     for n in xrange(-mx,mx+1) ] )

def imFilter(*a,**kw):
  """
    Create a PIL ImageFilter for the Gaussian smoothing 
    operation used by Avcibas et al.
  """
  return ImageFilter.Kernel((3,3),filt(*a,**kw).flatten())

def H(I):
  """
    Given a PIL Image object I, return a pair of numpy array images
    where the first image is I and the second image is I filtered
    with a Gaussian filter.
  """
  return (np.array(I,dtype=float),np.array(I.filter(imFilter()),dtype=float))

# Auxiliary operations::

def spatialsum(I):
  """
    Sum an image over the spatial dimensions.
    Return an array with one element per colour channel.
  """
  return np.sum(np.sum(I,0),0)

def spatialnorm(X,alpha=1):
  """Calculate the L_alpha norm for each colour channel of X."""
  return spatialsum( abs(X)**alpha )**(1.0/alpha)

def cnorm(X,alpha=1):
  """Calculate the alpha-norm of X averaged over the colour channels."""
  return np.mean(spatialnorm(X,alpha))

# Minkowsky measures::

def minkowsky(I,J=None,gamma=1):
  """
    Avcibas' so-called Minkowsky Measures of the image pair (I,J).  
    If J is None, I shold be a PIL image object and J is
    calculated by applying a Gaussian filter on I.
    Otherwise, I and J should be numpy arrays.

    This is grayscale-safe.
  """
  if J == None: (I,J) = H(I)
  D = abs(I - J)**gamma
  (M,N) = D.shape[:2]
  C = ( spatialsum(D) / (M*N) ) ** (1/gamma)
  return np.sum(C)/ncol(D)

# Correlation measures::

def elmin(I,J):
  """ 
    Return the element-wise minimum of I and J, where I and J
    are arbitrary numpy arrays.
  """
  return np.min( np.array( [ I,J ] ), axis=0 )

def pixnorm(I):
  """Return the pixel norms."""
  if len(I.shape) == 2: return abs(I)
  else: return np.sum( I**2, 2)**(0.5)

def pixprod(I,J):
  """Return the pixel norms."""
  P = I*J
  if len(I.shape) == 2: return P
  else: return np.sum( P, 2 )

def M3(I,J=None):
  """
    Avcibas' M3 feature (Czekanowski distance).

    This is grayscale safe, although it is not a single-channel
    feature averaged over the colour channels.
  """
  if J == None: (I,J) = H(I)
  (M,N) = I.shape[:2]
  S = I + J
  Mn = elmin(I,J)
  if len(I.shape) > 2:  # Add up over the colour channels
    Mn = np.sum(Mn,2)
    S = np.sum(S,2)
  Mn = 1 - 2*Mn / S
  Mn[ ( S == 0 ) ] = 0
  return (1/N*M) * np.sum( Mn )

def pixangle(I,J):
  """Calculate pixel-wise angles between two images I and J."""
  return sp.arccos( pixprod(I,J)/(pixnorm(I)*pixnorm(J)) )

def M4(I,J=None):
  """
    Avcibas' M4 feature (angular correlation).

    This feature is meaningless for grayscale images (always 0).
  """
  if J == None: (I,J) = H(I)
  if ncol(I) == 1: return 0
  (M,N) = I.shape[:2]
  return 1 - (2.0/N*M) * np.sum( pixangle(I,J) ) / sp.pi

def M5(I,J=None):
  """
    Avcibas' M5 feature (image fidelity).
    
    This is grayscale-safe.
  """
  if J == None: (I,J) = H(I)
  return 1 - np.sum( spatialsum( (I-J)**2 ) / spatialsum( I**2 ) )/ncol(I)

def M6(I,J=None):
  """
    Avcibas' M6 feature (normalised cross-correlation).
    
    This is grayscale-safe.
  """
  if J == None: (I,J) = H(I)
  return np.sum( spatialsum( I*J ) / spatialsum( I**2 ) )/ncol(I)

# Spectral measures 

def M7(I,J=None):
  """
    Avcibas' M7 feature.

    This is grayscale-safe.
  """
  if J == None: (I,J) = H(I)
  F = np.fft.fft2(I,axes=(0,1))
  G = np.fft.fft2(J,axes=(0,1))
  S = np.prod(I.shape)
  return np.sum( (abs(F) - abs(G))**2 ) / S

def getBlocks(I,b=32):
  """
    Split an image I (numpy array format) into b times b blocks.
    Return a list of numpy arrays.
  """
  (M,N) = I.shape[:2]
  nc = ncol(I)
  (m,n) = ( M % b , N % b )
  (m0,n0) = ( m/2, n/2 )
  if nc == 1: return [ I[i:(i+b),j:(j+b)]
     for i in xrange(m0,M,b)
     for j in xrange(n0,N,b) ]
  else: return [ I[i:(i+b),j:(j+b),:]
     for i in xrange(m0,M,b)
     for j in xrange(n0,N,b) ]

def pb(Ib,Jb):
  If = np.fft.fft2(Ib,axes=(0,1)) 
  Jf = np.fft.fft2(Jb,axes=(0,1))
  M = cnorm( abs(If) - abs(Jf) , 2 )
  phi = cnorm( abs(phase(If)) - abs(phase(Jf)) , 2 )
  return (M,phi)

def getJ0(I,J,gamma=2):
  return map( lambda x,y : pb(x,y), getBlocks(I), getBlocks(J) )

def getJ(I,J,gamma=2):
  L = getJ0(I,J,gamma)
  return ( [ x for (x,y) in L ],[ y for (x,y) in L ] )

def Jlambda(Jm,Jphi,l):
  """Given J^l_M and J^l_phi, calculate J^l."""
  # check order of variables
  return map( lambda x,y : l*x+(1-l)*y, Jm, Jphi )

def M8(I,J=None):
  """Avcibas' M8 feature.  This is grayscale-safe"""
  if J == None: (I,J) = H(I)
  (A,B) = getJ(I,J)
  return np.median(B) 

def M89(I,J=None,l=stdLambda):
  """Avcibas' M8 and M9 features.  This is grayscale-safe"""
  if J == None: (I,J) = H(I)
  (A,B) = getJ(I,J)
  return [ np.median(B), np.median(Jlambda(A,B,l)) ]

# HVS based measure::

def h(rho):
  """The HVS mask used in the HVS() function."""
  if rho < 7: return 0.05*sp.exp(rho ** 0.554 )
  else: return sp.exp( -9 * abs( np.log10(rho) - np.log10(9) ) ** 2.3 )

def HVS(I):
  """Apply the HVS filter on the image I."""
  F = dct2(I)
  (M,N) = I.shape
  for u in xrange(M):
    for v in xrange(N):
      F[u,v] *= h(np.sqrt(u^2+v^2))
  return idct2( F )
  
def M10gray(I,J):
  """
    HVS based measure of a grayscale image (Avcibas' M10 feature).
  """
  F = HVS(I)
  G = HVS(J)
  return spatialsum( (F-G) ** 2 ) / spatialsum( F**2 )
  # return np.sum( spatialsum( (F-G) ** 2 ) / spatialsum( F**2 ) ) / ncol(I)
 
def M10(I,J=None):
  """
    HVS based measure (Avcibas' M10 feature).
    This is grayscale-safe.
  """
  if J == None: (I,J) = H(I)
  if ncol(I) == 1: return M10gray(I,J)
  else:
    return np.mean( [ M10gray(I[:,:,i],J[:,:,i]) for i in xrange(ncol(I)) ] )

# Main feature vector return::

def iqFeatures(I,J=None,l=stdLambda):
  """
    Return the Avcibas features of image I.
    If J is given, both I and J should be numpy arrays and J should
    be the smoothed version of I.
    Normally, only I is given, in which case it should be a PIL image object.
  """
  print "iqFeatures()", type(I), type(J)
  if J == None: (I,J) = H(I)
  R = []
  R.append( minkowsky(I,J,gamma=1) )
  R.append( minkowsky(I,J,gamma=2) )
  R.append( M3(I,J) )
  R.append( M4(I,J) )
  R.append( M5(I,J) )
  R.append( M6(I,J) )
  R.append( M7(I,J) )
  R.extend( M89(I,J,l) )
  R.append( M10(I,J) )
  return R

def iqFeatureNames(l=None):
  """Return a list of feature names for the Avcibas' 10-feature set."""
  R = []
  R.append( "Minkowsky gamma=1" )
  R.append( "Minkowsky gamma=2" )
  R.append( "Czekanowski distance (M3)" )
  R.append( "Angular correlation (M4)" )
  R.append( "Image fidelity (M5)" )
  R.append( "Normalised cross-correlation (M6)" )
  R.append( "Global Spectral Measure (M7)" )
  R.append( "Local Spectral Phase (M8)" )
  R.append( "Local Spectral Mixed Feature lambda=%s (M9)" % l )
  R.append( "HVS based feature (M10)" )
  return R
