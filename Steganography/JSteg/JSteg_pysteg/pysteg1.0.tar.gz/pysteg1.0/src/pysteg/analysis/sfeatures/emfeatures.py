##  $Id$
## -*- coding: utf-8 -*-

# ####################################
# pysteg.analysis.sfeatures.emfeatures
# ####################################
#   
# .. module:: pysteg.analysis.sfeatures.emfeatures
# 
# :Module:    pysteg.analysis.sfeatures.emfeatures
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>
# 
# ::

from ..hcfmoments import predError, hcfmoments
from ..markov import cooccurrence,differenceMatrix
import numpy as np
from ..featuretree import node

def emfeatures(I,dir,order=[1,2,3],verbosity=0):

# The difference matrix is calculated in the same way as for 
# other feature vectors.
#
#   ::

  m = np.int32(np.max(I))
  D = differenceMatrix(I,dir,T=None)

# The histogram is calculated with a bin size of 1.
# We need a normalised histogram, so we convert to double and divide
# by its sum.
#
#   ::

  (h,b) = np.histogram(D,bins=list(xrange(-m,m+2)))
  h = h.astype( np.double ) / sum( h )
  if verbosity > 3: print zip(h,b)

# Finally, we calculate the moments.
#
#   ::

  m1 = [ sum([ k**i*h[k] for k in xrange(-m,m+1) ]) for i in order ]
  m2 = hcfmoments(h,order=order)
  return (m1,m2)

# Main Class
# ==========
#
# ::

class emVector(node):
  "An object holding an EM feature vector."
  Delta = reduce ( list.__add__,
                   [ [(i+1,0),(i+1,i+1),(0,i+1)] for i in xrange(3) ] )
  def __init__(self,I,name="EM-54",order=[1,2,3],dir=None,*a,**kw):
    "Calculate the CF moments features of the image I."
    node.__init__(self,name,*a,**kw)
    assert len(I.shape) == 2, "Assumes one colour channel only"
    print "__init__", name, self.len(), "v%i" % (self._verbosity,)
    if name == "EM-108":
      self.add( emVector( I, name="EM-54", order=order,dir=dir,*a,**kw) )
      self.add( emVector( predError(I), name="Pred.Error",
                order=order,dir=dir,*a,**kw) )
    elif dir == None:
      for dir in self.Delta:
        self.add ( emVector(I,name=str(dir),order=order,dir=dir,*a,**kw) )
    else:
      (m1,m2) = emfeatures(I,dir,order,verbosity=self._verbosity)
      self.addLeaf( m1, ("Hist",) )
      self.addLeaf( m2, ("HCF",) )
    return 
