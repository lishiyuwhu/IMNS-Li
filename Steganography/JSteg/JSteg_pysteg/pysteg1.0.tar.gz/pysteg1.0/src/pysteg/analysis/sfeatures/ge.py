##  $Id$
## -*- coding: utf-8 -*-

# ############################
# pysteg.analysis.sfeatures.ge
# ############################
#
# .. module:: pysteg.analysis.sfeatures.ge
#   
# :Module:    pysteg.analysis.sfeatures.ge
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>


import numpy as np

def ge(I):
  """
    Return the Gradient Power feature according to Lie and Lin (2005).
  """
  R = np.sum( ( I[1:,:] - I[:-1,:] ) ** 2 )
  R += np.sum( ( I[:,1:] - I[:,:-1] ) ** 2 ) 
  R /= I.size
  return R
