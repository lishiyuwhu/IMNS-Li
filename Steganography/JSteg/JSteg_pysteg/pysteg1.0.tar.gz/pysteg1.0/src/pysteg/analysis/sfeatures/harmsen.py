##  $Id$
## -*- coding: utf-8 -*-

# #################################
# pysteg.analysis.sfeatures.harmsen
# #################################
#
# .. module:: pysteg.analysis.sfeatures.harmsen
#   
# :Module:    pysteg.analysis.sfeatures.harmsen
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>


import numpy as np
from ..hcfmoments import hcfmoments
from ..featuretree import node

# Auxiliary functions
# -------------------
#
# So far, the auxiliary functions have been designed for colour images.
# Yet some of them are generic and may be reused.
# 
# ::

def hcfm(H):
  print H.shape
  assert len(H.shape) == 1
  return sum( [ i*H[i]/256 for i in xrange(H.shape[0]) ] )

def hcom(H1):
  """Calculate the centre of mass of a multi-dimensional HCF H."""
  K = len(H1.shape)
  R = []
  if K == 3: H = H1[0:129,0:129,0:129]
  elif K == 2: H = H1[0:129,0:129]
  else: raise Exception, "Only implemented support for 2-D and 3-D HCF."
  S = np.sum(H)
  if K == 2: 
    R = [ hcfm( np.sum(H,1) )/S, hcfm( np.sum(H,0) )/S ]
  else:
    R = []
    A = np.sum( H, K-1 )
    R.append( hcfm( np.sum(A,1) )/S )
    R.append( hcfm( np.sum(A,0) )/S )
    A = np.sum( H, 1 )
    R.append( hcfm( np.sum(A,0) )/S )
  return R

def hdd(L):
  """
  Given a list L of arrays, calculate the HCF-COM based on the joint
  histogram of the elements of L.
  All the arrays must be 8-bit unsigned integers.
  """
  assert L[0].dtype == np.uint8, \
	"Only 8-bit (24-bit) images are supported (got %s)." % (L[0].dtype,)
  bins = tuple([ list(xrange(257)) for i in L ])
  L = [ X.flatten() for X in L ]
  h = np.histogramdd( L, bins=bins )[0]
  H = np.fft.fftn(h)
  return hcom(H)

def h1d(I):
  """
    Calculate the HCF-COM of a grayscale image or single colour channel I.
  """
  assert I.dtype == np.uint8, \
	"Only 8-bit (24-bit) images are supported (got %s)." % (I.dtype,)
  h = np.histogram(I,bins=list(xrange(257)))[0]
  return hcfmoments(h,order=[1])

# Harmsen features for colour images
# ----------------------------------
#
# The following functions and feature vector class provide the raw
# Harmsen features (uncalibrated) for colour images.
#
# ::

def har1d(I):
  """Return the HAR1D-3 feature vector of I as a list."""
  assert len(I.shape) == 3, "This is not a colour image"
  return [ h1d(I[:,:,i]) for i in xrange(3) ]

def har2d(I):
  """Return the HAR2D-6 feature vector of I as a list."""
  assert len(I.shape) == 3, "This is not a colour image"
  (R,G,B) = (I[:,:,0],I[:,:,1],I[:,:,2])
  return  hdd((R,B)) + hdd((R,G)) + hdd((B,G))

def har3d(I):
  """Return the HAR3D-3 feature vector of I as a list."""
  assert len(I.shape) == 3, "This is not a colour image"
  return hdd( (I[:,:,0],I[:,:,1],I[:,:,2]) )

class harVector(node):
  def __init__(self,I,name="Harmsen",*a,**kw):
    assert len(I.shape) == 3, "This is not a colour image"
    assert I.shape[2] == 3, "I need exactly three colour channels"
    node.__init__(self,name,*a,**kw)
    print "__init__", name, self.len()
    self.addLeaf( har1d(I), ("HAR1D-3",) )
    self.addLeaf( har2d(I), ("HAR2D-6",) )
    self.addLeaf( har3d(I), ("HAR3D-3",) )
    print self.len()
    return

# Adjacency HCF for grayscale images
# ----------------------------------
#
# ::

def hcf2h(X):
  "Form the horizontal adjacency HCF from the pixmap matrix X."
  assert X.dtype == np.uint8, \
	"Only 8-bit (24-bit) images are supported (got %s)." % (X.dtype,)
  bins = tuple([ list(xrange(257)) for i in [0,1] ])
  L = [ X[:,:-1].flatten(), X[:,1:].flatten() ]
  h = np.histogramdd( L, bins=bins )[0]
  return np.fft.fftn(h)

def hcf2feature(X):
  "Return Ker's 2D adjacency COM-HCF of the pixmap image X."
  H = np.abs(hcf2h(X))
  D = np.sum(H)
  N = 0
  for i in xrange(256): 
    for j in xrange(256):
      N += (i+j)*float(H[i,j])
  return N/D

def estHistogram(h1,h2):
   """
   Estimate the histogram of a sum X1+X2, given the histograms
   of h1 and h2 of two indpendent variables  X1 and X2 respectively.
   The calculation uses an FFT transform as suggested by Harmsen's results.
   """
   H1 = np.fft.fft(h1)
   H2 = np.fft.fft(h2)
   return np.fft.ifft( H1*H2 )
