##  $Id$
## -*- coding: utf-8 -*-

"""
The SPAM features.

:Module:    pysteg.analysis.sfeatures.markov
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <georg@schaathun.net>

This module uses the :mod:`pysteg.analysis.markov` module for
most of the logics.  See the comments about integer overflow/underflow
risk in the docs for that module.
"""

print "[pysteg.analysis.sfeatures.markov] $Id$"

# ################################
# pysteg.analysis.sfeatures.markov
# ################################
#   
# .. automodule:: pysteg.analysis.sfeatures.markov
# 
# ::

import numpy as np
from ..markov import *
from ..featuretree import node

__all__ = [ "spamFeatures" ]

# The SPAM Class
# ==============
# 
# ::

class dmFeatures(node):
  "A feature vector for the SPAM features."
  nl = { 1 : "1st order" , 2 : "2nd order" }
  col = { 0 : "Red", 1 : "Green" , 2 : "Blue" }
  D1 = [ "h", "hr", "v", "vr" ]
  D2 = [ "d", "dr", "m", "mr" ]
  forward = [ "h", "v", "d", "m" ]
  backward = [ "hr", "vr", "dr", "mr" ]
  featureDic = {
    "SPAM1-162" : [ ( "SPAM", "1st order", ) ],
    "SPAM2-686" : [ ( "SPAM", "2nd order", ) ],
    "SPAM-948" : [ "SPAM1-162", "SPAM2-686" ],
    "CM1-162" : [ ( "CMA", "1st order", ) ],
    "CM2-686" : [ ( "CMA", "2nd order", ) ],
    "CM-948" : [ "CM1-162", "CM2-686" ],
    "CM1-324" : [ ( "CM", "1st order", ) ],
    "CM2-1372" : [ ( "CM", "2nd order", ) ],
    "CM-1896" : [ "CM1-324", "CM2-1372", ],
  }

  def __init__(self,I,name=None,label=None,order=None,T=None):
    if name == None:
      if order == None: name = "DM"
      else: name = self.nl[order]

    node.__init__(self,name=name,label=label)

# Recurse for 1st and for 2nd order.
#    ::

    if order == None:
      self.add( dmFeatures(I,label=label,order=1) )
      self.add( dmFeatures(I,label=label,order=2) )
      return None

# If we have a colour image, we recurse for each channel.
#    ::

    elif len(I.shape) > 2:
      for i in [0,1,2]:
        self.add( dmFeatures(I[:,:,i],name=self.col[i],order=order) )
      return None

# Now, we know that we have one colour channel and one order to deal with.
# 
#    ::

    self.tpm = {}
    self.cm = {}
    if T == None and order == 1: T = 4
    elif T == None: T = 3
    for d in self.forward:
      (tpm,cm) = diffTPM( I, d, T, order=order, CM=True ) 
      self.tpm[d] = tpm
      self.cm[d] = cm
    for d in self.backward:
      tpm = diffTPM( I, d, T, order=order )
      self.tpm[d] = tpm
    
    for d in self.forward:
      self.addLeaf( self.cm[d], ("CM",d,) )
    self.addLeaf( self.cm["h"] + self.cm["v"], ("CMA","hv",) )
    self.addLeaf( self.cm["d"] + self.cm["m"], ("CMA","dm",) )

    self.addLeaf( sum( [self.tpm[d] for d in self.D1 ] ) / 4,
                  ( "SPAM", "hv", ) )
    self.addLeaf( sum( [self.tpm[d] for d in self.D2 ] ) / 4,
                  ( "SPAM", "dm", ) )

    return None

# Functions
# =========
# 
# .. function:: markovFeatures(C,T=None,order=1)
#   
# ::

def markovFeatures(C,T=None,order=1):
  """
    Return the SPAM feature vector of Pevny-Bas-Fridrich of the given
    order using the given cap T.  The returned features are given as a list.
  """
  if T == None and order == 1: T = 4
  elif T == None: T = 3
  D1 = [ "h", "hr", "v", "vr" ]
  D2 = [ "d", "dr", "m", "mr" ]
  L = markovList(C,D1,T,order) + markovList(C,D2,T,order)
  print "markovFeatures(): %i features" % (len(L),)
  return L

def markovList(C,dirs,T,order=1):
  return list(markovAux(C,dirs,T,order=order).flatten())

def markovAux(C,dirs,T,order=1):
  return sum( [ diffTPM( C, dir, T, order=order ) for dir in dirs ] ) / 4
