##  $Id$
## -*- coding: utf-8 -*-

"""
An attempt to defeat HUGO by computing SPAM features for two image subsets,
based on the likelihood of a pixel containing hidden data.
"""

# ######################################
# pysteg.analysis.sfeatures.maskedmarkov
# ######################################
#
# :Module:    pysteg.analysis.sfeatures.maskedmarkov
# :Date:      $Date$
# :Revision:  $Revision$
# :Author:    2010: Johann A Briffa <j.briffa@surrey.ac.uk>
#             Hans Georg Schaathun <georg@schaathun.net>
#
# .. automodule:: pysteg.analysis.sfeatures.maskedmarkov
#
# Note: this module is a work-in-progress;
# ::

import numpy as np
from ..markov import *
from ..markov import dirSplit3
from ..featuretree import node

__all__ = [ "maskedmarkovFeatures" ]

# The Class for SPAM features on image subsets
# ============================================
#
# ::

class maskedmarkovFeatures(node):
  "A feature vector for the SPAM features of two image subsets."
  nl = { 1 : "1st order" , 2 : "2nd order" }
  col = { 0 : "Red", 1 : "Green" , 2 : "Blue" }
  D1 = [ "h", "hr", "v", "vr" ]
  D2 = [ "d", "dr", "m", "mr" ]
  forward = [ "h", "v", "d", "m" ]
  backward = [ "hr", "vr", "dr", "mr" ]
  featureDic = {
    "SPAM1-162" : [ ( "SPAM", "1st order", ) ],
    "SPAM2-686" : [ ( "SPAM", "2nd order", ) ],
    "SPAM-948" : [ "SPAM1-162", "SPAM2-686" ],
  }

  def __init__(self,I,M=None,name=None,label=None,verbosity=2,order=None,T=None):
    if name == None:
      if order == None: name = "MaskedMarkov"
      else: name = self.nl[order]

    node.__init__(self,name=name,label=label)

# If we have not computed it yet, compute the mask and recurse.
#    ::

    if M == None:
      M = computeHugoMask(I)
      self.add( maskedmarkovFeatures(I,M,name,label,verbosity,order,T) )
      return None

# Recurse for 1st and for 2nd order.
#    ::

    if order == None:
      self.add( maskedmarkovFeatures(I,label=label,order=1) )
      self.add( maskedmarkovFeatures(I,label=label,order=2) )
      return None

# If we have a colour image, we recurse for each channel.
#    ::

    if len(I.shape) > 2:
      for i in [0,1,2]:
        self.add( maskedmarkovFeatures(I[:,:,i],name=self.col[i],order=order) )
      return None

# Now, we know that we have one colour channel and one order to deal with.
#    ::

    if T == None and order == 1: T = 4
    elif T == None: T = 3

    self.tpm1 = {}
    self.tpm2 = {}
    for d in self.forward + self.backward:
      self.tpm1[d] = maskeddiffTPM( I, M, d, T, order=order )
      self.tpm2[d] = maskeddiffTPM( I, ~M, d, T, order=order )

    self.addLeaf( sum( [self.tpm1[d] for d in self.D1 ] ) / 4,
                  ( "SPAM-M", "hv", ) )
    self.addLeaf( sum( [self.tpm1[d] for d in self.D2 ] ) / 4,
                  ( "SPAM-M", "dm", ) )
    self.addLeaf( sum( [self.tpm2[d] for d in self.D1 ] ) / 4,
                  ( "SPAM-I", "hv", ) )
    self.addLeaf( sum( [self.tpm2[d] for d in self.D2 ] ) / 4,
                  ( "SPAM-I", "dm", ) )

    return None

# Functions
# =========
#
# .. function:: computeHugoMask(I)
#
# ::

import os
import tempfile
import shutil
import Image
import commands
from scipy import stats

def computeHugoMask(I,alpha=0.5):
   # create necessary folders
   root = tempfile.mkdtemp()
   input = os.path.join(root,"in")
   output = os.path.join(root,"out")
   os.mkdir(input)
   os.mkdir(output)
   # create the input file
   imwrite(I,os.path.join(input,"image.png"))
   # run HUGO
   cmd = "hugo_simulator -I %s -O %s -V -W -a %g" % (input, output, alpha)
   safe_execute(cmd)
   # read the output file
   M = imread(os.path.join(output,"image.png"))
   # clean up
   shutil.rmtree(root)
   return M < determineThreshold(M, alpha)

def determineThreshold(M, alpha):
   M = M.flatten()
   h = stats.cumfreq(M,256,(0,256))[0]
   h /= M.size
   return h.searchsorted(alpha)

def combinedMask(M,dir):
   (M1,M2) = splitMatrix(M,dir)
   return M1 * M2 # logical AND

def maskedTPM(D,M,dir,T=None):
  """
    Return the transition probability matrix P for the matrix
    D in direction dir, but only for elements where the corresponding
    mask M is set.
    D is split according to direction dir into D1 and D2, while
    M is split according to direction dir into M1 and M2
    The return value is
      P[s,t] = P( D2[i,j] = t | D1[i,j] = s, M1[i,j] ^ M2[i,j] )
    If T is ommitted, it is calculated as the largest absolute value
    in D.  Giving T explicitly may speed up the code.

    NB! Probabilities conditioned on zero-probability events are
    conventionally set to zero.  This feels reasonable, but does not
    match the limit.
  """
  if T == None:
     T = max( abs(D.flatten()) )
  # split the mask, combine and flatten
  (M1,M2) = splitMatrix(M,dir)
  assert M1.shape == M2.shape
  M = (M1 * M2).flatten()
  # split the matrices, flatten, and apply mask
  (D1,D2) = splitMatrix(D,dir)
  assert D1.shape == D2.shape
  D1 = D1.flatten()[M]
  D2 = D2.flatten()[M]
  # set a variable to hold the bin-range
  S = 2*T+1
  # determine the co-occurrence matrix, up to the required limit
  P = np.histogram2d( D1, D2, bins=S )[0]
  # Create a copy of the co-occurrence matrix in floating point, to
  # become the transition probability matrix.
  R = P.astype(float)
  # Now, we have to calculate the transition probabilities.
  P0 = np.histogram( D1, bins=S )[0]
  for s in range(S):
    for t in range(S):
      if P0[s] == 0:
        assert R[s,t] == 0
      else:
        R[s,t] /= P0[s]
  # return the transition probability matrix, R.
  return R

def maskedTPM2(D,M,dir,T=None):
  """
    Return the 2nd order transition probability matrix P for matrix
    D in direction dir, but only for elements where the corresponding
    mask M is set.
    D is split according to direction dir into D1 and D2, while
    M is split according to direction dir into M1 and M2
    The return value is
      P[s,t] = P( D2[i,j] = t | D1[i,j] = s, M1[i,j] ^ M2[i,j] )

    NB! Probabilities conditioned on zero-probability events are
    conventionally set to zero.  This feels reasonable, but does not
    match the limit.
  """
  if T == None:
     T = max( abs(D.flatten()) )
  # split the mask, combine and flatten
  (M1,M2,M3) = dirSplit3(M,dir)
  assert M1.shape == M2.shape == M3.shape
  M = (M1 * M2 * M3).flatten()
  # split the matrices, flatten, and apply mask
  (D1,D2,D3) = dirSplit3(D,dir)
  assert D1.shape == D2.shape == D3.shape
  L = [ D.flatten()[M] for D in [D1,D2,D3] ]
  # set a variable to hold the bin-range
  S = 2*T+1
  # determine the co-occurrence matrix, up to the required limit
  P = np.histogramdd( L, bins=S )[0]
  # Create a copy of the co-occurrence matrix in floating point, to
  # become the transition probability matrix.
  R = P.astype(float)
  # Now, we have to calculate the transition probabilities.
  P0 = np.histogramdd( L[:2], bins=S )[0]
  for s in range(S):
    for t in range(S):
      for u in range(S):
        if P0[s,t] == 0:
          assert R[s,t,u] == 0
        else: R[s,t,u] /= P0[s,t]
  # return the transition probability matrix, R.
  return R

def maskeddiffTPM(I,M,dir,T=4,order=1,**kw):
  """
    Return the transition probability matrix given a numpy array I
    representing the image pixels and a corresponding mask M,
    for the given direction dir.  The features are returned
    as a numpy array.
  """
  # determine the difference matrix in the required direction
  D = differenceMatrix(I,dir,T)
  # determine the corresponding composite mask
  M = combinedMask(M,dir)
  # now call the required routine to compute the TPM
  if order == 1:
     return maskedTPM( D, M, dir, T, **kw )
  else:
     return maskedTPM2( D, M, dir, T, **kw )

# Internal functions

def imwrite(I,fname):
   assert len(I.shape) == 2
   im = Image.new("L", I.shape)
   im.putdata(I.flatten())
   im.save(fname)
   return

def imread(fname):
   im = Image.open(fname)
   I = np.array(im.getdata()).reshape(im.size)
   return I

def safe_execute(cmd):
   st, out = commands.getstatusoutput(cmd)
   if st != 0:
      print "Error executing command:"
      print cmd
      print "Output:"
      print out
      sys.exit()
   return out
