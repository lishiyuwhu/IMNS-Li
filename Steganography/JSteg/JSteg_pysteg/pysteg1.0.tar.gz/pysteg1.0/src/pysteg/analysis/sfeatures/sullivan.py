##  $Id$
## -*- coding: utf-8 -*-

# ##################################
# pysteg.analysis.sfeatures.sullivan
# ##################################
#   
# .. module:: pysteg.analysis.sfeatures.sullivan
#   
# :Module:    pysteg.analysis.sfeatures.sullivan
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>
#
# ::

from ..markov import cooccurrence
import numpy as np
from ..featuretree import node

def midx(M,i,j):
  if i < 0: return 0
  elif j < 0: return 0
  else: return M[i,j]

class ssisVector(node):
  """
    An object holding a full feature vector due to Sullivan.
  """
  def __init__(self,I,name="SMCM-130",dir="h",*a,**kw):
    """
      Calculate the CF moments features of the image I.
    """
    node.__init__(self,name,*a,**kw)
    assert len(I.shape) == 2, "Assumes one colour channel only"
    print "__init__", name, self.len()
    mv = max(np.max(I),255)
    M = cooccurrence(I,dir,T=(0,mv))[0]
    A1 = [ M[k,k] for k in xrange(mv+1) ]
    A1 = [ (x,i) for (i,x) in enumerate(A1) ]
    A1.sort(reverse=True)
    A1 = A1[:6]
    print "Sullivan (A1)", A1
    for (x,i) in A1:
      L = [ midx(M,i,i-j) for j in xrange(11) ]
      self.addLeaf( L, ("No. %i" % (i,),) )
    L = [ M[k,k] for k in xrange(1,255,4) ]
    self.addLeaf( L, ("Subsample",) )
    return 

  def vector(self,id=None):
    if self._verbosity > 2:
      print "[sullivan.vector] entering", self.getname(), id, type(self)
    if isinstance(id,tuple) and id[0][:3] == "No.":
      return self.list[0].vector(id[1:])
    else: return node.vector(self,id)

