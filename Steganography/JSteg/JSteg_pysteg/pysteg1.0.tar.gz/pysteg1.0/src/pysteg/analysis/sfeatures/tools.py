##  $Id$
## -*- coding: utf-8 -*-


# ###############################
# pysteg.analysis.sfeatures.tools
# ###############################
#   
# .. module:: pysteg.analysis.sfeatures.tools
# 
# :Module:    pysteg.analysis.sfeatures.tools
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>
# 
# ::

import cmath
import numpy as np

fft2 = lambda x : np.fft.fft2(x,axes=(0,1))

def phase(M):
  """
    Return the polar phases of each element of a complex array M
    as an array.
  """
  return np.reshape( map( cmath.phase, M.flatten() ), M.shape )

def polar(M):
  """
    Return the polar phases of each element of a complex array M
    as an array.
  """
  return np.reshape( map( cmath.polar, M.flatten() ), M.shape )

def ncol(I):
  """
    Return the number of colour channels in the image I (in numpy array form).
  """
  sh = I.shape
  if len(sh) == 3: return sh[2]
  else: return 1

def norm(X,alpha=1):
  """
    Calculate the L_alpha norm of S, where S can be any sequence-like
    data type, including a list or one-dimensional matrix or array.
  """
  return np.sum( abs(X)**alpha )**(1.0/alpha)


