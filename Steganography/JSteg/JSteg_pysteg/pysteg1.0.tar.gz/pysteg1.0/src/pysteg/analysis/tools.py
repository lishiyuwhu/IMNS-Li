## $Id$
## -*- coding: utf-8 -*-

"""
Redundant.  These functions are not curently used.
"""

print "[pysteg.analysis.tools] $Id$"

# #####################
# pysteg.analysis.tools
# #####################
#   
# :Module:    pysteg.analysis.tools
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2009-2010: University of Surrey, UK
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-10)
# 
# .. automodule:: pysteg.analysis.tools
#
# The following two functions are used to parse lists of feature
# set ID-s given as command line arguments to scripts.
#
# ::

def idsep(S):
  return [ idsplit(s) for s in S.split(";") ]
def idsplit(S):
  return tuple( [ s.rstrip().lstrip() for s in S.split(",") ] )
