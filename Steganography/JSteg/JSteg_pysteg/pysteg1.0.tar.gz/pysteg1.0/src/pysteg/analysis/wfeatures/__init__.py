##  $Id$
## -*- coding: utf-8 -*-

"""
Feature extraction algorithms for Steganalysis using the Wavelet domain.

:Module:    pysteg.analysis.wfeatures
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

# #########################
# pysteg.analysis.wfeatures
# #########################
#   


import sys


if sys.getrecursionlimit() < 10**4:
  sys.setrecursionlimit( 10**4 )

# .. toctree::
#    :maxdepth: 2
#   
#    wam.py.txt
#    denoising.py.txt
#    cfmoments.py.txt
#    farid.py.txt
#    simple.py.txt
