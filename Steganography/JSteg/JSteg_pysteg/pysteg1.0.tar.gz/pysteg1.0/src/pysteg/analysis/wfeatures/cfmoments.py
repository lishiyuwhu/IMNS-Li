##  $Id$
## -*- coding: utf-8 -*-

"""
  Features due to Yun Q Shi's group, using moments of the
  characteristic functions in the wavelet domain.
"""

# ***********************************
# pysteg.analysis.wfeatures.cfmoments
# ***********************************
#   
# :Module:    pysteg.analysis.wfeatures.cfmoments
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>
#
# .. automodule:: pysteg.analysis.wfeatures.cfmoments
#
# ::

from ..featuretree import node
from ..hcfmoments import *
import numpy as np

__all__ = [ "cfmVector" ]

def cfmFeatures78(I,classification=None,*a,**kw):
  """
    Return the 78-D feature vector of
    Shi, Xuan, Zou, Gao, Yang, Zhang, Chai, Chen, & Chen  (2005).
  """
  if classification == None: R = []
  else: R = [classification]
  R.extend( cfmFeatures(I,None,*a,**kw) )
  R.extend( cfmFeatures(predError(I),None,*a,**kw) )
  return R

class cfmVector(node):
  """
    An object holding the full feature vector.
  """
  def __init__(self,I,name="HCF",*a,**kw):
    """
      Calculate the CF moments features of the image I.
      (This uses the cfmFeatures() function.)
    """
    node.__init__(self,name,*a,**kw)
    if len(I.shape) > 2:
      self.add ( cfmVector( I[:,:,0], "Red", *a, **kw ) )
      self.add ( cfmVector( I[:,:,1], "Green", *a, **kw ) )
      self.add ( cfmVector( I[:,:,2], "Blue", *a, **kw ) )
    else:
      self.add( hcfGenVector(I, "HCF-39", *a, **kw ) )
      self.add( hcfGenVector(predError(I), "Pred. Error", *a, **kw) )
    print "__init__", name, self.len()
