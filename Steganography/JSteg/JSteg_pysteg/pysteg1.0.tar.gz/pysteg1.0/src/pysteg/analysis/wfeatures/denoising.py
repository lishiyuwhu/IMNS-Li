##  $Id$
## -*- coding: utf-8 -*-

"""
  Functions for denoising following Kivanc, Mihcak, Kozintsev,
  and Ramchandran (1999).
"""

# ***********************************
# pysteg.analysis.wfeatures.denoising
# ***********************************
#
# .. automodule:: pysteg.analysis.wfeatures.denoising
#   
# :Module:    pysteg.analysis.wfeatures.denoising
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net>

import numpy as np

__all__ = [ "lawmlA", "lawmlB", "lawmlN" ]

Nset = [ 3, 5, 7, 9 ]

# NxN LAWML
# =========

def subm(X,N,i,j):
  "Return an NxN submatrix of X, centered at element (i,j)."
  N /= 2
  (m0,m1) = X.shape
  (i0,j0) = (max(0,i-N), max(0,j-N))
  (i1,j1) = (min(m0,i+N)+1, min(m1,j+N)+1)
  return X[i0:i1,j0:j1]

def sighat0(X,sig0): 
  return max(0, np.var(X) - sig0 )

# .. function:: lawmlGen(X,sig0,f)
#    is a generic (higher-order) denoising function.  The parameter
#    f will determine which of the variants is used.
#
# ::

def lawmlGen(X,sig0,f): 
  (m0,m1) = X.shape

# Define the array of variance estimates.  S[i,j] corresponds to
# \hat\sigma^2(i,j) in Goljan et al.
#
#   ::

  S = np.zeros((m0,m1))
  for x in xrange(m0):
    for y in xrange(m1):

# The calculation of S[x,y] depends on the input function f,
# which is :func:`sighatB` for Goljan's variant and :func:`sighat0` for
# the original.
#
#       ::

      S[x,y] = f(X,sig0,x,y)

# The return expression is Step 3 in Goljan's algorithm.
#
# ::

  return X*S/(S+sig0)

# .. function:: lawmlN(X,N,sig0=0.5)
#    is just a wrapper function for :func:`lawmlGen` to give the
#    Kivanc's non-adaptive variant
#
# ::

def lawmlN(X,N,sig0=0.5):
  """
    Return the denoised image by NxN LAWML,
    assuming a noise power of sig0.
  """

# The local variance estimate is calculated from just an NxN square
# neighbourhood of each pixel (x,y).  This is done by the lambda expression
# given as parameter f.
#
#   ::

  return lawmlGen(X,sig0,f=lambda X, sig0, x, y : sighat0(subm(X,N,x,y),sig0) )

# LAWML-B
# =======
#
# This is the variant of LAW-ML used by Goljan et al.
#
# ::

def sighatB(X,sig0,x,y):
  return min( [ sighat0(subm(X,N,x,y),sig0) for N in Nset ] )

# .. function:: lawmlB(X,sig0=0.5)
#    is another wrapper function for :func:`lawmlGen` to give Goljan's
#    variant
#
# ::

def lawmlB(X,sig0=0.5):
  """
    Return the denoised image of X as used by Goljan et al.,
    assuming a noise power of sig0.
  """

# This is very similar to :func:`lawmlN`, except that the variance 
# is estimated for several neighbourhood size and the lowest estimate
# is used.  This is done by :func:`sighatB`.
#
#   ::

  return lawmlGen(X,sig0,f=sighatB)

# Denoising Residuals
# ===================
#
# At the end of the day, what we need for WAM is the noise residuals,
# calculated as the difference between the denoised image calculates
# with LAW-ML and the original image, as follows::

def lawmlNres(X,*a,**kw): return X - lawmlN(X,*a,**kw)
def lawmlBres(X,*a,**kw): return X - lawmlB(X,*a,**kw)

# LAWML-A
# =======
#
# This is Kivanc's original version of LAW-ML, being locally adaptive.
# The computational complexity of the adaptation is enormous, making
# this version useless for image steganalysis.
#
# ::

def sighat(X,sig0):
  X = X.flatten()
  N = X.size
  return ( bootstrap(X,sig0), sighat0(X,sig0) )

def sighatA(X,sig0,x,y):
  (v,est) = min( [ sighat(subm(X,N,x,y),sig0) for N in Nset ] )
  return est

def bootstrap0(X,sig0):
  #X = X.flatten()
  N = X.size
  S = np.array(np.random.rand(N)*N, dtype=np.uint32)
  return sighat0(X[S],sig0)

def bootstrap(X,sig0,size=75):
  return np.var( [ bootstrap0(X,sig0) for i in xrange(size) ] )

# .. function:: lawmlA(X,sig0=0.5)
#    is the third wrapper function for :func:`lawmlGen`, give Kivanc's
#    original variant
#
# ::

def lawmlA(X,sig0=0.5):
  """
    Return the denoised image of X according to Mihcak et al.,
    assuming a noise power of sig0.
  """
  return lawmlGen(X,sig0,f=sighatA)

