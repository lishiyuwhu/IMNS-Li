##  $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.analysis.wfeatures.novel
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <georg@schaathun.net>
"""

# *******************************
# pysteg.analysis.wfeatures.novel
# *******************************
#
# .. module:: pysteg.analysis.wfeatures.novel
#   

from ..markov import TPM2
import pywt
import numpy as np
from ..featuretree import node

def cap(R,T):
  R[(R>T)] = T
  R[(R<-T)] = -T
  return R

def corrcoef(x,y):
  c = np.corrcoef(x,y)
  assert c[1,0] == c[0,1]
  assert c.shape == (2,2)
  return c[0,1]

def cc(L):
  R = []
  while len(L) > 0:
    x = L.pop().flatten()
    R.extend( [ corrcoef(x,y.flatten()) for y in L ] )
  return R

def TP2(C,dirs,T ):
  X = cap((2*C).astype(int),T)
  return sum( [ TPM2( X, dir, T ) for dir in dirs ] ) / 4

class hgsVector(node):
  """An object holding the WAM-27 vector."""
  featureDic = {}
  def __init__(self,I,name="HGS",wavelet="haar",*a,**kw):
    node.__init__(self,name,*a,**kw)

# Firstly, check if we have an array.
# We need this twice, so we define a boolean variable to avoid multiple
# updates if we need to make it more generic later.
#
#     ::

    isarray = isinstance(I,np.ndarray)

# Firstly, if we have a colour image, we have to recurse for each
# colour channel.
#
#     ::

    if isarray and len(I.shape) == 3:
      self.add( hgsVector(I[:,:,0],"Red",  *a,**kw) )
      self.add( hgsVector(I[:,:,1],"Green",*a,**kw) )
      self.add( hgsVector(I[:,:,2],"Blue", *a,**kw) )
      return
    
# Secondly, if we have a pixmap array, we need to wavelet decompose it
#     ::

    if isarray: I = pywt.wavedec2(I,wavelet,level=2)
    D1 = [ "h", "hr", "v", "vr" ]
    D2 = [ "d", "dr", "m", "mr" ]

    self.addLeaf( cc(list(I[-1])), ("Corr L1",) )
    self.addLeaf( cc(list(I[-2])), ("Corr L2",) )
    self.addLeaf( sum( [ TP2(X,D1,3) for X in I[-2] ] )/3, ("Markov 1",) )
    self.addLeaf( sum( [ TP2(X,D2,3) for X in I[-2] ] )/3, ("Markov 2",) )

    print "hgsVector() END"
