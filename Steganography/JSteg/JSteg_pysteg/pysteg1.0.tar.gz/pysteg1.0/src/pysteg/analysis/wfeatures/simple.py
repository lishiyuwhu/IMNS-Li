##  $Id$
## -*- coding: utf-8 -*-

"""
A really banale feature vector.

:Module:    pysteg.analysis.wfeatures.simple
:Date:      $Date$
:Revision:  $Revision$
:Copyright: 2010: University of Surrey
:Author:    2010: Hans Georg Schaathun <georg@schaathun.net>
"""

# ********************************
# pysteg.analysis.wfeatures.simple
# ********************************
#   
# 
# .. automodule:: pysteg.analysis.wfeatures.simple
# 
# ::

from ...wtools import *

def simpleFeatures(I,classification=0,name="haar"):
  w = getWavelet( name )
  assert len(I.shape) == 2
  (M,N) = I.shape
  print min(I.flatten()), max(I.flatten())
  if M > N: I = np.transpose(I)
  H = pywt.wavedec2( I, w, level=3 )
  R = [classification]
  D = 8*256
  R.extend( H[0].flatten()/D )
  print min(R), max(R)
  for h0 in H[1:]:
    D /= 2
    for h in h0:
      new = h.flatten()/D
      print min(new), max(new)
      R.extend( new )
  return R
