##  $Id$
## -*- coding: utf-8 -*-

"""
The WAM features

:Module:    pysteg.analysis.wfeatures.wam
:Date:      $Date$
:Revision:  $Revision$
:Copyright: 2010: University of Surrey
:Author:    2010: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[pysteg.analysis.wfeatures.wam] $Id$"

# *****************************
# pysteg.analysis.wfeatures.wam
# *****************************
#
# .. module:: pysteg.analysis.wfeatures.wam
#   

from ..moments import *
from .denoising import lawmlBres,lawmlNres
import pywt
import numpy as np
from ..featuretree import node

def moments(M,nmom):
  """
    Calculate the mean and the central moments of order
    2,... nmom of the matrix M.
  """
  A = np.mean(M)
  return [ A ] + centralMoment(M,range(2,nmom+1))


def wamNxN(I,N,nmom,*a,**kw):
  "This is a simple shorthand for use in the wamVector constructor."
  return wamVector(I,"WAM(%i)-27" % (N,),nmom,
                lambda a : lawmlNres(a,N), *a,**kw)

class wamVector(node):
  """An object holding the WAM-27 vector."""
  featureDic = {}
  def __init__(self,I,name="WAM-27",nmom=9,denoiser=None,*a,**kw):
    node.__init__(self,name,*a,**kw)

# Firstly, check if we have an array.
# We need this twice, so we define a boolean variable to avoid multiple
# updates if we need to make it more generic later.
# (See Goljan et al. Section 2, second paragraph.)
#
#     ::

    isarray = isinstance(I,np.ndarray)

# Firstly, if we have a colour image, we have to recurse for each
# colour channel.
#
#     ::

    if isarray and len(I.shape) == 3:
      self.add( wamVector(I[:,:,0],"Red",  nmom,denoiser,*a,**kw) )
      self.add( wamVector(I[:,:,1],"Green",nmom,denoiser,*a,**kw) )
      self.add( wamVector(I[:,:,2],"Blue", nmom,denoiser,*a,**kw) )
      return
    
# Secondly, if we have a pixmap array, we need to wavelet decompose it
#     ::

    if isarray: I = pywt.dwt2(I,"db4")

# If the denoiser is not given, we will recurse for each denoiser
# in our portfolio.
#     ::

    if denoiser == None:
      for N in [3,5,7,9]:
        self.add( wamNxN( I, N, nmom, *a, **kw ) )
      self.add( wamVector(I,"WAM(B)-27",nmom,lawmlBres,*a,**kw) )

# We have now resolved all the generic cases.  Thus we have one
# colour channel and one denoiser.  We just need 9 features for
# each of the three directions.
#
#     ::

    else:
      (L,(H,V,D)) = I
      self.addLeaf( moments(denoiser(H),nmom), ("Horizontal",) )
      self.addLeaf( moments(denoiser(V),nmom), ("Vertical",) )
      self.addLeaf( moments(denoiser(D),nmom), ("Diagonal",) )
    print "wamVector() END"
