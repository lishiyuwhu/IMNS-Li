#! /usr/bin/env python
## -*- coding: utf-8 -*-
## $Id$

"""
Module for client object to help feature selection.

:Module:    itml.cliselect
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.cliselect] $Id$"

# ##############
# itml.cliselect
# ##############
#   
# .. automodule:: itml.cliselect
#
# ::

import pickle
from itml.mysocket import *

def getTask( sock ):

# Message 1: we connect and send the hello string.
#
#   ::

   sock.connect()
   sock.send( reqString ) 
   R = True

# Message 2a-b: 
# The reply may be an instruction to terminate, in which case we return
# False.  Otherwise messages 2a is the length of message 2b, which in
# turn is a pickled object.
#
#   ::

   msg = sock.receive( )
   if msg == killString: return False
   elif msg[:2] != okPrefix:
      raise RuntimeError( "Protocol error" )
   else:
      msglen = int(msg[2:])
      msg = sock.receive( msglen )
      try:
        X = pickle.loads(msg)
      except Exception as e:
	 print_exc(e)
	 sock.send( errString )
	 raise e

# Message 3: acknowledgment and shut down

   sock.send( ackString )
   sock.shutdown( socket.SHUT_RDWR )
   sock.close( )
   return X

