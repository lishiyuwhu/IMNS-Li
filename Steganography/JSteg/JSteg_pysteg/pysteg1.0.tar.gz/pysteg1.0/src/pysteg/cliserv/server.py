## $Id$
## -*- coding: utf-8 -*-

"""
Module for a server object to help feature selection.

:Module:    itml.server
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[itml.cliselect] $Id$"

# ###########
# itml.server
# ###########
#   
# .. automodule:: itml.server
#
# ::

import pickle
from itml.mysocket import *
import threading
import socket
import sys
import Queue

class serverThread(threading.Thread):
   """
   A server thread listens to a port and spawns client threads to
   manage individual connections.
   """
   def __init__(self,Q,port=defaultPort):
      self.port = port
      self.Q = Q
      threading.Thread.__init__(self)
      self.daemon = True
   def run(self):
      sock = socket.socket( socket.AF_INET, socket.SOCK_STREAM)
      hostname = "0.0.0.0"
      sock.bind((hostname, self.port))
      sock.listen(5)
      cont = True
      count = 0
      print "[reqAccept] Listening ", hostname, self.port
      sys.stdout.flush()
      while cont:
        (clientsocket, address) = sock.accept()
        ct = clientThread(mySocket(clientsocket),self.Q)
        count += 1
        print "[reqAccept] Connection no. %i from %s" % (count, address )
        ct.start()
      print "[reqAccept] Completed %i connections" % (count,)

class clientThread(threading.Thread):
   "A client thread is used to manage a single connection with a client."
   def __init__(self,sock,Q,verbosity=1):
      print "[clientThread] Starting"
      self.sock = sock
      self.Q = Q
      threading.Thread.__init__(self)
      self.daemon = True
      self._verbosity = verbosity

   def run(self):
      print "[clientThread.run] Starting", self.name

# Message 1: receiving the Hello

      msg = self.sock.receive ()
      if msg != reqString:
        raise RuntimeError( "Protocol error" )

# Message 2a-b: sending a pickled object.

      try:
         job = self.Q.get(False,5)
      except Queue.Empty:
	 self.sock.send( killString )
      else:

         msg = pickle.dumps( job )
         L = len(msg)
         if self._verbosity > 2:
           print "[request] (%s) pickled length is %i" % (self.name,L)
         self.sock.send( okString( L ) )
         self.sock.send( msg )

# Message 3: receiving acknowledgement

         msg = self.sock.receive()
         if msg == errString:
	    raise RunTimeError( "Client Reported Error" )
         elif msg == ackString:
	    print "Client has acknowledged"
         else:
	    raise RunTimeError( "Protocol Error" )

# Shut down::

      self.sock.shutdown( socket.SHUT_RDWR )
      self.sock.close()
      return
