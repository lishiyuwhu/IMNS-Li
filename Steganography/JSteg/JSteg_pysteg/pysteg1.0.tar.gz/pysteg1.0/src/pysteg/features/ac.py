##  $Id$
## -*- coding: utf-8 -*-

"""
Calculate the Autocorrelation features of Yadollahpour and Naimi (2009).

:Module:    pysteg.features.ac
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>
"""

__all__ = [ "ac" ]

# ##################
# pysteg.features.ac
#   

import numpy as np

def acfeature(A,idx=(1,0)):
   return correlate( 2*(A%2).astype(int) - 1, idx=idx )

def correlate(A,idx=(0,0)):
   (M,N) = A.shape
   (x,y) = idx
   X = A[x:,y:] 
   Y = A[:M-x,:N-y] 
   return np.sum(X*Y)

idxs = reduce ( list.__add__,
                  [ [ (i,j) for j in xrange(5-i) if i+j > 0 ]
		     for i in xrange(5) ] )

featureDic = {
    "AC-4" : [ ((1,1),), ((2,1),), ((1,2),), ((3,1),) ],
}

def ac(I=None,idxs=idxs):
   """
   Calculate the AC features of the image I.  
   If I is None, the names of the features are returned.
   The second argument can be used to specify the shifts used for
   the autocorrelation.
   """
   if I == None:
      return [ "AC(%s,%s)" % (x,y) for (x,y) in idxs ]
   else:
      X = (I%2).astype(int) * 2 - 1
      return [ correlate( X, idx=id ) for id in idxs ]
