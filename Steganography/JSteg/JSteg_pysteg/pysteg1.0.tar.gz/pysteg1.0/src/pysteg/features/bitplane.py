## (C) 2012: Hans Georg Schaathun <georg@schaathun.net>
## -*- coding: utf-8 -*-

import homgen
import numpy as np

__all__ = [ "BPM", "nBPM", "BPH" ]

def setmask( mask, depth ):
   B = ( mask > 0 )
   N = mask[B].size*depth
   mask[B] = [ 2**i for i in range(0,N,depth) ]
   return (mask,N)

a = [1,1,1,1,1,1,1]
b = [0,0,0,1,0,0,0]
mask_dict = {
      "+" : np.array( [[ 0,1,0 ],[ 1,1,1 ],[ 0,1,0 ]] ),
      "++" : np.array( [b,b,b,a,b,b,b] ),
      "d" : np.array( [[ 0,0,1,0,0 ],[ 0,1,1,1,0 ],[ 1,1,1,1,1 ],
	[ 0,1,1,1,0 ], [ 0,0,1,0,0 ]] ),
      }

def BPM( C, shape=(2,2), depth=2 ):
   """Features based on the histogram of bit patterns.
   Note that absolute frequencies are given; for relative
   frequencies, use nBPM().
   """
   X = C & (2**depth-1)
   if mask_dict.has_key(shape): mb = mask_dict[shape]
   else: mb = np.ones(shape)
   (mask,N) = setmask( mb, depth )
   Y = homgen.convolve(X,mask)
   try:
     (h,b) = np.histogram( Y, bins=range( 2 ** N + 1 ) ) 
   except MemoryError:
      print N, shape, depth
      raise
   return h

def nBPM( *a, **kw ):
   """The BPM features normalised to relative frequencies."""
   h = BPM(*a,**kw)
   return h.astype(float) / h.size

def entropy(h):
   y = h[( h != 0 )]
   return - np.sum( y * np.log2(y) )

def BPH( C ):
   "Entropy of normalised BPM features."
   slist = [ "+", "++", "d", (3,3), (10,1), (1,10), (6,1), (1,6) ]
   dlist = [1,2] 
   L = [ [ entropy(nBPM(C,shape,depth)) for shape in slist ]
	 for depth in dlist ]
   return np.array(L)


def BPH3( C ):
   "Entropy of normalised BPM features."
   slist = [ "+", (2,2), (6,1), (1,6) ]
   depth = 3
   L = [ entropy(nBPM(C,shape,depth)) for shape in slist ]
   return np.array(L)
