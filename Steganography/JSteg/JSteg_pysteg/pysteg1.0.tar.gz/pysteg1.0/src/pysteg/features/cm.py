##  $Id$
## -*- coding: utf-8 -*-

"""
Auxiliary functions to work with difference and co-occurrence
matrices, as well as the Markov models used by Shi et al and
Fridrich et al.

:Module:    pysteg.features.cm
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2009-2010: University of Surrey, UK
            © 2012: Hans Georg Schaathun <georg@schaathun.net> 
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net> 

This module is used both in the Spatial Domain and in JPEG.
In principle it can work on arbitrary integer matrices, but the
calculations are done in C libraries without any guards against
overflows and underflows.

Unsigned 8 and 16 bit input is safe, as it is converted to signed 
32-bit.  Likewise, unsigned 32-bit is converted to 64-bit signed.
Signed input is assumed to have a bit to spare, so that the difference
between two scalars will not overflow.  Alternatively, the dtype
argument can be used to specify the desired (numpy-compatible)
data type.
"""

print "[pysteg.features.cm] $Id$"

# ##################
# pysteg.features.cm
# ##################
 
import numpy as np

__all__ = [ "cooccurrence", "splitMatrix", "differenceMatrix", "TPM", "diffTPM",
      "TPMnames" ]

def sm(C,d1,d2):
  (m,n) = C.shape
  (m1,m2) = (max(0,-d1), min(m,m-d1))
  (n1,n2) = (max(0,-d2), min(n,n-d2))
  return C[m1:m2,n1:n2]

def splitMatrix(C,dir):
  """
    Return two (overlapping) submatrices of C dislocated by one
    element in the direction dir.  This is used for calculation of
    both difference matrices and transition probability matrices.

    dir is a pair (x,y) indicating the vector difference between
    the two co-ordinates of each difference
    
    Alternatively, dir may be one of "h" (horizontal),
    "v" (vertical), "d" (diagonal), "m" (minor diagonal),
    or "Xr" (reverse order where X is one of the above).
  """
  if type(dir) == str:
    if dir[0] == "h": (d1,d2) = (0,1)
    elif dir[0] == "v": (d1,d2) = (1,0)
    elif dir[0] == "d": (d1,d2) = (1,1)
    elif dir[0] == "m": (d1,d2) = (1,-1)
    else: raise Exception, "Unknown direction for differences"
    if len(dir) > 1 and dir[1] == "r": (d1,d2) = (-d1,-d2)
  elif type(dir) == tuple:
    (d1,d2) = dir
  else:
    print dir
    raise Exception, "Unexpected type"
  return (sm(C,d1,d2),sm(C,-d1,-d2))

# cooccurrence() can probably replace a similar function
# jfeatures/fridrichbase
#
# ::

def cooccurrence(C,dir,T=None):
  """
  Calculate the co-occurrence matrix of C at direction dir.
  If the threshold T is set, the range is limited to [-T,+T].
  """
  (C1,C2) = splitMatrix(C,dir)
  if T == None: (m1, m2) = ( np.min(C), np.max(C) )
  elif type(T) == tuple: (m1,m2) = T
  else: (m1,m2) = (-T,T)
  bins = list(xrange(m1,m2+2))
  h = np.histogram2d( C1.flatten(),C2.flatten(),bins=bins )[0]
  return (h,bins)

def dirSplit(C,dir):
  """
    Return two (overlapping) submatrices of C dislocated by one
    element in the direction dir.  This is used for calculation of
    both difference matrices and transition probability matrices.

    dir is one of
      "h" -- horizontal
      "v" -- vertical 
      "d" -- diagonal
      "m" -- minor diagonal 
      "Xr" -- reverse order where X is one of the above

    Deprecated in favour of splitMatrix().
  """
  if dir[0] == "h": (M1,M2) = (C[:,:-1],C[:,1:])
  elif dir[0] == "v": (M1,M2) = (C[:-1,:], C[1:,:] )
  elif dir[0] == "d": (M1,M2) = (C[:-1,:-1], C[1:,1:])
  elif dir[0] == "m": (M1,M2) = (C[:-1,1:], C[1:,:-1])
  else: raise Exception, "Unknown direction for differences"
  if len(dir) > 1 and dir[1] == "r": return (M2,M1)
  else: return (M1,M2)

def dirSplit3(C,dir):
  """
  Return three (overlapping) submatrices of C dislocated by one
  element in the direction dir.  This is used for calculation of
  both difference matrices and transition probability matrices.
  """
  if dir[0] == "h":
    (M1,M2,M3) = (C[:,:-2],C[:,1:-1],C[:,2:])
  elif dir[0] == "v":
    (M1,M2,M3) = (C[:-2,:], C[1:-1,:], C[2:,:] )
  elif dir[0] == "d":
    (M1,M2,M3) = (C[:-2,:-2], C[1:-1,1:-1], C[2:,2:] )
  elif dir[0] == "m":
    (M1,M2,M3) = (C[:-2,2:], C[1:-1,1:-1], C[2:,:-2])
  else: raise Exception, "Unknown direction for differences"
  if len(dir) > 1 and dir[1] == "r": return (M3,M2,M1)
  else: return (M1,M2,M3)


def differenceMatrix(C,dir,T=4,dtype=None):
  """
  Return the difference matrix of C, in direction dir ("h", "v", "d", "m"),
  capped at T, as used by Shi et al for the Markov based features.
  """

# This is a bit ad hoc.
# We need signed integers for the difference, and uint8 is common.
# How do we want to deal with the general case?
#
#   ::

  if dtype != None: C = C.astype(dtype)
  elif C.dtype == np.uint8: C = C.astype(np.int32)
  elif C.dtype == np.uint16: C = C.astype(np.int32)
  elif C.dtype == np.uint32: C = C.astype(np.int64)

# We create two submatrices by cropping different edges.
# The difference matrix is simply the difference between the two.
#   ::

  (C1,C2) = splitMatrix(C,dir)
  R = C1 - C2

# If required, we cap the differences before we return the matrix.
#   ::

  if T != None:
    R[(R>T)] = T
    R[(R<-T)] = -T
  return R

# Centre of Mass::

def COM(C,dir,T=None):
  """
    Return the co-occurrence matrix M for the matrix C in direction dir.
    C is split according to direction dir into C1 and C2.
    The return value is
      P[s,t] = P( C2[i,j] = t, C1[i,j] = s )
    If T is ommitted, it is calculated as the largest absolute value
    in C.  Giving T explicitely, may speed up the code.
  """
  (C1,C2) = splitMatrix(C,dir)
  (M,N) = np.shape(C1)
  assert (M,N) == np.shape(C2)
  b = np.max(C) - np.min(C) + 1
  return np.histogramdd( (C1,C2), b )

def TPM(C,dir,T=None,TPM=True,CM=False):
  """
    Return the transition probability matrix P for the matrix
    C in direction dir.
    C is split according to direction dir into C1 and C2.
    The return value is
      P[s,t] = P( C2[i,j] = t | C1[i,j] = s )
    If T is ommitted, it is calculated as the largest absolute value
    in C.  Giving T explicitely, may speed up the code.

    NB! Probabilities conditioned on zero-probability events are
    conventionally set to zero.  This feels reasonable, but does not
    match the limit.  
  """
  (C1,C2) = splitMatrix(C,dir)
  (M,N) = np.shape(C1)
  assert (M,N) == np.shape(C2)
  if T == None: T = max( abs(C.flatten()) ) 

  P = np.histogram2d( C1.flatten(), C2.flatten(), bins=2*T+1 )[0]

# If only the co-occurrence matrix is required, we return it.
#   ::

  if not TPM:
    assert CM, "No return value requested"
    return P

# Create a copy of the co-occurrence matrix in floating point, to
# become the transition probability matrix.
#
#   ::

  R = P.astype(float)

# Now, we have to calculate the transition probabilities.
#
#   ::

  P0 = np.histogram( C1.flatten(), bins=2*T+1 )[0]
  for s in range(2*T+1):
    for t in range(2*T+1):
      if P0[s] == 0:
        assert R[s,t] == 0
      else:
        R[s,t] = R[s,t] / P0[s] 

# If CM is not set, we return just the transition
# probability matrix, R.
#
#   ::

  if (not CM): return R

# Otherwise, we return a tuple (T), combining those matrices called for.
#
#   ::

  T = (R,)
  if CM: T += (P,)
  return T

def TPM2(C,dir,T=None,TPM=True,CM=False):
  """
    Return the 2nd order transition probability matrix P for the
    Difference Matrix D in direction dir.

    NB! Probabilities conditioned on zero-probability events are
    conventionally set to zero.  This feels reasonable, but does not
    match the limit.  
  """
  (C1,C2,C3) = dirSplit3(C,dir)
  (M,N) = C1.shape
  assert (M,N) == C2.shape
  assert (M,N) == C3.shape
  if T == None: T = max( abs(C.flatten()) ) 
  S = 2*T+1
  L = [ C.flatten() for C in [C1,C2,C3] ]
  P = np.histogramdd( L, bins=S )[0]

# If only the co-occurrence matrix is required, we return it.
#
#   ::

  if not TPM:
    assert CM, "No return value requested"
    return P

# Create a copy of the co-occurrence matrix in floating point, to
# become the transition probability matrix.
#
#   ::

  P0 = np.histogramdd( L[:2], bins=S )[0]
  R = P.astype(float)

# Now, we have to calculate the transition probabilities.
#
#   ::

  for s in range(S):
    for t in range(S):
      for u in range(S):
        if P0[s,t] == 0:
          assert R[s,t,u] == 0
        else: R[s,t,u] = R[s,t,u] / P0[s,t] 

# If CM is not set, we return just the transition
# probability matrix, R.
#
#   ::

  if not CM: return R

# Otherwise, we return a tuple (T), combining those matrices called for.
#
#   ::

  T = (R,)
  if CM: T += (P,)
  return T

def diffTPM(C,dir,T=4,order=1,**kw):
  """
  Return the transition probability matrix given a numpy array C,
  for the given direction dir.  The features are returned
  as a numpy array.
  """
  if order == 1: return TPM( differenceMatrix(C,dir,T), dir, T, **kw )
  else: return TPM2( differenceMatrix(C,dir,T), dir, T, **kw )

def TPMnames(T=4,order=1):
   rng = range(-T,1+T)
   if order == 1: return [ (i,j) for i in rng for j in rng ]
   else: return [ (i,j,k) for i in rng for j in rng for k in rng ]

