#! /usr/bin/env python
##  $Id$
## -*- coding: utf-8 -*-

"""
Calculating the correlation coefficient of adjacent pixels as
used in cover selection.

:Module:    pysteg.features.correlation
:Date:      $Date$
:Revision:  $Revision$
:Copyright: (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 
"""

print "[pysteg.features.correlation] $Id$"

import numpy as np

def corrfeature(I):
    "Calculate the correlation coefficients corr-hor, corr-ver."
    if I == None: return [ "corr-hor", "corr-ver" ]
    I = I.astype(float)
    h = np.corrcoef( I[:,:-1].flatten(), I[:,1:].flatten() )
    v = np.corrcoef( I[:-1,:].flatten(), I[1:,:].flatten() )
    return [h[0,1],v[0,1]]

if __name__ == "__main__":
   print ccNames()
