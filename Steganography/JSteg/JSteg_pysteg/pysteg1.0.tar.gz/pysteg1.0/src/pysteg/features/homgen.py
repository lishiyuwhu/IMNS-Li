##  $Id$
## -*- coding: utf-8 -*-

"""
Functions to calculate generic higher-order features,
following the lines of HOLMES.  Both SPAM and HOLMES
are supported.

:Module:    pysteg.features.homgen
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2012 Hans Georg Schaathun <georg@schaathun.net>


It appears to be safe for various input constituent types,
because the scipy.signal module converts to 64-bit integers
in calculation.  Thus 8-, 16-, and 32-bit images should be
safe, whether signed or unsigned.
"""

print "[pysteg.features.homgen] $Id$"
__all__ = [
  "residual", "residualMM", "CM",
  "HolmesMAX", "HolmesMIN", "HolmesHV", "HolmesD",
  "HolmesSQmax", "HolmesSQmin", "HolmesKB",
  "HolmesCALImax", "HolmesCALImin", "HolmesEDGEmin", "HolmesEDGEmax",
  "HolmesHVsum", "HolmesDsum", "HolmesMINsum", "HolmesMAXsum",
  "HOM", "SPAM" ]

import numpy as np
import scipy.ndimage as ndi
from pysteg.sql import config

# This dict is the difference filters used for HOLMES.
# The dictionary key is s-1, where s is the span as used by Fridrich et al.
diff_filter = {
      2 : np.array( [ -1, 1 ] ),
      3 : np.array( [ 1, -2, 1 ] ),
      4 : np.array( [ 1, -3, 3, -1 ] ),
      5 : np.array( [ -1, 4, -6, 4, -1 ] ),
      6 : np.array( [ -1, 5, -10, 10, -5, 1 ] ),
      7 : np.array( [ 1, -6, 15, -20, 15, -6, 1 ] ),
      "KB" : np.array( [ [ -1, 2, -1 ], [ 2, -4, 2 ], [ -1, 2, -1 ] ] ),
      "CALI" : np.array( [ [ 1, 1 ], [ 1, 1 ] ] ),
      "EDGEnw" : np.array( [ [ -1, 2, -1 ], [ 2, -1, 0 ], [ -1, 0, 0 ] ] ),
      "EDGEne" : np.array( [ [ -1, 2, -1 ], [ 0, -1, 2 ], [ 0, 0, -1 ] ] ),
      "EDGEsw" : np.array( [ [ -1, 0, 0 ], [ 2, -1, 0 ], [ -1, 2, -1 ] ]  ),
      "EDGEse" : np.array( [ [ 0, 0, -1 ], [ 0, -1, 2 ], [ -1, 2, -1 ] ]  ),
      }
dir_dict = {
       "h":  (0,1),
       "v":  (1,0),
       "d":  (1,1),
       "m":  (1,-1),
       }
sumlist = zip( [ 3,4,5,6,7 ], [ 2,3,6,10,20 ] )

# Private auxiliaries

def _cap(M,T):
   """Cap a matrix M by +/- T, by replacing entries out of range
   by the capping value."""
   M[( M >  T)] = T
   M[( M < -T)] = -T
   return M

def _convolve(M,F):
   """Convolve two matrices of arbitrary dimension.
   Because multiple implementations exist in the API, this
   function should be used to provide consistency.  It 
   currently uses the function from scipy.ndimage, but this
   may change.  
   """
   try:
      R = ndi.convolve(M,F,mode="reflect")
   except RuntimeError as e:
      print "[_convolve]", M.shape, F.shape
      print e
      raise
   return R

def _stepfunc(N,d,order=1):
   "Auxliary function for splitMatrix()."
   if d == 0:
      fx = lambda x : [ x for i in range(order) ]
      XL = range(N)
   elif d < 0:
      fx = lambda x : [ x+i-1 for i in range(order,0,-1) ]
      XL = range(N+1-order)
   else:
      fx = lambda x : [ x+i for i in range(order) ]
      XL = range(N+1-order)
   return (fx,XL)
def _makeTuples(C,dir,order=2):
   """
   Return two (overlapping) submatrices of C dislocated by one
   element in the direction dir.  This is used for calculation of
   both difference matrices and transition probability matrices.

   dir is a pair (x,y) indicating the vector difference between
   the two co-ordinates of each difference
    
   Alternatively, dir may be one of "h" (horizontal),
   "v" (vertical), "d" (diagonal), "m" (minor diagonal),
   or "Xr" (reverse order where X is one of the above).
   """
   (M,N) = C.shape
   if dir == "square":
      XL = range(M-1)
      YL = range(N-1)
      XD = [ 0, 0, 1, 1 ]
      YD = [ 0, 1, 0, 1 ]
      fx = lambda x : [ x+i for i in XD ]
      fy = lambda x : [ x+i for i in YD ]
   else:
      if type(dir) == str:
         if dir_dict.has_key(dir): (d1,d2) = dir_dict[dir]
         else: raise Exception, "Unknown direction for differences"
      elif type(dir) == tuple:
         (d1,d2) = dir
      else:
         raise Exception, "Unexpected type (%s)" % (dir,)
      (fx,XL) = _stepfunc(M,d1,order)
      (fy,YL) = _stepfunc(N,d2,order)
   return np.vstack( [C[fx(x),fy(y)] for x in XL for y in YL] )

# public auxiliaries for HOLMES (corresponding to concepts in the paper)

def residual(M,dir=None,order=1,s=None,q=1,T=None):
   """Calculate the residual matrix (aka. difference matrix) of an image
   or matrix M.  Higher-order differences are supported following
   Fridrich et al, with a span s of order+1.  Optionally the matrix
   can be quantised by an integer factor q and capped by T.
   If the filter defining the difference is one-dimensional, dir may
   be specified to apply it horizontally (h), vertically (v), 
   diagonally (d), or along the minor diagonal (m).
   """
   if s == None: s = order + 1
   A = M.astype(np.int64)
   B = diff_filter[s]
   if dir == "h": F = B[None,:]
   elif dir == "v": F = B[:,None]
   elif dir == "d": F = np.diag(B)
   elif dir == "m": F = np.diag(B)[::-1,:]
   elif dir == None: F = B
   else: raise Exception, "Unknown direction."
   try:
      C = _convolve(A,F)
   except RuntimeError as e:
      print "[residual]", A.shape, F.shape
      print e
      raise
   assert C.dtype == np.int64
   if q != 1:
      C /= q
   if T != None:
      C = _cap(C,T)
   return C
   #return M[:,:-1].astype(np.int64) - M[:,1:].astype(np.int64)

def residualMM( im, f, dir="hv", q=1, s=1, m=3, T=4 ):
   """Get the MINMAX residual matrix.  The parameter f should
   be either np.min or np.max, specifying whether to take
   the minimum or the maximum.  The MINMAX residual is defined
   as the element-wise minimum or maximum of R^h and R^v.  Optionally
   the dir parameter can be set.  To get the EDGE residuals of HOLMES
   use dir="edge".  If dir="diag" the min/max is taken of R^d and R^m.
   """
   verbosity = config.getVerbosity( "sql" )
   if verbosity > 1:
      print "[residualMM] dir=%s, f=%s, s=%s" % (dir,f,s)
   if dir == "hv":
      D = [ "h", "v" ]
   elif dir == "diag":
      D = [ "d", "m" ]
   elif dir == "edge":
      F = [ "EDGEnw", "EDGEsw", "EDGEne", "EDGEse" ]
      D = None
   else:
      raise ValueError, "Unknown direction"
   R = []
   if D == None:
      for fil in F:
         R.append( residual( im, s=fil, q=q, T=T ) )
   else:
      for d in D:
         R.append( residual( im, s=s, dir=d, q=q, T=T ) )
   return f(R,axis=0)

def CM(C,dir,T,order=2):
   """Return the co-occurrence matrix of C of the given order
   along direction dir.  Relative frequencies are used, so the
   result is a floating point array."""
   S = _makeTuples(C,dir,order)
   R = range(-T,T+2)
   (N,d) = S.shape
   b = tuple([R for i in xrange(d)])
   (h,b) = np.histogramdd( S, bins=b )
   print "Non-zero entries:", h[(h>0)].size
   h = h.astype(np.float64) / N
   print "Non-zero entries:", h[(h>0)].size
   return h

# HOLMES

def HolmesMINMAX( im, f, dir="hv", q=1, s=1, m=3, T=4 ):
   """Calculate the MINMAX Holmes features for the given quantisation
   factor q, difference order order, co-occurrence order m, and
   capping value T.   The argument f should be np.min for the MIN
   feaures and np.max for MAX.
   """
   R = residualMM( im, f, dir, q, s, m, T )
   if dir == "hv":
      D = [ "h", "v" ]
   elif dir == "diag":
      D = [ "d", "m" ]
   else:
      raise ValueError, "Unknown direction"
   return sum( [ CM(R,dir=d,T=T,order=m) for d in D ] )
def HolmesMAX( im, *a, **kw ):
   return HolmesMINMAX( im, np.max, "hv", *a, **kw )
def HolmesMIN( im, *a, **kw ):
   return HolmesMINMAX( im, np.min, "hv", *a, **kw )

def HolmesMarkov( im, dir="hv", q=1, s=1, m=3, T=4 ):
   """Calculate the MARKOV Holmes features for the given quantisation
   factor q, difference order order, co-occurrence order m, and
   capping value T. 
   """
   if dir == "hv":
      D = [ "h", "v" ]
   elif dir == "diag":
      D = [ "d", "m" ]
   else:
      raise ValueError, "Unknown direction"
   L = []
   for d in D:
     R = residual( im, s=s, dir=d, q=q, T=T )
     L.append( CM(R,dir=d,T=T,order=m) )
   return sum(L)
def HolmesHV( im, *a, **kw ):
   return HolmesMarkov( im, "hv", *a, **kw )
def HolmesD( im, *a, **kw ):
   return HolmesMarkov( im, "diag", *a, **kw )

def HolmesSQ( im, f, s=3, q=2, m=4, T=1 ):
   """Calculate the Holmes SQUARE features. 
   We get 2x81 features from this function, calling it with
   f=np.max and f=np.min, for 81 features each.
   Fridrich et al. claim to get 2x162 features.
   """
   R = residualMM( im, f, s=s, q=q, m=m, T=T )
   return CM(R,dir="square",T=T,order=m)
def HolmesSQmax( im, *a, **kw ):
   return HolmesSQ( im, f=np.max, *a, **kw )
def HolmesSQmin( im, *a, **kw ):
   return HolmesSQ( im, f=np.min, *a, **kw )

def HolmesKB( im, q=1, m=3, T=4 ):
   """Calculate the Holmes features for the KB filter using quantisation
   factor q.  This gives 729 features per value of q.  The Holmes
   features use q=1,2,4.
   """
   R = residual( im, s="KB", q=q, T=T )
   return CM(R,dir="h",T=T,order=m) + CM(R,dir="v",T=T,order=m)

def HolmesCALImax( im, *a, **kw ):
   calib = residual( im, s="CALI" )
   return HolmesMAX( calib, *a, **kw )
def HolmesCALImin( im, *a, **kw ):
   calib = residual( im, s="CALI" )
   return HolmesMIN( calib, *a, **kw )

def HolmesEDGEmin( im, s, q, m, T ):
   "The EDGEMIN features of HOLMES."
   if s != 6:
      raise ValueError, "EDGE filters only available for s=6."
   R = residualMM( im, f=np.min, s=6, q=q, T=T )
   return CM(R,dir="h",T=T,order=m) + CM(R,dir="v",T=T,order=m)
def HolmesEDGEmax( im, s, q, m, T ):
   "The EDGEMAX features of HOLMES."
   if s != 6:
      raise ValueError, "EDGE filters only available for s=6."
   R = residualMM( im, f=np.max, s=6, q=q, T=T )
   return CM(R,dir="h",T=T,order=m) + CM(R,dir="v",T=T,order=m)

def HolmesMARKOVsum( im, dir, m, T ):
   L = [ HolmesMarkov(im,dir=dir,q=q,s=s,m=m,T=T) for (s,q) in sumlist ]
   return sum(L)
def HolmesMINMAXsum( im, f, m, T ):
   L = [ HolmesMINMAX(im,f=f,q=q,s=s,m=m,T=T) for (s,q) in sumlist ]
   return sum(L)
def HolmesHVsum( im, m, T ):
   return HolmesMARKOVsum( im, dir="hv", m=m, T=T )
def HolmesDsum( im, m, T ):
   return HolmesMARKOVsum( im, dir="diag", m=m, T=T )
def HolmesMINsum( im, m, T ):
   return HolmesMINMAXsum( im, f=np.min, m=m, T=T )
def HolmesMAXsum( im, m, T ):
   return HolmesMINMAXsum( im, f=np.max, m=m, T=T )

# HOM

def HOM(C,dir,difforder=1,order=2,capvalue=None,limit=None):
   """Calculate features based on a generalised higher-order
   model.  Either capvalue or limit has to be specified.
   To cap the underlying difference matrix, use capvalue.
   To use the unmodified difference matrix, use limit to select
   the central portion of the co-occurrence matrix."""

   print "HOM", dir, difforder, order, capvalue, limit

   D = residual(C,dir=dir,order=difforder)
   print "[HOM]", D.size, D[(D<0)].size, D[(D>0)].size
   print "[HOM]", D.size, D[(D<-3)].size, D[(D>3)].size
   if capvalue != None: D = _cap(D,capvalue)
   if limit == None: limit = capvalue
   print "[CM]", limit, capvalue
   return CM(D,dir=dir,T=limit,order=order)

# SPAM features

def SPAM(C,dir,order):
   """The SPAM features of Fridrich et al.  Only one direction
   (hv or diag) and one order (1 or 2) is calculated at a time.
   """
   if dir == "d": dir = [ "d", "m" ]
   elif dir == "hv": dir = [ "h", "v" ]
   else: raise Exception, "Invalid direction"
   if order == 1: T = 4
   elif order == 2: T = 3
   else: raise Exception, "Invalid order"
   (tmp,F1,R1) = diffTPM(C,dir[0],difforder=1,order=order,capvalue=T)
   (tmp,F2,R2) = diffTPM(C,dir[1],difforder=1,order=order,capvalue=T)
   return (F1+R1+F2+R2) / 4

def div0nan(A,B):
   X = A / B
   X[(np.isnan(X))] = 0
   return X
def diffTPM(C,dir,capvalue,difforder=1,order=2):
   """Calculate the difference matrix D of C and return both the
   co-occurrence matrix of D and the backwards and forwards
   transition probability matrices for a Markov model of the given order.
   This should be used for the SPAM features."""

   P = HOM(C,dir,difforder=difforder,order=order+1,capvalue=capvalue)
   d = len(P.shape)
   S1 = np.sum(P,axis=-1)
   S2 = np.sum(P,axis=0)
   S1 = np.reshape( S1, S1.shape + (1,) )
   S2 = np.reshape( S2, (1,) + S2.shape )
   return (P, div0nan( P,S1 ), div0nan( P,S2 ) )
