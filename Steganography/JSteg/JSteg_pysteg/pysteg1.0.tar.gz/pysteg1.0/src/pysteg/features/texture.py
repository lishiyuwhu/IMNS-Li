##  $Id$
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
Functions to estimate the beta coefficient to quantify the
level of texture in an image.

:Module:    pysteg.features.texture
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2012 Hans Georg Schaathun <georg@schaathun.net>
"""

print "[pysteg.features.texture] $Id$"

import numpy as np
import pywt
from math import gamma
__all__ = [ "ggdBeta" ]

 
def ggdBeta(im=None,wavelet="haar",verbosity=4):
    """Estimate the beta coefficient of the Generalised Gaussian 
    Distribution modelling the wavelet coefficients of an image im."""
    if im == None:
       return [ "txb-diag", "txb-hor", "txb-ver", "txb-min", "txb-max" ]

    (A,(H,V,D)) = pywt.dwt2(im,wavelet)
    if verbosity > 3:
        print "Horizontal", np.min(H), np.max(H), H.dtype
        print "Vertical", np.min(V), np.max(V), V.dtype
        print "Diagonal", np.min(D), np.max(D), D.dtype
        print "Image", np.min(im), np.max(im), im.dtype
        print "Low res", np.min(A), np.max(A), A.dtype
    L = [ ggdBetaComp(C) for C in (D,H,V) ]
    return L + [ np.min(L), np.max(L) ]

def ggdBetaComp(C):
    """Estimate the beta coefficient of the Generalised Gaussian 
    Distribution modelling the given wavelet component C."""
    if np.isnan(C).any():
        raise ValueError, "NaN values in input matrix."
    (m1,m2) = (_m1(C),_m2(C))
    if np.isnan(m1) or np.isnan(m2):
        raise ValueError, "NaN values in moments of input matrix."
    if m2 == 0:
        # Second moment is zero, which would lead to a zero divisor later.
        #
        # This happens when C is a constant matrix, which is rare,
        # but still common with images from the Hubble telescope.
        if (C==0).all():
            # This is the common case identified in the Hubble source.
            print "C is of type", type(C), C.dtype
            print ( "[ggdBetaComp] All zero input matrix. " 
               + " Conventionally returning beta=0." )
            return 0
            # raise ValueError, "Input matrix is all zero."
        else:
            # This case has not yet happened.
            print "[ggdBetaComp] Zero second moment; m1 =", m1
            raise ValueError, "Zero second moment makes a zero divisor."
    try:
        return _beta(m1,m2)
    except:
        print "[ggdBetaComp] Exception in _beta", m1, m2
        raise

def _m1(C):
    "First moment of C."
    return np.sum(np.abs(C)) / C.size
def _m2(C):
    "Second moment of C."
    return np.sum(C**2) / C.size
def _beta(m1,m2):
    return _Finv(m1**2/m2)
def _alpha(m1,m2,beta):
    return m1 * gamma(1.0/beta) / gamma(2.0/beta)

def _Finv(y,eps=10**(-5),xmin=0.025,xmax=4.0):
    """The inverse of _F(), calculated using binomial search."""
    if np.isnan(y):
        raise ValueError, "NaN value received in the F inverse function."
    f = lambda x : _F(x) - y
    (fmin,fmax) = (f(xmin),f(xmax))
    print "[_Finv] Starting eps=%s, xmin=%s, xmax=%s" % (eps,xmin,xmax)
    while xmax-xmin > eps:
        xmid = (xmin+xmax)/2.0
        fmid = f(xmid)
        if fmin*fmid < 0:
            (xmax,fmax) = (xmid,fmid)
        elif fmax*fmid < 0:
            (xmin,fmin) = (xmid,fmid)
        elif fmid == 0:
            (xmin,xmax) = (xmid,xmid)
            (fmin,fmax) = (fmid,fmid)
        else:
            print "[_Finv] x:", xmin, xmid, xmax
            print "[_Finv] f:", fmin, fmid, fmax
            raise Exception, "Neither interval contains the root."
    return (xmin+xmax)/2.0
def _F(x):
    return gamma(2.0/x)**2 / (gamma(3.0/x)*gamma(1.0/x))

class ggd(object):
    """A Generalised Gaussian probability distribution.

    This models a given matrix as a GGD and creates a probability
    distribution function.

    NOT used
    """
    def __init__(self,C):
        if np.isnan(C).any():
            raise ValueError, "NaN value in C."
        (m1,m2) = (_m1(C),_m2(C))
        if m2 == 0:
            print "[ggd] C in (%s..%s)" % (np.min(C),np.max(C))
            print "[ggd] Zero second moment; m1 =", m1
            raise ValueError, "Zero second moment gives zero divisor."
        if np.isnan(m1) or np.isnan(m2):
            print "[ggd] m1=%s, m2=%s." % (m1,m2)
            raise ValueError, "NaN value arising from moments of C."
        try:
            beta = _beta(m1,m2)
        except ValueError:
            print "[ggd] ValueError in _Finv: m1=%s, m2=%s." % (m1,m2)
            raise
        self.beta = beta
        alpha = _alpha(m1,m2,beta)
        self.alpha = alpha
        self.K = beta / ( 2*alpha*gamma(1.0/beta) )
    def __call__(self,x):
        return self.K * np.exp( -(np.abs(x)/self.alpha)**self.beta )

# Tests:
# 1. Compare alpha to standard deviation
# 2. Plot estimated PDF against actual histogram
