## $Id$
## -*- coding: utf-8 -*-

"""
Miscellaneous Auxiliary Functions for Image Processing.

:Module:    pysteg.imtools
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey, UK
:Author:    Hans Georg Schaathun <georg@schaathun.net>
"""

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.pyplot import imread
from PIL import Image
from mpl_toolkits.mplot3d import Axes3D
from pysteg.analysis.markov import differenceMatrix

__all__ = [ "imhist", "imread", "imsave", "dct2", "idct2", "dct2transform" ]

def imhist2d(fn,im,colours,xlim=256,bar=True):
  """
  Save the 2D image histogram of im to the file fn.
  """
  #plt.figure( figsize=(5.5,1.6) )
  fig = plt.figure()
  #ax = fig.add_subplot(111, projection='3d')
  ax = Axes3D(fig)
  #plt.xticks( fontsize=7 )
  #plt.yticks( fontsize=7 )
  print np.min(im), np.max(im)
  if colours == "rg": (X,Y) = (im[:,:,0].flatten(), im[:,:,1].flatten())
  elif colours == "rb": (X,Y) = (im[:,:,0].flatten(), im[:,:,2].flatten())
  elif colours == "gb": (X,Y) = (im[:,:,1].flatten(), im[:,:,2].flatten())
  else: raise Exception, "Invalid colour pair"
  b0 = np.array( [ x-0.5 for x in range(257) ] )
  h = np.histogram2d( X, Y, bins=[b0,b0] )[0]
  print "Histogram created", np.min(h), np.max(h)
  R = range (256)
  X, Y = np.meshgrid(R,R)
  print X.shape, Y.shape, h.shape
  print np.min(X), np.max(X)
  print np.min(Y), np.max(Y)
  print np.min(h), np.max(h)
  ax.plot_wireframe( X, Y, h, rstride=10, cstride=10  )
  plt.savefig( fn )
  return None

def imhist(fn,X,xlim=256,bar=True,diff=False):
  """
    Save the image histogram of X to the file fn.
  """
  plt.figure( figsize=(5.5,1.6) )
  plt.xticks( fontsize=7 )
  plt.yticks( fontsize=7 )
  plt.hold(True)
  if not isinstance(X,list): L = [ X ]
  else: L = X
  lspec = [ "k-", "k:", "k--" ]
  n = 0
  if diff == True: diff = "h"
  if diff:
    bins=[-257] + [ x-0.5 for x in range(-13,15) ] + [257]
    xval=range(-14,15)
  else:
    bins=[ x-0.5 for x in range(257) ]
    xval=range(256)
  for X in L:
    if diff: 
       X = differenceMatrix(X,diff,T=None)
    print np.min(X), np.max(X)
    (h,b) = np.histogram(X,bins=bins)
    if bar: plt.bar( xval, h, linewidth=0.01, edgecolor='w', align="center" )
    else: plt.plot( xval, h, lspec[n%3], linewidth=0.25 )
    n += 1
  #plt.xlim(0,xlim)
  plt.savefig( fn )
  return None

def imsave(I,outfile,mode="L"):
  """
    Save an image, represented as the numpy array I, in the given
    outfile.  This is done by converting to a PIL Image and using
    the PIL save() method.  The mode defaults to "L" for grayscale.
    Use "1" for two-colour images.
  """
  print "imsave() dimension", I.shape

  im = Image.fromarray( I, mode )
###   if mode == "RGB":
###     im = Image.fromarray( I, mode )
###   else:
###     im = Image.fromarray( I[::-1,:], mode )
  return im.save(outfile)

# Discrete Cosine Transform
# =========================
#
# ::

def alpha(u,N): 
  """Auxiliary function for use in dct2."""
  if u == 0: return 1.0/np.sqrt(N)
  else: return 2.0/np.sqrt(N)

def dctmtx(N):
  """
    Auxiliary function creating the matrices for the DCT transform.
  """
  return np.array(
    [ [ alpha(u,N) * np.cos( (2*x+1)*u*np.pi / (2*N) ) for u in xrange(N) ]
      for x in xrange(N) ]
  )

def dct2(I,M=None,N=None): 
  """
    Return the DCT2 transform of the image I.
  """
  if M == None: M = dctmtx(I.shape[0]).transpose()
  if N == None: N = dctmtx(I.shape[1])
  print M.shape, I.shape, N.shape
  return np.dot(np.dot(M,I),N)

class dct2transform(object):
  """
    Instansiable 2-D DCT transform.
    Instantiate as 
      T = dct2transform(M,N)
    where MxN is the image or matrix size, or
      T = dct2transform(M)
    where M is a matrix (image).
    The transform is applied as
      J = T.apply(I)
    for any image (matrix) I of size MxN.
    The transform is self-inverse.

    The transform follows Gonzalez and Woods (2008) eq (8.2-18).
  """
  def __init__(M,N=None):
    if N == None: (M,N) = M.shape
    self.size = (M,N)
    self.M = dctmtx(M).transpose()
    self.N = dctmtx(N)
    return None
  def apply(self,I):
    assert self.size == I.shape
    return self.M*I*self.N

idct2 = dct2
