## $Id: __init__.py 1494 2009-04-30 13:10:41Z css1hs $
## -*- coding: utf-8 -*-

"""
Collection of steganography embedding routines for JPEG images.

:Module:    pysteg.jsteg
:Date:      $Date: 2010-07-16 10:43:38 +0100 (Fri, 16 Jul 2010) $
:Revision:  $Revision: 1559 $
:Copyright: © 2010: University of Surrey, UK
            © 2011: Høgskolen i Ålesund, Norway
:Author:    Hans Georg Schaathun <georg@schaathun.net> (2010-2011)

The abstract stegbase class defines a standard interface for 
stego-systems.  All the other classes provide this interface.
"""

print "[jsteg] $Id$"

# ########################
# Steganographic Embedding
# ########################
#   
#
# .. automodule:: pysteg.jsteg
#
# .. toctree::
#    :maxdepth: 2
#
#    stegbase.py.txt
#    message.py.txt
#    f3.py.txt
#    f4.py.txt
#    f5.py.txt
#    exceptions.py.txt
# 
# 
# *******************
# Imports and Exports
# *******************
# 
# The jsteg package imports and exports all of stego objects from
# its submodules.  A user should never need to use any of the 
# submodules unless he is deriving new classes.
# 
# ::
 
from f1 import f1
from f3 import f3coef
from f4 import f4coef
from f5 import f5coef, f5v2, f4v2
from exceptions import CapacityException

# message should probably move to a different package/module
from message import message

__all__ = [ "f1", "f3coef", "f4coef", "f4v2", "f5coef", "f5v2",
            "rndembed", "message" ]

# *****************
# Other definitions
# *****************
# 
# ::
  
keymode = {
  "f1" : True, "jsteg" : False, "outguess" : True,
  "f3" : True,
  "f4" : True, "f4v1" : True, "f4v2" : True,
  "f5" : True, "f5v1" : True, "f5v2" : True,
  None : None
}

stegobject = {
  "f1" : f1, "jsteg" : f1, "outguess" : f1,
  "f3" : f3coef,
  "f4" : f4coef, "f4v1" : f4coef, "f4v2" : f4v2,
  "f5" : f5coef, "f5v1" : f5coef, "f5v2" : f5v2,
  None : None
}

def rndembed( im, msglength, alg, test=False, noreport=False ):
  """
    Embed a random message of length msglength in image im
    using algorithm alg.  im should be a JPEG object.
    Note, to embed in random locations, the im object must
    be prepared for this.  The jembed.py script does this
    correctly.
  """
  stegoclass = stegobject[alg]
  rk = keymode[alg]
  M = message( random=msglength )
  S = stegoclass( im.getsignal(), rndkey=rk )
  ok = True
  try:
    S.msgEmbed( M )
  except CapacityException, e:
    print "Capacity Exceeded", e
    print "Embedded %i of %i bits." % (S.embedded,8*len(M))
    ok = False
  im.setsignal(S)
  if test:
    return (S.embeddingReport(),stegoclass,im.getkey(),M)
  elif noreport:
    return S.embeddingReport()["Embedded"]
  else:
    return S.embeddingReport()
