## $Id: __init__.py 1494 2009-04-30 13:10:41Z css1hs $
## -*- coding: utf-8 -*-

# **********
# Exceptions
# **********
#
# .. module:: pysteg.jsteg.exceptions
#   
# :Module:    pysteg.jsteg.exceptions
# :Date:      $Date: 2010-07-16 10:43:38 +0100 (Fri, 16 Jul 2010) $
# :Revision:  $Revision: 1559 $
# :Copyright: © 2009: University of Surrey, UK
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009)
# 
# ::


"""
Definition of exceptions used in the JPEG based steganography
classes.
"""

class UnusedCoefficientError(LookupError): 
  """
  UnusedCoefficientError occurs when the application attempts
  to flip a bit which should not be used.
  """
  pass

class CapacityException(LookupError): 
  """
  A CapacityException occurs when the file does not have
  sufficient capacity.  This should be considered documented
  behaviour and should be dealt with.
  """
  pass

class CapacityError(RuntimeError): 
  """
  CapacityError indicates a programming error, where the
  application tries to access beyond the end of the sequence,
  without having checked for a CapacityException.
  """
  pass
