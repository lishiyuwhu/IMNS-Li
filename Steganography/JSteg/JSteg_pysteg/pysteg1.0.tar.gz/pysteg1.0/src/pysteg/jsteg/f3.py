## $Id$
## -*- coding: utf-8 -*-

"""
  F3 should be a simple inheritance from F4, overriding only
  the interpret function.
"""

# ##################
# The F3 Stegosystem
# ##################
#   
# :Module:    pysteg.jsteg.f3
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2009-10: University of Surrey, UK
# :Author:    Hans Georg Schaathun <georg@schaathun.net> (2009-10)


from f4 import f4coef

class f3coef(f4coef): 
  """
    This object handles a list of JPEG AC coefficients and
    embeds and extracts messages using F3.
  """
  def interpret(self,y): 
    "Decode a coefficient y F3 style.  Returns None when y=0."
    x = int(y)
    if x == 0: return None
    else: return (x&1)
