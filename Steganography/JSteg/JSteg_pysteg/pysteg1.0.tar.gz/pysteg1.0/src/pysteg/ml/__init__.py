#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
A selection of learning classifiers.  All the classes strive to
implement the interface of the classifiers from :mod:`mlpy`; with
the methods :meth:`learn`, :meth:`pred`, and :meth:`labels`.

:Module:    pysteg.ml
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>
"""

from .classifiers import *
from .svm import *
