#! /usr/bin/env python
## -*- coding: utf-8 -*-
# $Id$

# COM-HCF Demo
# ============
#
# :Module:    dim
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net> 2010
#
# .. automodule:: dim

# We many features from the numpy family of libraries.
# ::

import scipy.signal as sig
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# Embedding routines are taken from the ssteg package, and
# feature extraction functions from sfeatures.harmsen.
# ::

from ..ssteg.lsb import *
from ..analysis.sfeatures.harmsen import h1d, hcf2feature
from ..analysis.sfeatures.ale import ale1d,ale0
from ..analysis.sfeatures import ac
import pysteg.tools as pt

# The stegalg dictionary maps algorithm names to function objects.
# ::

stegalg = {
  "lsb" : lambda x,m,k : lsbembed(x,m,k,replace=True),
  "lsbpm" : lambda x,m,k : lsbembed(x,m,k,replace=False),
}
featurealg = {
      "hcfcom" : h1d,
      "hcf2feature" : hcf2feature,
      "adjacency" : hcf2feature,
      "ale2d1h" : lambda x : ale2d(x,"h")[0],
      "ale2d2h" : lambda x : ale2d(x,"h")[1],
      "ale1d" : ale1d,
      "ale0" : ale0,
      "ale1" : lambda im : ale1d(im)[0],
      "ale2" : lambda im : ale1d(im)[1],
      "ac" : lambda im : ac.acfeature(im,idx=(1,0)),
}

flabel = {
      "hcfcom" : "HCF-COM",
      "hcf2feature" : "HCF2D-COM",
      "ale2d1h" : r"$A(M_{0,1})$",
      "ale2d2h" : r"$d(M_{0,1})$",
      "ale0" : r"f_0",
      "ale1" : r"f_1",
      "ale2" : r"f_2",
      "ac" : "AC feature",
}

# .. autoclass:: dim
#
# ::

class dim(object):
  """
  This offers method to run a series of simulations of the Harmsen 1D
  feature on a single image which is provided at instantiation, as well
  as its downsampled version.  Different embedding rates may be tested
  and features plotted.
  """

# The col and label attributes are used to mark and label the 
# plots.
#
#   ::

  col = [ "", "x", "+", "o" ]
  label = [ "Image", "Downsampled", "Ratio" ]

# The colour attribute is True for colour images.
#   ::

  colour = False
  filename = None

# Constructor
# -----------
#
#   ::

  def __init__(self,alg,im,feature="hcfcom",msgstep=128,*a,**kw):
    print "[sim.dim.__init__]", type(self)
    if type(im) == str:
      self.filename = im
      im = np.array( Image.open( im ) )
    self.msgstep = msgstep
    self.orig = im
    self.im = np.array( im ) 
    self.newalg(alg)
    self.featurealg = featurealg[feature]
    self.colour = len(im.shape) == 3
    self.size = im.size
    if flabel.has_key( feature ): self.ylabel = flabel[feature]
    else: self.ylabel = "Feature value"

# Embedding related methods
# -------------------------
#
#   ::

  def get1feature(self,im):
    A = self.featurealg( im )
    if isinstance(A,list): return A
    else: return [A]
  def newalg(self,alg):
    "Change the stego-algorithm used."
    self.alg = alg
  def embed(self,im,m,k=None):
    return stegalg[self.alg](im,m,k)
  def rndembed( self, msglength ):
    "Embed a random message of length msglength in the image."
    if msglength > self.size:
      msglength = self.size
      return False
    M = rndbits( msglength )
    self.im = self.embed( self.orig, M )
    return True

# Feature related methods
# -----------------------
#
#   ::

  def downsample(self):
    mask = np.array( [[0.25,0.25],[0.25,0.25]] )
    if self.colour:
      L = [ self.im[:,:,i] for i in [0,1,2] ]
    else: L = [ self.im ]
    M = [ sig.convolve2d(I,mask) for I in L ]
    R = [ np.floor(X[1:-1:2,1:-1:2]).astype(np.uint8) 
	  for X in M ]
    if self.colour: return np.dstack(R)
    else: return R[0]
  def features(self,msglength=0):
    if msglength > 0: self.rndembed( msglength )
    A = self.get1feature( self.im )
    B = self.get1feature( self.downsample() )
    print "[features]", A, B
    return [ A[0], B[0], A[0]/B[0] ]

# Simulation methods
# ------------------
#
#   ::

  def fsim(self,mode=None,*a,**kw):
    """
      Calculate the blockiness for a range of embedding rates.
      It returns a pair of lists (X,Y) where X is the embedding
      rates and Y is the blockiness at each embedding rate.
    """
    step = self.msgstep
    cont = True
    X = range( 0, self.size, step )
    XF = [ self.features(x) for x in X ] 
    print "[fsim]", XF
    Y = np.array( XF )
    X = [ float(x)/self.size for x in X ]
    N = Y.shape[1]
    return (X,[ Y[:,n] for n in xrange(N) ])
  def fplot(self,line,alg=None,alpha=1,mode=None,**kw):
     if kw.has_key( "key" ): key = kw["key"]
     elif alg != None: 
        self.newalg(alg)
        key = self.filename + "/" + alg
     else: 
        (a,key,b) = pt.fnsplit(self.filename)
     print "[dim.fplot()]", line, key, alg
     (X,Y) = self.fsim(alpha=alpha,mode=mode)
     if mode == "cal":
        print "[fplot]", line
        if alg != None: key = alg + "/"
        else: alg = ""
        col = self.col
	if len(Y) > 1: label = self.label
	else: label = [""]
        plt.hold(True)
        for j in xrange(len(Y)):
          i = j%4
	  print "[fplot]", j, len( Y[j] ), max( Y[j] ), min( Y[j] )
          plt.plot( X, Y[j], line+col[i], label=key+label[i] )
     else: plt.plot( X, Y[2], line, label=key ) 
     plt.ylabel( self.ylabel )

class dim1(dim):
  "Plot a single feature for a multiple images."
  label = [ "Image" ]
  def __init__(self,*a,**kw):
     dim.__init__( self, stegalg.keys(), *a, **kw )
     self.im = [ np.array(self.im) for i in stegalg.keys() ]
  def features(self,msglength=0):
    print "[dim1.features]", msglength, "-",
    if msglength > 0: self.rndembed( msglength )
    A = [ self.get1feature( im ) for im in self.im ]
    return A
  def embed(self,im,m,k=None):
    return [ stegalg[alg](im,m,k) for alg in self.alg ]
  def downsample(self,*a,**kw):
     raise NotImplementedException

class dim2(dim):
  "Plot multiple features for a single image."
  label = [ r"$f_1$", r"$f_2$" ]
  def __init__(self,*a,**kw):
     dim.__init__( self, *a, **kw )
     if kw.has_key( "label" ): self.label = kw["label"]
  def features(self,msglength=0):
    print "[dim2]", msglength, "-",
    if msglength > 0: self.rndembed( msglength )
    A = self.featurealg( self.im )
    if isinstance(A,list): return A
    else: return [A]
  def downsample(self,*a,**kw):
     raise NotImplementedException


# Demo objects for other features
# ===============================

class dimadj(dim):
  def features(self,msglength=0):
    if msglength > 0: self.rndembed( msglength )
    A = hcf2feature( self.im )
    B = hcf2feature( self.downsample() )
    return [ A, B, A/B ]
