#! /usr/bin/env python
## -*- coding: utf-8 -*-
# $Id$

# Blockiness Demo
# ===============
#
# :Module:    jim
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2010: University of Surrey
# :Author:    Hans Georg Schaathun <georg@schaathun.net> 2010
#
# .. automodule:: jim

from pysteg.jpeg import jpeg
from pysteg.jsteg import stegobject, keymode, message
from pysteg.jsteg.exceptions import *
from pysteg.analysis.jfeatures.fridrichbase import blockiness

import matplotlib.pyplot as plt

from copy import deepcopy

def getbness(im,*a,**kw):
  return blockiness(im.getSpatial(),*a,**kw)

class jim(jpeg):
  """
    This extension of the jpeg class offer additional methods to
    roll back modifications (incl. embedding), calculate blockiness,
    and create plots of blockiness as a function of embedding rate.
  """
  col = [ "k:", "k--", "k-.", "k-" ]
  label = [ "Image", "Calibrated", "Reembedded", "???" ]
  mode = None
  def __init__(self,alg,infile,msgstep,cal=False,emb=False,*a,**kw):
    jpeg.__init__(self,infile,*a,**kw)
    self.nz = self.nzcount()
    self.msgstep = msgstep
    self.newalg(alg)
    if emb: self.rndembed( self.nz )
    if cal: self.calibrate(mode=cal)
    self.orig = self.getsignal()
  def newalg(self,alg):
    "Change the stego-algorithm used."
    self.alg = stegobject[alg]
    self.rk = keymode[alg]
  def _ystart(self,*a,**kw):
    print "[jim] _ystart"
    return [ getbness(self,*a,**kw) ]
  def _yadd(self,Y,msglength,*a,**kw):
    Y.append( getbness( self, *a, **kw ) )
    return Y
  def fsim(self,*a,**kw):
    """
      Calculate the blockiness for a range of embedding rates.
      It returns a pair of lists (X,Y) where X is the embedding
      rates and Y is the blockiness at each embedding rate.
    """
    step = int(self.msgstep*self.nz/8)
    msglength = 0
    cont = True
    Y = self._ystart(*a,**kw)
    X = [ 0 ]
    while cont:
      msglength += step
      emb = self.rndembed( msglength )
      print "[bness]", emb, msglength
      cont = ( emb/8 == msglength + 4 )
      self._yadd(Y,msglength,*a,**kw)
      X.append( emb )
      self.setsignal(self.orig)
    X = [ float(x)/emb for x in X ]
    print Y
    print X
    return (X,Y)
  def rndembed( self, msglength ):
    """
      Embed a random message of length msglength in the image.
    """
    M = message( random=msglength )
    S = self.alg( self.getsignal(), rndkey=self.rk )
    try:
      S.msgEmbed( M )
    except CapacityException, e:
      print "Capacity Exceeded. Embedded %i of %i bits." % (S.embedded,8*len(M))
    self.setsignal(S)
    return S.embeddingReport()["Embedded"]
  def fplot(self,line,alg=None,alpha=1,label=None):
    if alg != None: 
      self.newalg(alg)
      key = self.filename + "/" + alg
    else: key = self.filename 
    kw = {}
    if label == None: kw["label"] = key
    elif label: kw["label"] = label
    print "[jim.bplot()]", line, key
    (X,Y) = self.fsim(alpha=alpha)
    if self.mode == "cal":
      print line
      col = self.col
      for j in xrange(len(Y)):
        i = j%4
        if label == None: kw["label"] = self.label[i]
        plt.plot( X, Y[j], col[i]+line, **kw )
    else:
       plt.plot( X, Y, line, **kw ) 

class bnessjim(jim):
  label = [ "Image", "Calibrated", "Reembedded" ]
  mode = "cal"
  def _ystart(self,*a,**kw):
    print "[bnessjim] _ystart"
    Y = ( [ blockiness(self.getSpatial()) ],
            [ blockiness(self.getCalSpatial()) ],
	    [] )
    emb = self.rndembed( self.nz )
    Y[2].append( blockiness(self.getSpatial()) )
    self.setsignal(self.orig)
    return Y
  def _yadd(self,Y,msglength,*a,**kw):
    Y[0].append( blockiness(self.getSpatial()) )
    Y[1].append( blockiness(self.getCalSpatial()) )
    #Y[1].append( blockiness(self.getSpatial(),offset=(4,4)) )
    self.rndembed( self.nz )
    Y[2].append( blockiness(self.getSpatial()) )
    return Y
