## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
This package provides an interface to an SQL database to store
image features for steganalysis.

:Module:    pysteg.sql
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>

The tables represented by SQLObject classes are visible directly
in the package.  The different submodules provide functionality:

:setup:    functions to create tables and enter standard feature def's
:imageset: enter images in the db and create test and training sets
:features: establish new feature vectors
:extract:  extracting features from images and enter them in the db
:stats:    statistical analysis of features in the database
:svmodel:  managing SVM classifiers using features from the db
:tools:    reporting, feature dumps, and other output
:latex:    LaTeX formatted output
:coverselect:  cover selection
:errors:       error analysis for steganalysers
:stegocompare: performance analysis for steganalysers
:exceptions:   exceptions and errors

A couple of private modules are important, but their contents
exposed via the main package:

:tables:    the core database tables
:_queue:    the class and SQL table for the job queue 
:_scaling:  scaling models for use with learning classifiers
"""

print "[pysteg.sql]"

from sqlobject import sqlhub,connectionForURI,SQLObject
import tables
from tables import *
from ._queue import Queue
from ._config import config

__all__ = ( [ "sqlConnect", "getImageSet", "config", "Queue" ]
      + tables.__all__ )

def sqlConnect():
    """Connect to the data base, using connection data from the
    config object."""
    url = config.get( "sql", "url" )
    verbosity = config.getint( "sql", "verbosity" )
    try:
        s = sqlhub.processConnection
        if verbosity:
            print "Already connected to", s
    except:
        if verbosity:
            print "Connecting to", url
        sqlhub.processConnection = connectionForURI( url )
    return sqlhub.processConnection 

def getImageSet(name):
    """Look up an image set by its key.  The ImageSet table is tried
    first, and the TestSet table if that fails.  If the argument is
    itself an SQLObject, this is returned as is.  It should be used
    by any function intended to take a polymorphic image set argument.
    """
    if isinstance(name,SQLObject):
        return name
    try:
        T = ImageSet.byName(name) 
    except:
        T = TestSet.byName(name) 
    return T
