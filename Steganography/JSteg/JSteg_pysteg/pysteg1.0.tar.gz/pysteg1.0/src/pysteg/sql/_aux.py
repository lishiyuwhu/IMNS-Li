## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
Auxilliary functions.  Used internally in the package; not intended
for export.
"""

from sqlobject import dberrors
from .tables import *

def isDuplicateError(e):
    return (isinstance(e,dberrors.DuplicateEntryError) or
               tailType(e) == "IntegrityError")

def tailType(obj):
    """Return the class name of an object, stripping any prefixing package 
    names.  This is used to recognise exceptions returned from different
    database backends.  The exception names have been standardised
    (DataError, IntegrityError, etc.), but each backend has its own
    definition."""
    return str(type(obj)).split("'")[1].split(".")[-1]

def matrix2dict( M, centre=False ):
    """Return a list of (index,value) pairs where value is an entry in
    the matrix M and index its index.  If centre is True, the indices are
    offset to be centred at 0."""
    offset = 0
    if (not hasattr(M,"shape")) or (len(M.shape) == 1):
        if centre: offset = len(M) / 2
        return [ ((i-offset,),M[i]) for i in range(len(M)) ]
    else:
        L = [ matrix2dict(A, centre) for A in M ]
        if centre: offset = len(L) / 2
        return [ ((i-offset,)+idx,s) for i in range(len(L)) for (idx,s) in L[i] ]

def splitFilename(fn):
    L = fn.split(".")
    fext = L[-1]
    fbase = ".".join(L[:-1])
    return (fbase,fext)

def getFeatureObject(f):
    if isinstance(f,str):
        return Feature.byKey(f)
    elif isinstance(f,Feature):
        return f
    else:
        raise TypeError, "Function can handle Feature objects and key strings."
