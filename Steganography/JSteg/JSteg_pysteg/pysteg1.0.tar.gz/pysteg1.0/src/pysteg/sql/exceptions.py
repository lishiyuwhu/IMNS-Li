## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
Exceptions for the :mod:`pysteg.sql` package

:Module:    pysteg.sql.exceptions
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>
"""

class MissingDataException(Exception):
    """This exception is raised when prerequisite data are found
    to be missing from the database during calculations.
    Catching it allows client processes to proceed to the next
    task in the queue."""
    pass
class ConfigError(Exception):
    "Error in the configuration file."
    pass
class DataIntegrityException(Exception):
    "Integrity error in the database contents."
    pass
