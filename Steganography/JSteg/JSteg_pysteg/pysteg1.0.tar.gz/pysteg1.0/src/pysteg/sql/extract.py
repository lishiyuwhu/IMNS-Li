#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <hg@schaathun.net>

"""
Methods to load images, extract features, and enter them into the
database.  This module makes the glue between the SQL object library
and the features module.

:Module:    pysteg.sql.extract
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>

Only two methods are exported, one to enter tasks in the queue and one
to process the queue.
"""

import signal
import datetime as dt
import threading
import sys
import Queue as qmod
from sqlobject import SQLObject

from pysteg.sql import * #@UnusedWildImport
import exceptions
from .svmodel import SVMPerformance
from ..imtools import imread
import tables

def flush(*a,**kw): 
    print "[flush]", dt.datetime.now()
    print "Threads alive:"
    for t in threading.enumerate():
        print t
    sys.stderr.flush()
    sys.stdout.flush()

# The following imports are used to evaluate extraction functions
# from the database
from pysteg.features import * #@UnusedWildImport
import pysteg.ssteg.lsb as lsb #@UnusedImport


__all__ = [ "queueSet", "worker" ]

imp = config.get( "sql", "featuremodules" )
imp = [ s.strip() for s in imp.split( "," ) ]
for s in imp:
    if s == "": continue
    exec "from %s import *" % (s,)

class sigState(object):
    """This object listens to a given signal and records whether it has
    occurred.  It is a state machine which is initially False, and changes
    to True when the signal is received.  The state can be read by the
    isset() method, and reset to False with the unset() method.
 
    It is used to allow the queue processor to complete the current task
    before terminating when an agreed signal is received.
    """
    def __init__(self,sig):
        self.state = False
        signal.signal(sig,self)
    def __call__(self,*a,**kw):
        print "Signal caught", a
        print kw
        self.state = True
    def unset(self):
        self.state = False
    def isset(self):
        return self.state

def _extract1( im, img, fv, submit=None, verbosity=1 ):
    """Auxiliary method for extract(), handling a single feature set,
    and taking both the image matrix (im) and the Image SQL object (img)
    as arguments.
    """
    if isinstance(fv,str):
        key = fv
        fv = FeatureSet.byKey( fv )  # Look up SQL object for feature vector
    else:
        key = fv.key
    if verbosity > 0:
        print fv, key
    log = tables.FeatureLog.selectBy( image=img, fsetID=fv.id ).getOne(None)
    # Check if feature set has been calculated:
    if log != None:
        if verbosity > 0:
            print "[_extract1] Features already calculated.  Returning"
            print log
        return
    if verbosity > 0:
        print "Extraction function:", fv.func
    fx = eval(fv.func)        # Get extraction function from SQL entry
    val = fx(im)                     # Extract features
    if fv.matrix:
        if hasattr(val,"shape") and verbosity > 1: 
            print "[_extract1] val.shape =", val.shape
        if submit == None:
            img.addFeatureMatrix(fv,val)
        else:
            submit.put((img,fv,val),True)
    else:
        names = fx(None)
        img.addFeaturesNamed(val,names)
        log = tables.FeatureLog( image=img, fset=fv, entered=dt.datetime.now() )
        if verbosity > 1:
            print log
    return

def extract( img, fv, submit=None, verbosity=1 ):
    "Extract the given feature set(s) fv from the image img."
    if verbosity > 1:
        print "[extract]", img
    if isinstance(img,SQLObject):
        fn = img.getPath()        # Look up file path
    elif isinstance(img,str):
        fn = img
        img = Image.byPath( img )
    else: raise TypeError, "Was expecting an Image as first argument"
    im = imread( fn )         # Load image
    if isinstance(fv,list):
        for fv0 in fv:
            _extract1(im,img,fv0,submit,verbosity=verbosity)
    else: _extract1(im,img,fv,submit,verbosity=verbosity)
    return

def worker( *a, **kw ):
    """Process jobs from the queue until the queue is empty, or
    the SIGUSR2 signal is received.

    It may be suboptimal to configure the signal handler in the API.
    It might be better to move the loop to the script defining the UI.
    """
    i = 0
    signal.signal( signal.SIGUSR1, flush )
    verbosity = config.getVerbosity( "sql" )
    kw["verbosity"] = verbosity
    q = qmod.Queue()
    qt = qThread(q,verbosity)
    qt.start()
    kw["submitq"] = q
    cont = True
    while cont:
       try:
	  cont = qProcess( *a, **kw )
       except:
	  if verbosity > 0:
	     print "[qProcess] exception in iteration no.", i
	     flush()
	  # The False token to the queue makes the I/O thread terminate.
	  # Without it, the process might not halt (depending on the OS).
	  q.put(False,True)
	  raise
       i += 1
       if verbosity > 1:
	  print "[qProcess] completed iteration no.", i
	  flush()
    q.put(False,True)
    if verbosity > 1:
        print "[worker] waiting for I/O thread"
        print qt
	flush()
    qt.join()
    if verbosity > 0:
        print "[worker] returning after", i, "iterations."
	flush()
    return i

class qThread(threading.Thread):
    def __init__(self, q, verbosity=1 ):
        self.q = q
        self.verbosity = verbosity
        threading.Thread.__init__(self)
	self.name += " (I/O thread)"
    def run(self):
        cont = True
        while cont:
            job = self.q.get(block=True,timeout=None)
            if isinstance(job,Queue):
                job.releaseJob()
                if self.verbosity > 0:
                    print "[qThread] release job", job.id
            elif job == False:
                cont = False
            else:
                (img,fs,M) = job
                img.addFeatureMatrix(fs,M)
        if self.verbosity > 0:
            print "[qThread] terminating", self.name

class LWFeatureSet(object):
    """This is a light-weight object implementing the data fields of
    FeatureSet but without the SQL interface."""
    def __init__(self,id,key,jpeg,matrix,symidx,func,verbosity=0):
        self.id = id
        self.key = key
        self.jpeg = jpeg
        self.matrix = matrix
        self.symidx = symidx
        self.func = func
        if verbosity > 4:
            print id,key,jpeg,matrix,symidx,func

def qImage( job, submitq=None, verbosity=3 ):
    img = job.image
    # We could make a low-level query here to create a sequence
    # of LWFeatureSet objects instead of FeatureSet.
    S = """SELECT feature_set.id,key,jpeg,matrix,symidx,func 
         FROM feature_set_queue,feature_set 
         WHERE feature_set_id=feature_set.id
         AND queue_id=%s ;""" % (job.id,)
    fl0 = Queue._connection.queryAll( S )
    # fl  = job.features
    
    # Create a submit Q if none is given, with a thread to process it
    if submitq == None:
        submitq = qmod.Queue()
        qt = qThread(submitq,verbosity)
        qt.start()
    if verbosity > 2:
        print "[qImage] (%s) %s" % (len(fl0), img)
    for fs0 in fl0:
        fs = LWFeatureSet(*fs0,verbosity=verbosity) 
        if verbosity > 3:
            print "[qProcess]", fs
        extract( img, fs, submit=submitq, verbosity=verbosity )
    submitq.put(job,True)
    if verbosity > 0:
        print "[qImage] completed job", job.id

def qProcess( *a, **kw ):
    "Process one job from the queue."
    verbosity = kw.get("verbosity",1)
    submitq = kw.get("submitq",None)
    stop = sigState( signal.SIGUSR2 )
    q = Queue.getJob( *a, **kw )
    if verbosity > 0:
        print "[qProcess]", q
    if not q: return False
    img = q.image
    if img != None:
        qImage( q, submitq=submitq, verbosity=verbosity )
    else:
        S = q.testset
        M = q.svmodel
        if M == None:
            raise exceptions.DataIntegrityException, \
                 "Neither SVM model nor image is given for queue item."
        if S == None:
            try:
                M.train()
                M.saveModel()
            except exceptions.MissingDataException:
                print "Missing data for", M
                q.releaseJob(success=False)
                q = None
                M.destroy()
        else:
            M.loadModel()
            try:
                P = SVMPerformance( svmodel=M, testset=S )
                P.run()
            except exceptions.MissingDataException:
                print "Missing data for", P
                q.releaseJob(success=False)
                q = None
                P.destroy()
        if q != None:
            q.releaseJob()
    return not stop.isset()

def extractSet( imgset, fv ):
    """Extract the given feature sets or list of feature sets fv
    from every image in imgset which may be an ImageSet or TestSet.
    This is obviously only useful when parallellisation is not possible.

    NOT USED!  Use the queue system instead.
    """
    if not hasattr( imgset, "__iter__" ):
        imgset = ImageSet.byPath( imgset )
    for img in imgset:
        extract( img, fv )
    return

def getFS(fs):
    if isinstance(fs,SQLObject):
        return fs
    else:
        return FeatureSet.byKey(fs)

def queueSet( imgset, fv, stegonly=False, checkLog=True ):
    """Queue new tasks for feature extraction.  The given feature sets
    or list of feature sets fv are queued for every image in imgset,
    which can be either an ImageSet or a TestSet.
    """
    verbosity = config.getVerbosity( "sql" )
    if verbosity > 1:
        print "[queueSet]", imgset
        print fv
    if hasattr(fv,"__iter__" ):
        fv = [ getFS(x) for x in fv ]
    if not hasattr( imgset, "__iter__" ):
        imgset = ImageSet.byPath( imgset )
    if stegonly:
        L = imgset.getClass(1)
    else:
        L = imgset
    for img in L:
        fv0 = fv
        if verbosity > 2:
            print img
        if hasattr(fv,"__iter__" ):
            if checkLog:
                fv0 = [ v for v in fv if not _isLogged(img,v) ]
                if len(fv0) == 0:
                    continue
            if verbosity > 2:
                print "fv0: %s/%s (%s)" % (len(fv0),len(fv),checkLog)
        else:
            if checkLog and _isLogged(img,fv0):
                if verbosity > 0:
                    print "[queueSet] Features already calculated.  Returning"
                    # print log
                    continue
            if verbosity > 2:
                print "fv0 = ", fv0
        Queue.addToImage( img, fv0 )
    return

def _isLogged( img, fv, verbosity=1 ):
    log = tables.FeatureLog.selectBy( image=img(), fsetID=fv.id ).getOne(None)
    if log != None:
        if verbosity > 0:
            print "[queueSet/isLogged] Features already calculated.  Ignoring"
            print log
        return True
    return False

