#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
Define new feature sets and feature vectors.

:Module:    pysteg.sql.features
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>

This modules provide functions to define new features, feature
vectors, and feature sets, including feature level fusion.
The functions :func:`fsconfig` and :func:`fvconfig` read 
definitions from a config file and enter them into the database.
"""

import ConfigParser 
from sqlobject import *

from pysteg.sql import *
from exceptions import ConfigError
from pysteg.features import *

__all__ = [ "fsconfig", "fvconfig" ] 


def getFeatureCollection(key):
    """Look up a feature collection by key.  If the key is itself
    an SQLObject, this is returned as is.  Otherwise, the FeatureVector
    object is tried first, and then the FeatureSet table.  At last,
    the Feature table is checked, and if the key matches a feature,
    this is returned as a singleton list."""
    if isinstance(key,SQLObject):
        return key
    try:
        return FeatureVector.byKey( key )
    except:
        pass
    try:
        return FeatureSet.byKey( key )
    except:
        return [ Feature.byKey( key ) ]
    return f

def _idxgen(T,d):
    R = range(-T,T+1)
    if d == 1: return [ (i,) for i in R ]
    else:
        return [ x + (i,) for x in _idxgen(T,d-1) for i in R ]

def _add2d(fs,x,y):
    L = [ fs.key + "(%s,%s)" % (i,j) for i in range(x) for j in range(y) ]
    for key in L:
        Feature( cat=fs, key=key )
    return 

def addmatrix(fs,limit,dim):
    if dim == 1: return _add1d(fs,limit)
    if dim == 2: return _add2d(fs,limit,limit)
    raise TypeError, "Undefined dimension %s (%s)" % ( dim, type(dim) )

def _addsym(fs,T,d):
    for idx in _idxgen(T,d):
        key = fs.key + str(idx).replace(" ","")
        Feature( cat=fs, key=key )
    return
def _add1d(fs,N):
    for i in xrange(N):
        Feature( cat=fs, key=fs.key+"(%s)" % (i,) )
    return

def _addNames(fs,l):
    for n in l:
        Feature( cat=fs, key=n )
    return

def fsconfig( fn ):
   """
   Define feature sets/vectors from a config file with the given filename fn.

   The file assumes feature sets by default, but any section with
   vector = True will be handled as a feature vector.
   """
   cfg = ConfigParser.SafeConfigParser( )
   cfg.read( fn )
   fvlist = []
   verbosity = config.getVerbosity( "sql" )
   for s in cfg.sections():
      if verbosity > 4:
	 print "[fsconfig] next section:", s
      try:
         isfv = bool(eval(cfg.get(s,"vector")))
      except ConfigParser.NoOptionError:
	 isfv = False
      if isfv:
	 fvlist.append(s)
	 continue
      if verbosity > 2:
	 if isfv:
	    print "[fsconfig] FV", s
	 else:
	    print "[fsconfig]", s
      kw = { "key" : s }
      kw["func"] = cfg.get(s,"func")
      try:
         kw["description"] = cfg.get(s,"description")
      except ConfigParser.NoOptionError:
	 pass
      try:
         kw["jpeg"] = eval(cfg.get(s,"jpeg"))
      except ConfigParser.NoOptionError:
	 pass
      try:
         kw["count"] = int(cfg.get(s,"count"))
      except ConfigParser.NoOptionError:
	 pass
      scheme = cfg.get(s,"scheme")
      if scheme == "named":
	 kw["matrix"] = False
	 kw["symidx"] = False
	 addFeatures = lambda : _addNames(fs,eval(kw["func"])(None))
      elif scheme == "2d":
	 kw["matrix"] = True
	 kw["symidx"] = False
	 (x,y) = eval(cfg.get(s,"limit"))
	 addFeatures = lambda : _add2d(fs,x,y)
      elif scheme == "matrix":
	 kw["matrix"] = True
	 kw["symidx"] = False
	 limit = eval(cfg.get(s,"limit"))
	 dim = eval(cfg.get(s,"dimension"))
	 addFeatures = lambda : addmatrix(fs, limit, dim)
      elif scheme == "sym":
	 kw["matrix"] = True
	 kw["symidx"] = True
	 limit = eval(cfg.get(s,"limit"))
	 dim = eval(cfg.get(s,"dimension"))
	 addFeatures = lambda : _addsym(fs,limit,dim)
      else:
	 raise ConfigError, "Unknown scheme"
      try:
	 fs = FeatureSet( **kw )
      except Exception as e:
	 print type(e)
	 print e
	 print "Not allowed to add FeatureSet", kw["key"]
	 pass
      else:
	 addFeatures()
   fvconfig( cfg=cfg, fvlist=fvlist, verbosity=verbosity )
   return

def fvconfig( fn=None, cfg=None, fvlist=None, verbosity=1 ):
   """
   Define feature vectors based on a config file with the given filename fn.
   """
   if verbosity > 0:
      print "[fvconfig]", fn, cfg
   if cfg == None:
      cfg = ConfigParser.SafeConfigParser( )
      cfg.read( fn )
   if fvlist == None:
      fvlist = cfg.sections()
   for s in fvlist:
      if verbosity > 1:
	 print "[fvconfig] Key:", s
      kw = { "key" : s }
      features = None
      for o in cfg.options(s):
	 if o == "features":
	    features = cfg.get(s,o).split()
	 elif o == "dim":
	    kw["dim"] = int(cfg.get(s,o))
	 elif o == "vector":
            isfv = bool(eval(cfg.get(s,"vector")))
	    if not isfv:
	       raise ValueError(
		     "Non-feature vector definition passed to fvconfig()" )
	 else:
	    kw[o] = cfg.get(s,o)
      if features == None:
	 raise ConfigError, "No features defined."
      try:
	 fv = FeatureVector( **kw )
      except Exception as e:
	 print type(e)
	 print e
	 print "Not allowed to add FeatureVector", kw["key"]
	 pass
      else:
	 for fkey in features:
	    if fkey == "": continue
	    fs = getFeatureCollection(fkey)
	    for f in fs: fv.addFeature(f)
   if verbosity > 0:
      print "[fvconfig] complete"
   return
