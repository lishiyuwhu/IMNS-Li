#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
Load image sets into the database and define test and training sets.

:Module:    pysteg.sql.imageset
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>

This is rather crude and it may be better to consult the scripts
to see how the functions are used.
"""

from pysteg.sql import *
import sqlobject.sqlbuilder as sqlb
import os
import numpy.random as rnd
import numpy as np
import _aux
rnd.seed()
import ConfigParser 

__all__ = [ "loadImages", "similarTestSet", "makeTestSets",
      "groupTestSet", "dummyTestSet", "mergeTestSet", ]

def loadImages( fn ):
    """
    Define image sets based on a config file with the given filename fn.
    """
    cfg = ConfigParser.SafeConfigParser( )
    cfg.read( fn )
    for s in cfg.sections():
        kw = { "name" : s }
        for o in cfg.options(s):
            kw[o] = cfg.get(s,o)
        if kw.has_key("source"):
            kw["source"] = ImageSet.byName( kw["source"] )
        try:
            S = ImageSet( **kw )
        except Exception as e:
            print type(e)
            print e
            print "Not allowed to add ImageSet", kw["name"]
            pass
        else:
            submitImages(S)
    return

def submitImages( imgset ):
    """
    Submit images to an ImageSet object imgset by reading the
    filenames directly from the file system.  If source is given, 
    it should be another ImageSet containing source images.  
    The individual source images for each derived image is 
    defined by the file basename and linked.
 
    This is an auxiliary function for :func:`loadImages`.
    """
    verbosity = config.getVerbosity( "sql" )
    dir = imgset.getPath()
    fl = os.listdir( dir ) 
    if verbosity > 1:
         print "[submitImages]", dir, len(fl)
    ext = imgset.extension
    src = imgset.source
    L = []
    for fn in fl:
        (fbase, fext) = _aux.splitFilename(fn)
        # (fbase,fext) = fn.split( ".", 1 )
        if ext != None and ext != fext:
            print ext, fext
            continue
        if src:
            source = src.getBasename( fbase )
            if verbosity > 3:
                print "From", source
            if source == None:
                print "Source set:", src
                print "Image:", fbase
                raise ValueError, "Source image not found"
            L.append( { "filename" : fn,
                        "imageset_id" : imgset.id,
                        "source_id" : source.id } )
        else: 
            L.append( { "filename" : fn, "imageset_id" : imgset.id } )
    I0 = sqlb.Insert( "image", valueList=L )
    I = imgset._connection.sqlrepr( I0 )
    imgset._connection.query( I )
    if verbosity > 0:
        print imgset
        print "Loaded %s images" % (len(L),)
    return

def similarTestSet( base, stego, name, incomplete=False ):
    """
    Create a new TestSet based on base, but using stego images
    from stego instead.  The same random selection is used as
    in bane.  If images are missing from the new stego set,
    an excpetion will be raised unless the incomplete argument
    is set to True, in which case the missing image will just
    be ommitted.

    The current approach is not ideal.  It is difficult to 
    queue feature extraction tasks for the new images without
    requeueing old images as well.  A new approach is needed.
    """

    T = TestSet( name=name )
    for img in base.testimg:
        if img.label == 0:
            r = TestImage( image=img.image, imagesetID=T, label=0 )
            print img.image
            print r
        else:
            try:
                st = Image.selectBy( imageset=stego,
                     source=img.getSource() ).getOne()
            except Exception as e:
                print e
                if incomplete:
                    print "Missing stego image:", img
                    print "from", stego
                else:
                    raise
            else:
                r = TestImage( image=st, imagesetID=T, label=1 )
                print st
                print r
    return T

def makeTestSets( clean, stego, name, testname=None,
      testsize=None, trainsize=None,skew=0.5 ):
    """
    Given two image sets for clean images and steganograms respectively,
    training and test sets are constructed randomly.  It is assumed that
    both clean and stego contain corresponding images with the same
    basename, and if a clean image is included, the corresponding stego
    images is excluded, and vice versa.

    TODO: Create intermediate subsets to make it easier to queue
      feature extraction of just the necessary images.
    """

    if testname == None: testname = name + "_test"
   
    try:
        train = TestSet( name=name )
        test  = TestSet( name=testname )
    except StandardError as e:
        if not _aux.isDuplicateError(e):
            raise
        print "Warning!  Sets already existed"
        train = TestSet.byName( name ) 
        test  = TestSet.byName( testname ) 
        print test
        print train
        return (train,test)

    # Catch errors here
    img   = rnd.permutation(list(clean.images))

    totalsize = len(img)
    if testsize == None and trainsize == None:
        testsize  = np.floor( totalsize / 2 )
        trainsize = np.ceil( totalsize / 2 )
    if testsize != None and testsize <= 1:
        testsize = testsize*totalsize
    if trainsize != None and trainsize <= 1:
        trainsize = trainsize*totalsize
    if testsize == None: testsize = totalsize - trainsize
    if trainsize == None: trainsize = totalsize - testsize

    popTestSet( train, img[:trainsize], stego, skew )
    popTestSet( test,  img[trainsize:(testsize+trainsize)], stego, skew )
    return (train,test)

def dummyTestSet( name, L ):
    """
    Create a dummy TestSet by combining all images from every image set in L.
    All the test images are given the label 1.  This is mainly intended to
    form a set of images for which classification scores can be calculated 
    in bulk, and not as a test or training set as such.  The elements of L
    may be any iterable over images, including TestSet or ImageSet objects.
    """
    T = TestSet( name=name ) 
    for ims in L:
        I = getImageSet(ims)
        popTestSet( T, list(I), None, 1 )

def mergeTestSet( name, L, verbosity=1 ):
    """
    Create a dummy TestSet by combining all images from every image set in L.
    All the test images are given the label 1.  This is mainly intended to
    form a set of images for which classification scores can be calculated 
    in bulk, and not as a test or training set as such.  The elements of L
    may be any iterable over images, including TestSet or ImageSet objects.
    """
    T = TestSet( name=name ) 
    count = 0
    for ims in L:
        I = getImageSet(ims)
        if not isinstance(I,TestSet):
            raise TypeError, "Need test sets to merge"
        for im in I:
            im.copy(T)
            count += 1
    if verbosity > 0:
        print "[mergeTestSet] copied %s images." % (count,)

def filter( name, tset, L ):
    """Generate a new TestSet object by taking every test image from
    tset which is also in L.
    
    :Parameters:
       name : string
          name of the new TestSet object
       tset : string or SQLObject instance
          this may be the name of an ImageSet or TestSet, or an
          SQLObject subclass implementing the interface of these
          classes.
       L : list of strings, string, or SQLObject instance
          This may be the name of an ImageSet or TestSet, or an
          SQLObject subclass implementing the interface of these
          classes; or just a list of file base names.
    """
    T = TestSet( name=name ) 
    if not isinstance(tset,SQLObject):
        tset = getImageSet(tset)
    if isinstance(L,str):
        L = getImageSet(L)
    if isinstance(L,SQLObject):
        L = [ im.getBasename() for im in L ]
    for im in tset:
        if im.getBasename() in L:
            print TestImage( image=im(), imageset=T, 
                label=im.label, response=im.response )

def popTestSet( set, images, stego, skew, verbosity=1 ):
    """Populate a Test or Training Set with images from a list.
    This is an auxiliary function for makeTestSets()."""

    N = len(images)
    N1 = np.floor(N*skew)
    print type(set), N, N1
    for img in images[:N1]:
        TestImage( image=img, imagesetID=set, label=0 )
    for img0 in images[N1:]:
        img = stego.getBasename( img0.getBasename() )
        if img == None:
            if verbosity > 0:
                print "[popTestSet] missing stego image", img0.getBasename() 
        else:
            TestImage( image=img, imagesetID=set, label=1 )

def groupTestSet( set, name, feature, min=None, max=None,
      create=True, **kw ):
    """Return a new TestSet object with the given name, created
    by taking the images from set which satisfy min <= feature < max.
    If min or max is None, it poses no constraint.
    """
    L = [ (im,im.getOneFeature(feature)) for im in set ]
    if max == None:
        c = lambda v : ( v >= min )
    elif min == None:
        c = lambda v : v < max
    else:
        c = lambda v : v < max and v >= min 
    V = [ v for (im,v) in L ]
    L = [ (im,v) for (im,v) in L if c(v) ]
    if create:
        tset = TestSet( name=name, **kw )
        for (im,v) in L:
            im.copy(tset)
        return tset
    else:
        return len(L)
