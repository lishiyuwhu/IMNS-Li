# (C) 2012: Hans Georg Schaathun <georg@schaathun.net>

"""
Selection of functions to create reports in LaTeX format.
"""

from .svmodel import *

__all__ = [ "texPerformance", "texModels" ]

def formatRow(T):
    r = [ str(row[k]) for k in keys ]
    return "   " + " & ".join(r) + "\\\\\n"

def modelRow(T):
    f = "   %s & %s " % ( T[0], T[1], )
    for i in [2,3,4,5,6,7]:
        try:
	    f += "& %.1f\\%% " % (100*T[i],)
        except:
	    f += "& %s " % (T[i],)
    f += " \\\\\n"
    return f 

def performanceRow(T):
    f = "   %s & %s & %s " % ( T[0], T[1], T[2], )
    for i in [3,4,5]:
        try:
	    f += "& %.1f\\%% " % (100*T[i],)
        except:
	    f += "& %s\\%% " % (T[i],)
    f += " \\\\\n"
    return f 

def _gt(p):
    if p == None: 
        return (None,None,None)
    else:
        return (p.FP,p.FN,p.accuracy,)

def getModels():
   for mod in SVModel.select():
       tr = mod.testset.name
       fv = mod.fvector.key
       P1 = mod.getPerformance()
       P2 = mod.getPerformance(training=True)
       yield (fv,tr) + _gt(P1) + _gt(P2)

def texModels():
    """Return a LaTeX table showing all SVM models with testing where
    available.
    """
    keys = [ "Feature Vector", "TrainingSet", 
        "FP", "FN", "Accuracy", 
        "FP", "FN", "Accuracy", ]
    L = list( getModels() )
    L.sort()
    h = "\\multicolumn{2}{c}{Model} & \\multicolumn{3}{c}{Testing} & " + \
                                   " \\multicolumn{3}{c}{Training} \\\\\n"
    return textable(L,keys,cols="lllrrrrrr",formatRow=modelRow,xhead=[h])

def texPerformance():
    """Return the entire SVMPerformance table in LaTeX format.
    The return value is a string.
    """
    keys = [ "Feature Vector", "TrainingSet", "Test Set",
         "FP", "FN", "Accuracy", ]
    L = [ tuple( [ row[k] for k in keys ] ) 
	  for row in SVMPerformance.getRows() ]
    L.sort()
    return textable(L,keys,cols="lllrrr",formatRow=performanceRow)

def textable(L,keys=None,cols=None,formatRow=formatRow,xhead=[]):
    head = None
    if keys == None:
        L = list(L)
        keys = L[0].keys()
    if cols == None:
        cols = len(keys)*"l"
    S = "\\begin{longtable}{%s}\n" % (cols,)
    S += "\\hline\n"
    for h in xhead:
        S += h
    S += " & ".join(keys) + "\\\\\n"
    S += "\\hline\hline\n\endhead\n"
    S += "\\hline\n\endfoot\n"
    for row in L:
        if isinstance(row,dict):
            row = [ row[k] for k in keys ]
        S += formatRow(row)
    S += "\\hline\n"
    S += "\\end{longtable}\n"
    return S
