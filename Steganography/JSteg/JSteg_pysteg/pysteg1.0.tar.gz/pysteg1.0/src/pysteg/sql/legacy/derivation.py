"""
Module with functions to calculate various derived features, including:
*  difference calibration (used in PEV-219),
*  ratio calibration (used by Ker), and 
*  average (used in PEV-219 for the Markov features).
"""
