#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
This module is an attempt to speed up feature retrieval by doing
complex table joins server side.

NOT USED.  It seems that client side join is faster in wall time.
"""

from . import *

class fVector(object):
   def __init__(self,fv):
      if not isinstance(fv,SQLObject):
	 fv = FeatureVector.byKey(fv)
      self.conn = FeatureVector._connection
      w = []
      c = [ "image.id AS image" ]
      a = [ "image" ]
      for (i,f) in enumerate(fv.features):
	 s = "f%06i" % (i,)
	 id = f.id
	 a.append( "feature_value as %s" % (s,) )
	 c.append( "%s.value as %s" % (s,s,) )
	 w.append( "%s.feature_id = %s and %s.image_id = image.id" % (s,id,s) )
      A = ",".join(a)
      C = ",".join(c)
      W = " and ".join(w)
      self.selectQ = "SELECT %s FROM %s WHERE %s" % (C,A,W)
      self.createQ = "CREATE TEMP VIEW fview AS (%s);" % (self.selectQ,)
      print self.createQ
      rows = self.conn.query( self.createQ )
   def __str__(self): return self.selectQ
   def queryAll(self,*a,**kw):
      return self.conn.queryAll(*a,**kw)
   def select(self,image=None):
      if image == None:
         Q = "SELECT * FROM fview ;" 
      elif isinstance(image,SQLObject):
         Q = "SELECT * FROM fview WHERE image = %s ;" % (image.id,)
      else:
         Q = "SELECT * FROM fview WHERE image = %s ;" % (image,)
      return self.conn.queryAll( Q )

