#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <hg@schaathun.net>

"""
REDUNDANT and or DEPRECATED

Functions to retrieve feature vectors from the database.
"""

from . import *
from svm.tools import savefeatures
import numpy as np

# File I/O

def getFeatureFile( fn, imgset, fv=None, **kw ):
   """Save feature vectors to file.  The features are retreived
   using getFeatureSet( imgset, fv ), and stored using 
   svm.tools.savefeatures( fn, **kw ).  To store comma separated
   values, defined keyword argument libsvm=false.  Otherwise
   the sparse format of libSVM is used.
   
   DEPRECATED.  Use the pysteg.sql.tools module instead."""

   L = getFeatureSet( imgset, fv )
   return savefeatures( fn, [ [l]+f for (l,f) in L ], **kw )

# Retrieving feature vectors.
# These functions may be redundant -
# alternative functions are defined in the SQL classes.

def getFeatureSet( imgset, fv=None ):
   """Get the feature vectors defined by fv from the TestSet imgset.
   The feature vector fv kan be a FeatureSet object, a FeatureVector
   object, or a FeatureVector key.  The imageset imgset can be either
   a TestSet name, or a TestSet or ImageSet object.
   The return value is a list of (label,feature vector) pairs."""

   if not isinstance( imgset, SQLObject ):
      imgset = TestSet( name=imgset )
   return [ ( timg.label, timg.image.getFeatures( fv ) ) for
	    timg in imgset.images ]

def getFeatureMatrix( *a, **kw ):
   """Return a pair (L,M) where L is a list of labels and M is 
   a matrix where the rows are feature vectors."""
   F = getFeatureSet(*a,**kw) 
   L = [ l for (l,f) in F ]
   S = [ f for (l,f) in F ]
   return (L, np.array( S ))
