#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
This module defines SQLObject classes for the image and feature datasets.
The SQL database tables are defined through the SQLObject definitions.
"""

from . import *
from .config import config
from sqlobject.views import ViewSQLObject
from .aux import *

class FeatureView(ViewSQLObject):
   "Under construction!"
   class sqlmeta:
        idName = VectorFeature.q.id
        clause = VectorFeature.q.feature == Feature.q.id and \
                 VectorFeature.q.vector == FeatureVector.q.id and \
                 FeatureValue.q.feature == Feature.q.id 

   # Feature vector key, used for look-up
   fvector  = StringCol( dbName=FeatureVector.q.key )

   # Image ID referencing the object of interest
   imageID  = ForeignKey('FeatureValue',  dbName=FeatureValue.q.image)

   # The actual feature value
   value    = ForeignKey('FeatureValue',  dbName=FeatureValue.q.value)

   # The following are just the ID-s of each table involved
   featureID = ForeignKey('Feature',       dbName=Feature.q.id)
   valueID   = ForeignKey('FeatureValue',  dbName=FeatureValue.q.id)
   vectorID  = ForeignKey('FeatureVector', dbName=FeatureVector.q.id)
   relaID    = ForeignKey('VectorFeature', dbName=VectorFeature.q.id)


# TODO: Feature Views: fvalueID, image, fvector_key, fvalue

