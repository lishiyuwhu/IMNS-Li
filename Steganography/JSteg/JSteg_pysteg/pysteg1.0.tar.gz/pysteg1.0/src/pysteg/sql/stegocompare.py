## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from . import *
from .coverselect import predict
import matplotlib.pyplot as plt
import numpy as np

def ccount2d(L1,L2,bn,s1,s2,verbosity=1):
    """
    Given a list L of ImageSet objects and a basename bn, 
    check the images corresonding to bn from each ImageSet
    and return the number of such images which are classified
    as stego by the given classifier score.
    """
    R1 = ccount(L1,bn,s1,verbosity=verbosity)
    R2 = ccount(L2,bn,s2,verbosity=verbosity)
    if verbosity > 1:
        print "[ccount]", S1
        print "[ccount]", S2
    return (R1,R2)

def ccount(L,bn,score,feature=None,verbosity=1):
    """
    Given a list L of ImageSet objects and a basename bn, 
    check the images corresonding to bn from each ImageSet
    and return the number of such images which are classified
    as stego by the given classifier score.
    """
    I = [ s.getBasename(bn) for s in L ]
    if verbosity > 2:
        for im in I: print im
    S1 = [ im.getOneFeature(score) for im in I ]
    S = [ predict(s) for s in S1 ]
    R = S.count(1)
    if verbosity > 0:
        print "[ccount]", S1
    if feature != None:
        fval = I[0].getCoverFeature(feature)
        return (R,fval)
    else:
        return R

def cdata2d(L1,L2,T,s1,s2):
    verbosity = config.getVerbosity( "sql" )
    T = getImageSet(T)
    if not isinstance(s1,SQLObject):
        s1 = Feature.byKey(s1)
    if not isinstance(s2,SQLObject):
        s2 = Feature.byKey(s2)
    names = [ im.getBasename() for im in T ]
    S1 = [ getImageSet(s) for s in L1 ]
    S2 = [ getImageSet(s) for s in L2 ]
    X = [ ccount2d(S1,S2,bn,s1,s2,verbosity=verbosity) for bn in names ]
    X1 = [ x for (x,y) in X ]
    X2 = [ y for (x,y) in X ]
    N = max(max(X1),max(X2))
    (h,xe,ye) = np.histogram2d(X1,X2,bins=range(N+2))
    if verbosity > 1:
        print h
    return h

def _cdata(L,T,score,feature,verbosity=1):
   T = getImageSet(T)
   if not isinstance(score,SQLObject):
      score = Feature.byKey(score)
   names = [ im.getBasename() for im in T ]
   sets = [ getImageSet(s) for s in L ]
   X = [ ccount(sets,bn,score,feature,verbosity=verbosity) for bn in names ]
   return X

def cbar(L,T,score,feature,outfile=None):
   verbosity = config.getVerbosity( "sql" )
   X = _cdata(L,T,score,feature,verbosity=verbosity)
   N = max( [ x for (x,y) in X ] ) + 1
   Y = [ y for (x,y) in X ]  
   YL = [ [ y for (x,y) in X if x == i ]  for i in range(N) ]
   (h,b) = np.histogram(Y,bins=5)
   H = [ np.histogram(y,bins=b)[0] for y in YL ]
   r = np.zeros( h.shape )
   plt.figure()
   plt.hold( True )
   L = b[:-1]
   w = 0.75*(b[1]-b[0])
   idx = 0
   c = [ "k", "b", "c", "g", "y", "m", "r" ]
   for h in H:
      plt.bar(L,h,width=w,bottom=r,color=c[idx])
      r += h
      idx += 1
   if outfile != None:
      plt.savefig(outfile)
   return None

def cstat(L,T,score,feature,outfile=None):
   verbosity = config.getVerbosity( "sql" )
   S = _cdata(L,T,score,feature,verbosity=verbosity)
   #X = [ x for (x,y) in S ] 
   D = {}
   for (x,y) in S:
      try:
	 D[x].append(y)
      except KeyError:
	 D[x] = [y]
   for x in D.keys():
      Y = D[x]
      print "Class %s: (%s,%s)" % (x,np.mean(Y),np.var(Y))
   return None


def cscatter(L,T,score,feature,outfile=None):
    verbosity = config.getVerbosity( "sql" )
    X = _cdata(L,T,score,feature,verbosity=verbosity)
    Y = [ y for (x,y) in X ] 
    X = [ x for (x,y) in X ] 
    scatteropt = { "s" : 1, "linewidth" : (0,) }
    plt.scatter( X, Y, c="k", **scatteropt )
    plt.xlabel( "Correct classifications" )
    plt.ylabel( feature )
    if outfile != None:
        plt.savefig(outfile)
    return None

def chist(L,T,score,outfile=None):
   verbosity = config.getVerbosity( "sql" )
   T = getImageSet(T)
   if not isinstance(score,SQLObject):
      score = Feature.byKey(score)
   if verbosity > 0:
      print score
   names = [ im.getBasename() for im in T ]
   sets = [ getImageSet(s) for s in L ]
   if verbosity > 2:
      print sets
   X = [ ccount(sets,bn,score,verbosity=verbosity) for bn in names ]
   N = max(X)
   if verbosity > 0:
      print "N =", N
   (h,b) = np.histogram(X,bins=range(N+2))
   if verbosity > 2:
     print b
     print h
   if outfile != None:
      L = [ x-0.4 for x in range(N+1) ]
      plt.bar(L,h,)
      plt.savefig(outfile)
      return h
