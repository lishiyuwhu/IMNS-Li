#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
This module defines SQLObject classes for the image and feature datasets.
The SQL database tables are defined through the SQLObject definitions.

:Module:    pysteg.sql.svmodel
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>
"""

print "[pysteg.sql.svmodel]"

from sqlobject import *
from pysteg.sql import * #@UnusedWildImport
from ._aux import isDuplicateError
# import numpy as np
import sys
import datetime as dt
import pysteg.ml as ml

from ._scaling import ScaleModel

__all__ = [ "SVModel", "SVMPerformance", "ScaleModel",
            "newModel", "newSVM", "testSVM", "perfQueue", ]

alg_dict = {
      "svm" : 1,
      "fld" : 2,
      "ensemble" : 3,
      }
conf_dict = {
      "svm"      : ( [ "crange", "grange", "fold", "nworker" ], [] ),
      "ensemble" : ( [ "L", "dred", "nworker" ], [] ) }
class_dict = {
      1 : ml.SVM,
      2 : None,
      3 : ml.EC,
      }

def predict(x):
    return int(x < 0)

class SVModel(SQLObject):
    """An SVModel object defines a classifier (using SVM or another
          algorithm.  It consists of the following elements:

    1. testset: a TestSet object used as training set,
 
    2. fvector: a FeatureVector object identifying the features used 

    3. feature: an associated Feature object representing the classifier
       output (classification score) 

    4. classifier: integer to identify the classifier algorithm.
       Default: 1 for :class:`pysteg.ml.SVM`.

    5. scalemethod: integer to identify the scaling method
       Default: 1 for scaling into the interval (-1,+1)

    6. scaling: a ScaleModel object
       The ScaleModel object is calculated from the training set
       prior to training, and is used to scale all test objects
       prior to testing.

    7. model: the classification model.
       This is not persistent.  Instead the model is serialised
       either in a file identified by the modfile column, or by
       pickling in the pickle column.

    8. modfile: filename for the the classification model.
 
    9. param: classifier parameters (for arbitrary classifiers)
       This is a string which must evaluate to a python dict object.

    The classifier is defined by the training set (1), feature vector (2),
    and a scaling strategy which is used to calculate (3).  The model (4)
    is derived from the first three.  The feature (5) is a hook for the
    classifier output to use it as input feature in a fused classifier. 
 
    Unfortunately, the libsvm classifier model relies on the ctypes library
    and cannot be pickled.  It has to be stored on file and not in the
    database.
    """
    # Core attributes
    testset = ForeignKey( "TestSet" )
    fvector = ForeignKey( "FeatureVector" )
    feature = ForeignKey( "Feature", alternateID=True, cascade=True )
    classifier  = IntCol( default=1 )
    scalemethod = IntCol( default=1 )
    scaling = ForeignKey( "ScaleModel", default=None )
    model   = None
    pickle  = PickleCol( default=None )
    modfile = StringCol( default=None )
    param   = StringCol( default=None )

    # Other attributes
    # Accuracy in cross-validation
    xrate = FloatCol( default=None )
    # Convenience - join with the performance table
    performance = SQLMultipleJoin( "SVMPerformance", joinColumn="svmodel_id" )

    @classmethod
    def new(cls,classifier="svm",**kw):
        """Create a new instance of an SVModel using the given classifier
        algorith.  Every configuration parameter of the classifier can be
        passed as a keyword argument, and so can key settings for the SVModel
        object.
        """
        # We will split kw into two dict's:
        #    kw for classifier parameters
        #    kw1 for SVModel attributes
        # L1 is the keys for kw1
        L1 = [ "testset", "fvector", "feature", "classifier", "scalemethod",
              "scaling", "modfile" ]
        # (1) Create the kw1 dict
        kw1 = {} 
        kw1["classifier"] = alg_dict[classifier.lower()]
        for k in L1:
            v = kw.pop(k,None)
            if v != None: kw1[k] = v

        # Look up permissible keys for kw
        (L,S) = conf_dict[classifier]

        # Copy settings from config file into kw 
        for k in L:
            if kw.has_key(k): continue
            v = config.get(classifier,k)
            if v != "": kw[k] = eval(v)
        for k in S:
            if kw.has_key(k): continue
            v = config.get(classifier,k)
            if v != "": kw[k] = v
        s = str(kw).replace("'",'"')

        # Remove None entries from the kw1 dict
        for k in kw1:
            if kw1[k] == None:
                kw1.pop(k)

        # Create and return instance
        return cls(param=s,**kw1)

    def __str__(self):
        return ( "<SVModel %s [%s/%s]>"
          % (self.feature.key,self.fvector.key,self.testset.name,) )
    def destroy(self,values=False):
        """Delete the model from the data base.
        Note that any external model file is not removed.
        """
        f = self.feature
        self.destroySelf()
        if self.scaling != None:
            self.scaling.destroy()
        f.destroy()

    @classmethod
    def destroyAll(cls):
        "Delete all SVM models."
        for m in cls.select():
            m.destroy()

    @classmethod
    def byKey(cls,key):
        "Retrieve an SVM model by key (feature key)."
        f = Feature.byKey( key )
        return cls.byFeatureID( f )

    def getTestSet(self):
        """Get the canonical test set for this SVM model.
        The canonical test set is found by taking the name of
        the training set and appending the string "_test".
        """
        name = self.testset.name + "_test"
        return TestSet.byName( name )
    def getPerformance(self,training=False,prune=False):
        """Get the canonical SVMPerformance objects for this model.
        If training is True, then the performance on the training
        set is returned."""
        if training:
            T = self.testset
        else:
            T = self.getTestSet()
        P = self.performance.filter( SVMPerformance.q.testset == T )
        N = P.count()
        print N, "performance objects"
        if N == 0:
            return None
        else:
            return P[0]

# Model management

    def getModel( self ):
        "Return the SVM model.  The type is a libsvm ctypes object."
        if self.model == None:
            self.loadModel()
        return self.model
    def loadModel( self ):
        """Load the model from file.  The filename is stored in the database.
      
        TODO: add support for the pickle column.
        """
        if self.modfile == None:
            raise exceptions.MissingDataException, "No model file is defined."
        print "[loadModel]", self.modfile
        cls = class_dict[self.classifier]
        self.model = cls.load_model( self._getPathName() ) 
        print self.model
        return self.model
    def saveModel( self, filename=None ):
        """Save the model to file.  The filename can be specified as
        an argument, overriding normal behaviour.  Otherwise it
        is sought in in the database or constructed from the key
        using a standard formula.
        
        TODO: add support for the pickle column.
        """

        if filename != None:       self.modfile = filename
        self.model.save_model( self._getPathName() ) 
    def _getPathName( self ):
        """
        Get the full path name of the SVM model file.
        If no file name has been specified in the record, one
        is generated from the key.
        """
        if self.modfile == None:
            self.modfile = self.feature.key + ".svmodel"
        return config.get( "sql", "modeldir" ) + "/" + self.modfile
  
# Grid search and training

    def _getproblem( self ):
        """Get the problem matrices (x,y) training."""
        (l,fv,_) = self.testset.getFeatures( self.getScaleModel() )
        print "Labels:", len(l)
        print "Feature vectors:", len(fv)
        print "Dimension:", len(fv[0])
        return ( fv, l )

    def gridOpt( self, **kw ):
        raise NotImplementedError
    def _getGridOpt( self ):
        raise NotImplementedError

    def train( self ):
        """Train the classifier.

        The training set is scaled before training and the scaling
        model stored.
        """
        verbosity = config.getVerbosity( "sql" )
        if self.scalemethod != 1:
            raise ValueError, "Unsupported scaling method."
        if verbosity > 0:
            print "[SVModel.train] Scaling ..."
            sys.stdout.flush()
        self._scale( verbosity=verbosity )
        if verbosity > 0:
            print "[SVModel.train] Scaling done"
            sys.stdout.flush()
        return self._train( verbosity=verbosity )

    def _train( self, verbosity=1 ):
        """Auxiliary for :meth:`train`.

        Perform the actual training after scaling.
        """
        (x,y) = self._getproblem()
        kw = eval( self.param )
        self.model = class_dict[self.classifier]( **kw )
        if verbosity > 0:
            print "[SVModel.train] Starting training"
            sys.stdout.flush()
        self.model.learn( x, y )
        if verbosity > 0:
            print "[SVModel.train] trained"
            sys.stdout.flush()
        return self.model

# Retrieving and scaling features

    def _scale( self, verbosity=1 ):
        """Calculate the scaling model for the feature vector based on
        the given training set.
        
        This is exceedingly slow and 40-50% of the activity is on the
        SQL server.
        """
        if verbosity > 0:
            print "[_scale] Creating Scaling rows"
            sys.stdout.flush()
        self.scaling = ScaleModel.calc( self.fvector.features,
              self.testset, verbosity )
        if verbosity > 0:
            print "[_scale] Returning"
            sys.stdout.flush()
        return

    def getScaleModel( self ):
        """Get the scaling model from the database.  The return value
        is a pair (factor,addterm) of lists.  The addterm should be
        subtracted from the feature vector and then the factor should 
        be multiplied to get a scale feature vector.
        """
        return self.scaling

    def classify( self, img ):
        """Classify the given images img, which may be an Image,
        a TestSet, or a list of Image objects.  The return value is
        a list of (image,score) pairs where score is the soft information
        classification heuristic.
  
        In addition to returning the scores, they are also entered in 
        the database as feature values.
        """
  
        verbosity = config.getVerbosity( "sql" )
        fv = self.getScaleModel()
        if verbosity > 1:
            print "[predict]", fv
            sys.stdout.flush()
     
        # This should be the key of a TestSet object
        if isinstance( img, str ):
            img = getImageSet( img )
     
        # This should be a single Image object
        if hasattr(img,"features"): 
            print "[predict] one image", img
            x = [ img.getFeatures( fv ) ]
            imlist = [img]
     
        # This is an iterator over images, and could be a list or an ImageSet
        elif hasattr(img,"__iter__"): 
            print "[predict] iterator"
            L = [ (im.getFeatures(fv),im()) for im in img ]
            x = [ f for (f,i) in L ]
            imlist = [ i for (f,i) in L ]
     
        # If none of the above is right, we are stuffed
        else: 
            raise TypeError, "Do not know how to handle type %s" % (type(img),)
   
        if verbosity > 2:
            print "[predict]", len(x), len(x[0])
            sys.stdout.flush()

        # Look up the actual model
        model = self.getModel()
  
        # Look up labels and check number of classes
        labels = model.labels()
        if len(labels) != 2:
            raise ValueError, "Only binary classification is supported."
  
        # Run the classifier.  Reverse the sign if the labels are unsorted
        score = model.pred_values( x )
        if labels[0] > labels[1]:
            score *= -1
        if verbosity > 0:
            print "[predict] classification complete."
            sys.stdout.flush()

        # Sanity checks
        (_,D) = score.shape
        if D != 1:
            raise ValueError(
                  "Only binary classification is supported (D=%s)." % (D,) )

        # Enter scores and return
        score = score[:,0]
        for (im,val) in zip(imlist,score):
            self.feature.addValue( im, val )
        return zip(imlist,score)
   
class SVMPerformance(SQLObject):
    """Class to record performance statistics for a particular SVM 
    model on a particular test set.""" 

    svmodel = ForeignKey( "SVModel", cascade=True )
    testset = ForeignKey( "TestSet", cascade=True )
    idx     = DatabaseIndex( 'svmodel', 'testset', unique=True )
    description = StringCol( default=None )
    FP = FloatCol( default=None )
    FN = FloatCol( default=None )
    accuracy = FloatCol( default=None )

    def destroy(self): return self.destroySelf()
    def __str__(self):
        key = self.svmodel.feature.key
        tset = self.testset.name
        return "<SVMPerformance %s model=%s testset=%s FP=%s FN=%s>" % (
            self.id, key, tset, self.FP,self.FN )

    def display(self):
        "Pretty-print the performance entry."
        key = self.svmodel.feature.key
        tset = self.testset.name
        print "FP=%s, FN=%s (%s) %s/%s" % (
            self.FP,self.FN,self.accuracy, key,tset)

    def run(self,recalculate=True):
        """Calculate the performance.
  
        By default, every test object is reclassified.  
        If the recalculate parameter is set to False, the classification
        scores are retrieved from the database.

        TODO:  Check for missing classification scores and recalculate
           as required.
        """
        verbosity = config.getVerbosity( "sql" )
        if recalculate:
            self.svmodel.classify( self.testset )
        L = [ (im.getOneFeature(self.svmodel.feature),im.label)
               for im in self.testset ]
        labels = self.svmodel.model.labels()
        if verbosity > 1:
            print "[SVMPerformance]", labels
        R = [ (labels[predict(s)],l) for (s,l) in L ]
        N = len(R)
        FP = R.count( (1,0) )
        TP = R.count( (1,1) )
        FN = R.count( (0,1) )
        TN = R.count( (0,0) )
        print "FP=%s - FN=%s - TP=%s - TN=%s" % (FP,FN,TP,TN)
        if FP+TN == 0:
            self.FP = 0
        else:
            self.FP = float(FP) / (FP+TN)
        if FN+TP == 0:
            self.FN = 0
        else:
            self.FN = float(FN) / (FN+TP)
        self.accuracy = float(TP+TN) / N
        self.list = L
        return 

    @classmethod
    def getRows(cls):
        return ( x.getRow() for x in cls.select( orderBy="svmodel_id" ) )
    def getRow(self):
        return {
          "Feature Vector" : self.svmodel.fvector.key,
          "TrainingSet"    : self.svmodel.testset.name,
          "Test Set"       : self.testset.name,
          "FP"             : self.FP,
          "FN"             : self.FN,
          "Accuracy"       : self.accuracy,
        }

def newModel( fskey, key, fvkey, tset, fsdesc=None, desc=None, **kw ):
    """
    Create a new SVModel object and necessary related records.
    """
    T = TestSet.byName( tset )
    try:
        fset = FeatureSet.byKey( fskey )
    except:
        fset = FeatureSet( key=fskey, matrix=False, symidx=False,
                description=fsdesc )
    try:
        feature = Feature( cat=fset, key=key, description=desc )
    except StandardError as e:
        if not isDuplicateError(e):
            print "[newModel] Unknown error."
            raise e
        feature = Feature.byKey( key )
        if feature.cat != fset:
            raise dberrors.IntegrityError, \
                "Clash with existing feature.  Feature set does not match."
    fv = FeatureVector.byKey( fvkey )
    try:
        mod = SVModel.new( testset=T, feature=feature, fvector=fv, **kw )
    except StandardError as e:
        if not isDuplicateError(e):
            print "[newModel] Unknown error."
            raise e
        mod = SVModel.byFeatureID( feature )
        if mod.testset != T:
            raise dberrors.IntegrityError, \
               "Clash with existing SVModel.  Test set does not match."
        if mod.fvector != fv:
            raise dberrors.IntegrityError, \
                 "Clash with existing SVModel.  Feature does does not match."
    return mod

def testSVM( training=False, key=None ):
    """Queue a performance test of every SVModel object in the database. 

    If key is given, every model is tested on the corresponding TestSet
    object.  Otherwise, it is tested on the training set if the training
    argument is set to True, or on the canonical test set if it is set
    to False (default).
    """
    count = 0
    for m in SVModel.select():
        if m.modfile == None:
            print "Model has not been trained"
            print m
        else:
            if key != None:
                k = key
            elif training:
                k = m.testset.name 
            else:
                k = m.testset.name + "_test"
            print "[testSVM]", k
            T = TestSet.byName( k )
            if perfQueue( T, m ) != None: count += 1
    print "[testSVM]", count, "new tasks queued"

def perfQueue( T, m ):
    """Queue a performance test of model m on TestSet T, unless a
    performance record already exists."""
    L = SVMPerformance.selectBy( svmodel=m, testset=T )
    N = L.count()
    if N > 0:
        print "[perfQueue] Model has been evaluated.", N
        print  m
        print  T
        for ev in L: print ev
        return None
    else:
        q = Queue( image=None, entered=dt.datetime.now(), testset=T, svmodel=m )
        print "New test queued"
        print m
        print q
    return q

def newSVM( trainingset, fvlist, fsdesc=None, **kw ):
    """
    Add a new SVModel for the given trainingset and every feature
    vector in fvlist.  Queue all the new models for training.
    If a model already exists, no new model is created with the
    same parameters.
    """
    newcount = 0
    verbosity = config.getVerbosity( "sql" )
    if trainingset == None:
        for t in TestSet.select(): 
            if t.name[-5:] != "_test":
                newcount += newSVM( t, fvlist, fsdesc, **kw )
        if verbosity > 0:
            print "[newSVM] total of", newcount, "new SVM models"
        return newcount
    if not fvlist:
        fvlist = list(FeatureVector.select())
    if isinstance( trainingset, SQLObject ):
        T = trainingset
        trainingset = T.name
    else:
        T = TestSet.byName( trainingset )
    fskey = trainingset + "SVM"
    try:
        fset = FeatureSet.byKey( fskey )
    except:
        fset = FeatureSet( key=fskey, matrix=False, symidx=False,
            description=fsdesc )
    if verbosity > 0:
        print "[newSVM]", fset
    for fvkey in fvlist:
        if isinstance(fvkey,SQLObject):
            fv = fvkey
            fvkey = fv.key
        else:
            fv = FeatureVector.byKey( fvkey )
        modlist = SVModel.selectBy( fvector=fv, testset=T )
        modcount = modlist.count()
        modkey =         trainingset + "-" + fvkey
        desc="SVM model (%s,%s)" % (trainingset,fvkey)
        if modcount > 0:
            if verbosity > 0:
                print modkey, modcount, "existing models"
            if verbosity > 1:
                for m in modlist: print m 
        else:
            try:
                feature = Feature( cat=fset, key=modkey, description=desc )
            except StandardError as e:
                if not isDuplicateError(e):
                    print "[newSVM] Unknown error."
                    raise e
                feature = Feature.byKey( modkey )
                if feature.cat != fset:
                    raise dberrors.IntegrityError, \
                         "Clash with existing feature.  Feature set does not match."
            mod = SVModel.new( testset=T, feature=feature, fvector=fv, **kw )
            q = Queue( image=None, entered=dt.datetime.now(), svmodel=mod )
            if verbosity > 1:
                print "new", mod
                print q
            newcount += 1
    if verbosity > 0:
        print "[newSVM]", newcount, "new SVM models"
    return newcount
