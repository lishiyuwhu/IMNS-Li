# (C) 2012: Hans Georg Schaathun <hg@schaathun.net> 
## -*- coding: utf-8 -*-

"""
Reporting, feature dumps, and outher output.

:Module:    pysteg.sql.tools
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2012: Hans Georg Schaathun <georg@schaathun.net>

Selection of functions to produce reports and other output 
from the feature database.
"""

from pysteg.sql import *
import sys
import svm.tools as svt
import _scaling 
import svmodel 

def savefeatures(fn,imgset,fv,*a,**kw):
    """Save features in a text file, taking features from the
    imageset imgset and feature vector fv.  The output filename
    is given by fn.  The output is libSVM's sparse format by default,
    but specifying the keyword argument libsvm=False gives comma
    separated values instead.
    """
    (ll,vl,i) = imgset.getFeatures(fv)
    fvl = [ [l] + v for (l,v) in zip(ll,vl) ]
    return svt.savefeatures(fn,fvl,*a,**kw)

def saveScaledFeatures(fn,imgset,model,*a,**kw):
    """Save scaled features in a text file, taking features from the
    imageset imgset and SVM model model.  The output filename
    is given by fn.  The output is libSVM's sparse format by default,
    but specifying the keyword argument libsvm=False gives comma
    separated values instead.

    TODO: fix this - avoid call to non-existent function scaling.applyScale.
    """
    if not isinstance(model,SQLObject):
        model = svmodel.SVModel.byKey( model )
    fv = model.fvector
    (ll,vl,i) = imgset.getFeatures( fv )
    sm = model.getScaleModel()
    raise NotImplementedError, "This functions needs updating"
    # vl = scaling.applyScale(sm,vl)
    fvl = [ [l] + v for (l,v) in zip(ll,vl) ]
    return svt.savefeatures(fn,fvl,*a,**kw)

def calculated():
    """
    Print a report for each image set showing which features have been 
    calculated and recorded in the database.  This is a slow operation.
    """
    for s in ImageSet.select():
        N = s.images.count()
        print s.name, N, "images"
        for fs in FeatureSet.select():
            dim = fs.features.count()
            L = [ len(img.getFeatures(fs)) for img in s ]
            count = len( [ i for i in L if i==dim ] )
            zero = len( [ i for i in L if i==0 ] )
            if count == N:
                print "%s: complete" % ( fs.key, )
            elif zero == N:
                print "%s: not started" % ( fs.key, )
            else:
                print "%s: %s images calculated out of %s" % (
		      fs.key, count, N )
                partial = N - zero - count
                print "%s: %s images partially calculted" % ( fs.key, partial )
            sys.stdout.flush()
        print

if __name__ == "__main__":
    sqlConnect()
    calculated()
