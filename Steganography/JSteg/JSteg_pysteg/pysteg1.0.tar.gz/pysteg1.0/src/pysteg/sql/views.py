#! /usr/bin/env python
## -*- coding: utf-8 -*-
## (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

"""
This module defines a scaling model, to scale features prior to 
classification.  It is used by the SVModel class, but is designed
with loose coupling to facilitate reuse with other classification
algorithms.

The ScaleModel class implements some of the interface of FeatureVector
and can be used in lieu thereof when getting feature values from
images.

The implementation is slow.  Each feature value depends on three
tables and three records are queried separately from Feature,
FeatureValue, and Scaling.  Combining the three in one view 
to be queried in one operation is expected to be faster.

This module will auto-connect to the database and must be loaded
after options have been processed, to ensure correct connection.
The reason for this is that it depends on views defined server side.
"""

print "[pysteg.sql.views]"

from sqlobject import *
from . import *

sqlConnect()

class ScaledFeatureValue(SQLObject):
   """This is an attempt to start on an object to fetch multiple
   SQL records in one operation to save time.  NOT COMPLETE.
   """
   class sqlmeta:
      fromDatabase = True
      columnList = True
      idName = "id"
      idType = str

   #key = StringCol()
   #value = FloatCol()
   #rawvalue = FloatCol()
   #addterm = FloatCol()
   #factor = FloatCol()
   #image  = ForeignKey("Image")
   #scalemodel  = ForeignKey("ScaleModel")

   @classmethod
   def getFeatures(cls,image,scalemodel,verbosity=0):
      try:
	 iid = image.id
      except AttributeError:
	 iid = image
      try:
	 sid = scalemodel.id
      except AttributeError:
	 sid = scalemodel
      if verbosity > 2:
	 print "[ScaledFeatureValue.getFeatures]", iid, sid
      return cls.selectBy( imageID=iid, scalemodelID=sid )

   def getFID(self):
      return self.fid
   def __cmp__(self,r):
      return cmp(self.getFID(),r.getFID())
   def getValue(self):
      "Return the scaled feature value."
      return self.value
