## $Id$
## -*- coding: utf-8 -*-

"""
ssteg - Steganography in the Spatial Domain.

:Module:    pysteg.ssteg
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

Currently only the LSB module is available, providing
LSB replacement and LSB matching.
"""

# ***********************************
# Steganography in the Spatial Domain
# ***********************************
#
# .. automodule:: pysteg.ssteg
# 
#   
# .. toctree::
#    :maxdepth: 2
#   
#    lsb.py.txt
#   
