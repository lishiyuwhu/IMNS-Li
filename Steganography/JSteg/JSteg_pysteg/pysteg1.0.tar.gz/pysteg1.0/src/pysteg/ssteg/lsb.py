## $Id$
## -*- coding: utf-8 -*-

"""
ssteg.lsb - LSB embedding in the spatial domain

:Module:    pysteg.ssteg.lsb
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <H.Schaathun@surrey.ac.uk> 2010
"""

# The LSB Module
# ==============
# 
# 
# ::

import numpy as np
import numpy.random as rnd
import scipy as sp

__all__ = [ "rndembed", "lsbembed", "lsbextract", "rndbits", "invperm" ]

#class bitstring(np.ndarray)
  #def __init__(self,L):

def rndembed( I, rate=0.5, **kw ):
   "Embed a random message with the given rate in the image I."
   msglength = np.floor( I.size * rate )
   M = rndbits( msglength ) 
   key = rnd.get_state()
   return lsbembed( I, M, key=key, **kw )

def invperm(P):
  """
    Return the inverse of the permutation P.
  """
  I = np.ones( len(P), dtype=int )
  I[P] = array( range(len(P)) )
  return I

def join(L):
  """
    Take a list of lists and join (concatenate) the elements.
  """
  return reduce(lambda x, y : x + y, L )

def int2bit(L,length=8):
  """
    Write an integer L in base 2, giving a list of {0,1} of the
    given length.  If length=0, 32 is used for type int, and
    for type long the length is the smallest length required to
    represent the number.
  """
  if length == 0:
    if type(L) == int: length = 32
    elif type(L) == long: length = ceil(sp.log2(L))
    else: raise Exception, "Unrecognised type %s" % (type(L),)
  return [ (L>>i) %2 for i in xrange(length-1,-1,-1) ]

def str2bit(S,length=8):
  """
    Convert a string S to binary, assuming characters of length
    bits.  The result is a list of integers.
  """
  return np.array( join( [ int2bit(ord(s),length) for s in S ] ),
              dtype=np.uint8 )

def bit2int(L):
  N = len(L) 
  R = sum ( [ L[N-1-i]*2**i for i in xrange(N) ] )
  return R
def bit2str(L,length=8):
  """
    Convert a string S to binary, assuming characters of length
    bits.  The result is a list of integers.
  """
  I = [ bit2int( L[i:i+8] ) for i in xrange(0,len(L),8) ] 
  i = 0 
  S = u""
  while i < len(I):
    if I[i] > 127:
      n = (I[i]&31 )*64 + (I[i+1]&63)
      C = unichr(n)
      S += C
      i += 2
    else:
      S += unichr(I[i])
      i += 1
  return S

def any2bit(L):
  """
    Convert a variety of types to bit strings, represented
    as lists of integers.
    (This does not work reliably.)
  """
  if isinstance(L,str): return str2bit(L)
  if isinstance(L,int): return int2bit(L)
  if isinstance(L,long): return int2bit(L)
  if isinstance(L,list):
    return reduce(lambda x, y : x + y, map(bitstring,L) )
  raise Exception, "No support for type %s" % (type(L),)

def bitstring(L):
  """
    Convert a variety of types to bit strings, represented
    as 1D numpy arrays.
    (This does not work reliably.)
  """
  return np.array(any2bit(L),dtype=uint8)

def rndbits(l):
  """
    Return a random bitstring of length l.
  """
  return rnd.randint(2,size=l).astype(np.uint8)

def getperm(L,key):
  if type(key) == tuple:
    rnd.set_state(key)
  else:
    rnd.seed(key)
  return rnd.permutation(L)

def lsbembed(cover,message,key=None,rotate=False,replace=True):
  """
    Embed message in a cover using LSB embedding.
    The cover is assumed to be a numpy grayscale image (2D array).
  """
  if isinstance(message,str): M = str2bit(message)
  else: M = message
  (I,P,Sh) = im2sig( cover, key, rotate )
  minpix = 0
  maxpix = 255
  if np.max(cover) > maxpix: maxpix = 256**2-1
  L = len(M)
  if replace:
    I[:L] -= I[:L]%2
    I[:L] += M
  else:
     M1 = np.sign(np.random.randn(L)) * ( M ^ (I[:L]%2) )
     print np.max(M1), np.min(M1)
     M1[(I[:L]==minpix) & (M1<0)] = +1
     M1[(I[:L]==maxpix) & (M1>0)] = -1
     I[:L] += M1
  if key == None:
    I1 = I.reshape(Sh)
  else:
    I1 = I[P].reshape(Sh)

  #T = I1.astype(float) - cover
  #print np.max(T), np.min(T)
  if rotate:
    return np.transpose(I1)
  else:
    return I1

def im2sig(cover,key=None,rotate=False):
  S = cover.size
  if rotate:
    I0 = np.transpose(cover)
  else:
    I0 = cover
  Sh = I0.shape
  if key != None:
    P = getperm(S, key)
    I = np.zeros(S,dtype=cover.dtype)
    I[P] = I0.flatten()
    return (I,P,Sh)
  else:
    return (I0.flatten(),None,Sh)

def lsbextract(cover,key=None,length=None,convert=None,rotate=False):
  """
    Extract a message from a cover embedded with LSB embedding.
    The cover is assumed to be a numpy grayscale image (2D array).
    The key is not currently used.  If convert is specified, it
    should be a function accepting a bitstring (1D numpy array of
    {0,1}) as input, outputting whatever data type is desired.
  """
  (I,P,Sh) = im2sig( cover, key, rotate )
  if length != None: M = I[:length] % 2
  else: M = I % 2
  if convert != None: M = convert(M)
  return M
