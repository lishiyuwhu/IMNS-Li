# $Id$

"""
Statistical steganalysis and related functions.

This package provides definitions for statistical steganalysis,
such as RS and chi square tests for LSB embedding in pixmap images.
The package is standalone, totally independent of pysteg.analysis
which provides feature extraction for use with machine learning.
"""
