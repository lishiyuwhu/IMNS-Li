## $Id$
## -*- coding: utf-8 -*-

"""
RS steganalysis
"""

singular  = -1
regular   = +1
unchanged =  0

# Options:
#   2d/1d
#   choice of mask
#   disjoint or overlapping groups

import numpy as np

def solve(a,b,c):
   """
   Solve a quadratic equation with coefficients a, b, and c.
   A pair of two solutions is returned.
   """
   s = np.sqrt( b**2 - 4*a*c )
   return ( ( -b + s ) / ( 2*a ), ( -b - s ) / ( 2*a ), )

def smoothness1d(x):
   """
   Calculate the smoothness f() as defined in Eq. (8) in 
   Fridrich et al (2003).  
   """
   x1 = np.array( x[:-1] )
   x2 = np.array( x[1:] )
   return np.sum( np.abs( x1 - x2 ) )

def smoothness2d(x):
   """
   Calculate the smoothness f() of a 2D pixel group.
   """
   r = np.sum( np.abs( x[:-1,:] - x[1:,:] ) )
   r += np.sum( np.abs( x[:,:-1] - x[:,1:] ) )
   return r

def smoothness(x):
   """
   Calculate the smoothness f() of a pixel group.
   In the case where x is multi-dimensional, say 2x2 as suggested
   by Fridrich et al (2001), it is unclear in the sources how to
   calculate the smoothness.
   """
   if not has_attr(x, "shape" ): return smoothness1d(x)
   elif len(x.shape) == 2: return smoothness2d(x)
   else: return smoothness1d(x)
   raise ValueError

class rs(object):
   """
   A class to do part of the calculations for RS steganalysis.
   The class is intantiated with a mask, and all subsequent
   calculations are subject to that mask.  This is done as
   a class in order to calculate constants derived from the
   mask once and for all and thus speed up subsequent functions.
   """
   def __init__(self,mask,verbosity=0):
      self._verbosity = verbosity
      self.amask = np.abs(mask)
      self.cmask = - mask
      self.cmask[(mask > 0)] = 0
      if len(mask.shape) == 1: self.smoothness = smoothness1d
      elif len(mask.shape) == 2: self.smoothness = smoothness2d
      else: raise ValueError
   def flip(self,x):
      return (x.astype(int) + self.cmask) ^ self.amask - self.cmask
   def groups(self,img):
      """
      Return an iterator over all the pixel groups in image img.
      """
      if len(self.amask.shape) == 1:
        X = img.flatten()
	l = len(X)
	ml = len(self.amask)
        for i in xrange(l-ml): yield img[i:(i+ml)]
      elif len(self.amask.shape) == 2:
        (m,n) = img.shape
        (x,y) = self.amask.shape
        for i in xrange(m-x):
          for j in xrange(n-y):
	     yield img[i:(i+x),j:(j+y)]
      else:
	 raise ValueError, "Mask should be 1D or 2D."
   def analyse(self,img):
      if self._verbosity: print type(img), img.dtype
      L = [ self.classify(G) for G in self.groups(img) ]
      N = len(L)
      return (float(L.count(regular))/N, float(L.count(singular))/N)
   def classify(self,x):
      """
      Classify the pixel group x, return singular (-1) if x is in S,
      regular (+1) if x is in R, and unchanged (0) if x is in U;
      using the notation of Fridrich et al (2003).
      """
      return np.sign( self.smoothness(self.flip(x)) - self.smoothness(x) )
   def diff(self,*a,**kw):
      (R,S) = self.analyse(*a,**kw)
      if self._verbosity: print "(R,S) = ", (R,S)
      return R - S

def rsestimate(img,mask,verbosity=0):
   """
   Estimate the length of the embedded message in image img,
   using RS steganalysis with mask mask.
   """
   X = img.astype(int)
   O = rs(mask,verbosity)
   d0 = O.diff(X)
   d1 = O.diff(X^1)
   O = rs(-mask,verbosity)
   dn0 = O.diff(X)
   dn1 = O.diff(X^1)
   (p0,p1) = solve( 2*(d1+d0), (dn0 - dn1 - d1 - 3*d0), (d0-dn0) ) 
   if np.abs(p0) < np.abs(p1): z = p0
   else: z = p1
   if verbosity: print "(p0,p1) =", (p0,p1), "; z =", z
   return z / (z-0.5)

# Early drafts::

def flippos(x):
   """
   The LSB flipping function F_1 as defined by Fridrich et al (2003).
   """
   return x ^ 1
def flipnaught(x):
   """
   The identity function.  This is F_0 in the notation of 
   Fridrich et al (2003).
   """
   return x
def flipneg(x):
   """
   The shifted LSB flipping function F_{-1} as defined by
   Fridrich et al (2003) in Eq (9).
   """
   return flip(x.astype(int)+1) - 1

