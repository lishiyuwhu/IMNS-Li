## $Id$
## -*- coding: utf-8 -*-

"""
Generic auxiliary functions.
  
This functiona are used in, but not particular to, the pysteg project.

:Module:    pysteg.tools
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey, UK
            © 2011: Høgskolen i Ålesund, Norway
:Author:    Hans Georg Schaathun <georg@schaathun.net> (2010-2011)
"""

import numpy as np
import pickle

def norm(S,alpha=1):
  """Calculate the L_alpha norm of S, where S can be any sequence-like
  data type, including a list or one-dimensional matrix or array.
  """
  return sum( [ abs(x)**alpha for x in S ] )**(1.0/alpha)

def txtwrite(s,outfile):
  "Take a string s and write it to outfile."
  f = open(outfile,"w")
  f.write(s)
  f.close()
  return s

def txtread(infile):
  "Read a text file (infile) and return a string."
  f = open(infile,"r")
  s = f.read()
  f.close()
  print s
  return s

def getfilename(fn):
  """
    Given a pathname fn, return just the filename, stripping the
    directory component.
  """
  return fn.rsplit("/",1)[-1]

def fnsplit(fn):
  """
    Given a filename fn, return a tuple (dir,base,ext),
    where dir is the directory part including a trailing slash
    unless empty, ext is the extension including the dot,
    and base is the remaining base filename.
  """
  L = fn.rsplit("/",1)
  if len(L) == 1: L = [""] + L
  else: L[0] += "/"
  K = L[1].rsplit(".",1)
  if len(K) == 1: K.append("")
  else: K[1] = "." + K[1]
  return (L[0],K[0],K[1])

def rev(L):
  """
    Reverse the order of a list.
    This is a functional alternative to list.reverse() which 
    reverses the list in place.  The functional approach means
    that the reversed list can be used in an expression without
    explicitely being copied or assigned to a name.
  """
  print "rev", type(L), len(L)
  if len(L) < 2: return L
  else:
    N = len(L)/2
    return rev(L[N:]) + rev(L[:N])

# The :func:`loadObject` and :func:`saveObject` functions are 
# designed to be generic, and can process arbitrary objects.
#
# ::

def loadObject(fn,verbosity=None):
  "Load a pickled object from the given filename."
  if verbosity != None: print "[loadObject] Read file", fn
  f = open(fn,"rb")
  try:
    R = pickle.load(f)
  except EOFError as e:
     print "EOFError: file is probably corrupt: ", fn
     raise e
  f.close()
  print "[loadObject] File %s, type %s" % (fn,type(R))
  return R

def saveObject(X,fn,verbosity=None):
  "Save a pickled object from the given filename."
  if verbosity != None: print "[saveObject] Save file", infile
  f = open(fn,"wb")
  R = pickle.dump(X,f)
  f.close()

