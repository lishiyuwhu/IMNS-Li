## $Id: __init__.py 1596 2010-07-18 15:56:07Z css1hs $
## -*- coding: utf-8 -*-

"""
Generic test function script for steganographic embedding in JPEG.

:Module:    pysteg.tsteg
:Date:      $Date: 2010-07-18 16:56:07 +0100 (Sun, 18 Jul 2010) $
:Revision:  $Revision: 1596 $
:Copyright: © 2010: University of Surrey, UK
:Author:    Hans Georg Schaathun <georg@schaathun.net>
"""

import string
from jpeg import jpeg
from jsteg import message
from jsteg.exceptions import *

def tsteg(stegoclass,file,N):

  # The jpeg call loads the given file and returns a jpeg object.
  # The object includes a secret key, which is random by default
  im = jpeg( file )

  # Store the secret key.  
  K = im.getkey() 
  print "KEY:", K

  # Extract the AC coefficients of im as a coefficient object
  # For F5, stegoclass = f5v2
  S = stegoclass( im.getsignal(), rndkey=True )  

  # Generate a random message of N bytes
  M = message( random=N )

  # The Stego object has methods to embed and extract messages.
  # Now, embed the message M in S.
  try:
    S.msgEmbed(M)
  except CapacityException, e:
    print "Capacity Exceeded"
    print "Embedded %i of %i bits." % (S.embedded,8*len(M))

  # Store some diagnostics
  D = S.embeddingReport()
  D["Capacity"] = S.getcapacity()

  # Reinsert the modified coefficient (with steganographic embedding)
  # into the image.
  im.setsignal(S)

  # Finally, save the image
  outfile = "stego" + string.split( file, "/" )[-1]

  im.save( outfile )

  # Delete objects before we start testing
  del(im)
  del(S)

  # Load the stego image
  im = jpeg( outfile, key=K )
  
  # Extract the AC coefficients from the image
  S = stegoclass(im.getsignal()) 
  
  # Extract the message from the AC coefficients
  R = S.msgExtract()

  
  # Finally, compare the original message with the extracted one
  if M.isequal(R):
    print "Test SUCCESSFUL"
    D["Result"] = True
  else:
    print "ERROR: extracted message does not match."
    D["Result"] = False
  
  # The return value is a dictionary of diagnostic data
  return D
