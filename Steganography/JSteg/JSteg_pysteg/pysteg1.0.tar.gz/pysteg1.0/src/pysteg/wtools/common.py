## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    pysteg.wtools.common
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <H.Schaathun@surrey.ac.uk> 2010
"""

# ********************
# pysteg.wtools.common
# ********************
#   
# .. module:: pysteg.wtools.common
#   
# 
# ::

import numpy as np
import pywt
from qmf import qmfWavelet

def quant(A):
  A = np.round(A)
  A[( A > 255 )] = 255
  A[( A < 0 )] = 0
  return np.array( A, dtype=np.uint8 )

def getWavelet(name):
  if name[:3] == "qmf": return qmfWavelet(name)
  else: return pywt.Wavelet(name)
