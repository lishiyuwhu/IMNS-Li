## $Id$
## -*- coding: utf-8 -*-

"""
Create a visual illustrations of wavelet decomposition of images.

:Module:    pysteg.wtools.dwtview
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <H.Schaathun@surrey.ac.uk> 2010
"""

# *********************
# pysteg.wtools.dwtview
# *********************
#   
# .. module:: pysteg.wtools.dwtview
#   
# 
# ::

import numpy as np

def wtview1(T0,T1,B=255):
  """
    Handle the recursive case of of wtview().
  """
  print T0.shape, T1[0].shape
  r0 = np.hstack([T0,T1[0]+B])
  print T1[1].shape, T1[2].shape
  r1 = np.hstack([T1[1]+B,T1[2]+B])
  return np.vstack([r0,r1])/2

def wtview(L):
  """
    Combine a wavelet decomposition into a single matrix (numpy.array)
    for display.
  """
  if len(L) == 0:
    return None
  elif len(L) == 1:
    return np.array(L[0],dtype=np.uint8)
  else:
    #print L[2:]
    T = wtview1(L[0],L[1])
    #print T
    return wtview([T]+list(L[2:]))
