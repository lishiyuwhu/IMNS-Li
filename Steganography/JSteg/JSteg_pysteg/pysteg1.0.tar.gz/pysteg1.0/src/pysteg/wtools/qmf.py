## $Id$
## -*- coding: utf-8 -*-

"""
Generate Simoncelli's QMF Wavelet for use with pywt.

:Module:    pysteg.wtools.qmf
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: University of Surrey
:Author:    Hans Georg Schaathun <H.Schaathun@surrey.ac.uk> 2010
"""

# *****************
# pysteg.wtools.qmf
# *****************
#   
# .. module:: pysteg.wtools.qmf
#   
# ::


from scipy import sqrt,ceil
from pywt import Wavelet

QMFtable = {
  "qmf5" : [ -0.076103, 0.3535534, 0.8593118, 0.3535534, -0.076103 ],
  "qmf9" : [ 0.02807382, -0.060944743, -0.073386624, 0.41472545, 0.7973934, 
          0.41472545, -0.073386624, -0.060944743, 0.02807382 ],
  "qmf13" : [ -0.014556438, 0.021651438, 0.039045125, -0.09800052,
          -0.057827797, 0.42995453, 0.7737113, 0.42995453, -0.057827797, 
          -0.09800052, 0.039045125, 0.021651438, -0.014556438 ],
  "qmf8" : map( lambda x : x*sqrt(2),
            [0.00938715, -0.07065183, 0.06942827, 0.4899808,
            0.4899808, 0.06942827, -0.07065183, 0.00938715 ] ),
  "qmf12" : map( lambda x : x*sqrt(2),
     [-0.003809699, 0.01885659, -0.002710326, -0.08469594,
       0.08846992, 0.4843894, 0.4843894, 0.08846992, -0.08469594,
       -0.002710326, 0.01885659, -0.003809699 ] ),
  "qmf16" : map( lambda x : x*sqrt(2),
           [0.001050167, -0.005054526, -0.002589756, 0.0276414, 
            -0.009666376, -0.09039223, 0.09779817, 0.4810284, 0.4810284,
            0.09779817, -0.09039223, -0.009666376, 0.0276414, -0.002589756,
            -0.005054526, 0.001050167 ] ),
}

def hfilt(filt):
  sz = len(filt)
  sz2 = ceil(float(sz)/2) - 1
  h = [ filt[i]*(-1)**(i-sz2) for i in xrange(sz-1,-1,-1) ]
  return h

def rev(filt):
  """
    Reverse the order of a list.
    This is a functional alternative to list.reverse() which 
    reverses the list in place.  The functional approach means
    that the reversed list can be used in an expression without
    explicitely being copied or assigned to a name.
  """
  sz = len(filt)
  return [ filt[i] for i in xrange(sz-1,-1,-1) ]

def qmfWavelet(name):
  """
    Return a Wavelet object representing the given QMF wavelet.
  """
  lf = QMFtable[name] 
  if len(lf) % 2 == 1: lf = lf + [0]
  hf = hfilt(lf)
  f = ( lf, hf, rev(lf), rev(hf) )
  return Wavelet(name,f)

