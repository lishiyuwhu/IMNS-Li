#! /usr/bin/env python
# $Id$

from optparse import OptionParser
import numpy.random as rnd
import shutil

parser = OptionParser("""
  rndsplit.py  -s stegodir -c coverdir [-m] img1 img2 ...

  Randomly copy half of the images (img1, img2,...) to each of
  the directories stegodir and coverdir.  If -m is given,
  move the files instead of copying.
""")

parser.add_option("-s", "--stego-dir", help="Stego directory",
          dest="dir" )
parser.add_option("-c", "--cover-dir", help="Cover image directory",
          dest="cdir" )
parser.add_option("-m", "--move", help="Move (remove original)",
          dest="move", default=False, action="store_true" )

(options,args) = parser.parse_args()

rnd.seed()
fl = rnd.permutation(args)
if options.move: cmd = shutil.move
else: cmd = shutil.copy

L = len(fl)/2 
print len(fl), L

for infile in fl[L:]:
  cmd(infile, options.dir)
for infile in fl[:L]:
  cmd(infile, options.cdir)
