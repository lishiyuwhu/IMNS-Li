#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

docstring="""
Perform RS steganalysis

:Script:    rs.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""


from pysteg.imtools import *
from PIL import Image
import pysteg.stats.rs as rs
import numpy as np

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-v", "--verbose", 
          help="Verbosity level", default=0, dest="verbosity" )
(options,args) = parser.parse_args()
verbosity = int(options.verbosity)

mask = np.array( [[1,0],[0,1]] )

def main():
   global verbosity
   for infile in args:
     X = np.array( Image.open ( infile ) )
     # X = imread( infile )
     if verbosity:
        print type(X), X.shape, X.dtype
        print np.max(X), np.min(X)
     p = rs.rsestimate(X,mask,verbosity=verbosity)
     print infile, p
 
if __name__ == "__main__":
    main()
