#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

"""
  Quick script make scatter plots of the co-occurrence matrix of an image.
"""

import sys
sys.path = sys.path + [ "../../Packages", "..", "." ]

# from pysteg.tools import *
from PIL import Image
import numpy as np
import shutil
from pysteg.analysis.markov import splitMatrix,differenceMatrix
import pysteg.analysis.markov as mark

# import traceback, pickle

# Parse options
import optparse 
parser = optparse.OptionParser()
parser.add_option("-o", "--outfile",
          help="Output generated steganogram to specified filename.",
          dest="outfile" )
parser.add_option("-d", "--dir",
          help="Direction of pixel pairs (h,v,d,m).",
	  default="h", dest="dir" )
parser.add_option("-c", "--colour",
          help="Colour of plot points",
	  default="k", dest="col" )
parser.add_option("-D", "--difference-histogram",
          help="Make histogram plot of difference matrix.",
	  default=False, action="store_true", dest="diff" )
parser.add_option("-H", "--histogram-3d",
          help="Make a 3-D bar plot instead of scatter plot.",
	  default=False, action="store_true", dest="hist2d" )
parser.add_option("-2", "--difference-matrix",
          help="Colour of plot points",
	  default=False, action="store_true", dest="diff" )
parser.add_option("-j", "--jpeg",
          help="Analyse the JPEG matrix instead of the pixmap",
	  default=False, action="store_true", dest="jpeg" )
parser.add_option("-x", "--x-frequency",
          help="The vertical frequency to consider (JPEG only)",
	  dest="xfreq" )
parser.add_option("-y", "--y-frequency",
          help="The horizontal frequency to consider (JPEG only)",
	  dest="yfreq" )
# Currently unused
parser.add_option("-v", "--verbose", 
          help="Verbosity level", dest="verbosity" )

(options,args) = parser.parse_args()

# Main loop

def mkplot(X,f,**kw):
   if options.hist2d:
      return mark.hist2plot(X,f, **kw )
   elif options.diff:
      return mark.diffhistplot(X,f, **kw )
   else:
      return mark.scatterplot(X,f, **kw )
def main():
  for infile in args:
    kw = {
	  "dir" : options.dir,
	  "col" : options.col,
	  }

    if options.outfile == None:
      (d,f,e) = fnsplit( infile )
      outfile = d + f + "-scatter.pdf"
    else:
      outfile = options.outfile
    if options.jpeg:
      from pysteg.jpeg import jpeg
      X = jpeg( infile ).getCoefMatrix("Y")
      kw["alpha"] = 0.2
      kw["s"] = 0.2
      kw["linewidth"] = 1
      kw["lim"] = (-5,5)
    else:
      kw["lim"] = (0,256)
      X = np.array( Image.open( infile ) )
    if options.xfreq != None:
      from pysteg.jpeg.base import getfreq
      assert options.yfreq != None
      X = getfreq( X, int(options.xfreq), int(options.yfreq) )
    print infile, X.shape
    if options.diff:
      X = differenceMatrix( X, options.dir, 256 )
    mkplot(X,outfile,**kw)
  if len(args) == 0:
    X = np.random.randn(300,300)
    mkplot(X,options.outfile)

if __name__ == "__main__":
    main()
