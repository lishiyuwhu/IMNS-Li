#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# :Script:    select.py
# :Date:      $Date$
# :Revision:  $Revision$
# :Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
#
# This script is used to evaluate features using information theory.
#
# We have to choose a batch friendly engine for matplotlib, before
# other packages load pyplot::

from itml.select import fvSelect
from itml.bfs.bfselect import bfSelect, abstractSelect
import pysteg.tools as pt 
import optparse 

# Parse options
# -------------
#
# ::

parser = optparse.OptionParser()
parser.add_option("-i", "--infile",
          help="Input file (pickled fvEval or fvSelect object).",
          dest="infile" )
parser.add_option("-O", "--outbase",
          help="Base filename for each intermediate ranking.",
          dest="outbase" )
parser.add_option("-d", "--pickle-after",
          help="Filename pickling the select object after selection.",
          dest="datfile2" )
parser.add_option("-D", "--pickle-before",
          help="Filename pickling the select object before selection.",
          dest="datfile" )
parser.add_option("-o", "--outfile",
          help="Text output file.",
          dest="outfile" )
parser.add_option("-S", "--scale",
          help="Scale the features before ranking.",
          default=False, action='store_true',
          dest="scale" )
parser.add_option("-x", "--exclude-extremal", 
          help="Exclude objects with feature exceeding /exclude/ std. deviations.",
          dest="exclude" )
parser.add_option("-H", "--heuristic", 
          help="Specify the heuristic to use.",
          default="JMI",dest="heuristic" )
parser.add_option("-b", "--beta", 
          help="beta parameter for Gavin Brown's formula",
          default=1,dest="beta" )
parser.add_option("-g", "--gamma", 
          help="gamma parameter for Gavin Brown's formula",
          default=1,dest="gamma" )
parser.add_option("-N", "--dimension", 
          help="Number of features to be selected",
          default=50,dest="N" )
parser.add_option("-v", "--verbose", 
          help="Verbosity level",
          default=2,dest="verbosity" )
parser.add_option("-p", "--parallel", 
            help="Accept client connections for parallel processing.",
            dest="parallel", default=False,
	    action='store_true' )
parser.add_option("-P", "--port", help="Port number", dest="port" )
(opt,args) = parser.parse_args()

# Interpret options
# -----------------
#
# ::

def cleanops(opt):
  opt.verbosity = int(opt.verbosity)
  opt.N = int(opt.N)
  opt.beta = float(opt.beta)
  opt.gamma = float(opt.gamma)
  if opt.exclude != None: opt.exclude = int(opt.exclude)
  return opt

# Main Functionality
# ------------------
#
# ::

def main():
   cleanops(opt)
   assert opt.infile != None, "Input file is required"
   ev = pt.loadObject(opt.infile)
   if isinstance(ev,abstractSelect):
      sv = ev
   else:
      (C,S,T) = ev._getArrays(opt.scale)
      ev.load()
      if opt.heuristic == "BFS":
        sv = bfSelect(C,S,T,names=[ p[1] for p in ev.listFeatures() ] )
      else:
	ev.load()
        sv = fvSelect(C,S,T,names=[ p[1] for p in ev.listFeatures() ],
	     exclude=opt.exclude,verbosity=opt.verbosity,
	     alg=opt.heuristic, beta=opt.beta,gamma=opt.gamma)

# In parallel mode, we wrap the test object in a :class:`servSelect`
# object.
#
#   ::

   if opt.parallel:
      if opt.port: port = int(opt.port)
      else: port = opt.port
      print "[select] using port", port
      import itml.servselect as serv
      psv = serv.servSelect( sv, port=port )
   else: psv = sv

   if opt.datfile != None: pt.saveObject(sv,opt.datfile)
   psv.select(opt.N)
   if opt.datfile2 != None: pt.saveObject(sv,opt.datfile2)
   if opt.outfile != None: sv.printRanking(opt.outfile) 
   if opt.outbase != None: sv.printRankings(opt.outbase) 

if __name__ == "__main__":
    main()
