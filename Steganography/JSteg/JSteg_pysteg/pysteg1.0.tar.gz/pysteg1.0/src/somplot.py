#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# SVM Testing
# ===========

docstring = """
:Script:    somplot.py
:Date:      $Date$
:Revision:  $Revision$
:Author:    © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

import optparse 
import matplotlib
matplotlib.use( "Cairo" )

import pysteg.tools as pt
import numpy as np
import itml.som as som

# Parsing Options
# ---------------

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

# The following are core options, fully supported and validated.
#
# ::

# File name options::

  parser.add_option("-O", "--outfile",
            help="""Output file for the SOM plot.""",
            dest="outfile" )
  parser.add_option("-i", "--infile",
            help="""Dataset input file.""",
            dest="infile" )
  parser.add_option("-o", "--datfile",
            help="""Dataset output file.""",
            dest="datfile" )
  parser.add_option("-T", "--testset",
            help="""Input file for the test set.""",
            dest="testset" )
  parser.add_option("-S", "--scatterfile",
            help="""Output file for scatter type plot.""",
            dest="scatterfile" )
  parser.add_option("-m", "--somfile",
            help="""Output file for the trained map (pickled object).""",
            dest="somfile" )
  parser.add_option("-u", "--umatrix",
            help="""Output file for the umatrix plot.""",
            dest="ufile" )

  parser.add_option("-n", "--iterations", 
            help="Number of iterations",
            default=0, dest="niter" )
  parser.add_option("-W", "--width", 
            help="SOM width",
            default=10, dest="width" )
  parser.add_option("-H", "--height", 
            help="SOM height",
            default=10, dest="height" )

# Other options::

  parser.add_option("-f", "--feature-set", 
            help="Feature set identifier (e.g. Fridrich, Markov, CP)",
            dest="id" )

# Verbosity is not currently used, but obviously it should be, in a
# standard way.
#
#   ::

  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            default=0, dest="verbosity" )

  (opt,a) = parser.parse_args()

# Some options need to be converted to appropriate data types::

  opt.verbosity = int(opt.verbosity)
  opt.height = int(opt.height)
  opt.width = int(opt.width)
  opt.niter = int(opt.niter)

  return (opt,a)

# The actual work
# ===============
#
#   ::

dataDict = {
      (-1,-1, 0) : ( "jpeg75boss/f1-256-fv/", xrange(0,200) ),
      (-1,-1,+1) : ( "jpeg75boss/f1-512-fv/", xrange(500,700) ),
      (-1,+1, 0) : ( "jpeg75boss/f5-256-fv/", xrange(1000,1200) ),
      (-1,+1,+1) : ( "jpeg75boss/f5-512-fv/", xrange(1500,1700) ),
      (+1,-1, 0) : ( "jpeg85boss/f1-256-fv/", xrange(2000,2200) ),
      (+1,-1,+1) : ( "jpeg85boss/f1-512-fv/", xrange(2500,2700) ),
      (+1,+1, 0) : ( "jpeg85boss/f5-256-fv/", xrange(3000,3200) ),
      (+1,+1,+1) : ( "jpeg85boss/f5-512-fv/", xrange(3500,3700) ),
      (-1, 0,-1) : ( "jpeg75boss/clean-fv/", xrange(4000,4200) ),
      (+1, 0,-1) : ( "jpeg85boss/clean-fv/", xrange(4500,4700) ),
      }

def mkDataSet(opt):

   X = []
   Y = []
   for k in dataDict.keys():
      (d,r) = dataDict[k]
      X.extend(
	  [ pt.loadObject( d + str(i) + ".pgm.dat" ).vector(opt.id) for i in r ] )
      Y.extend( [ k for i in X ] )

# We scale the feature vectors to have unit variance and zero mean.
#
#  ::

   X = np.array( X )
   sigma = np.sqrt( np.var(X, axis=0 ) )
   sigma[sigma==0] = 1
   basept = np.mean(X, axis=0 )
   X -= basept
   X /= sigma
   return { "FV" : X, "PV" : Y }

if __name__ == '__main__':
   (opt,args) = parseArgs()
   if opt.infile != None:
      DS = pt.loadObject( opt.infile )
   else:
      DS = mkDataSet(opt)

   if opt.datfile != None:
        pt.saveObject( DS, opt.datfile )

# If we have loaded a SOM object, we use it.
#
#   ::

   if isinstance(DS,som.SOM):
	somap = DS

# Otherwise we create the SOM object from the data set.
# 
#   ::

   else:
     (X,Y) = (DS["FV"], DS["PV"])
     dim = len(X[0])
     somap = som.SOM( opt.height, opt.width, dim, 3 )

   if opt.niter > 0:
     somap.train( X, Y, opt.niter )

   if opt.scatterfile != None: 
      C = som.SOMclassifier(somap)
      if opt.testset != None:
	 TS = pt.loadObject( opt.testset )
      else: TS = DS
      if TS.has_key("FV1"): (X,Y) = ( TS["FV1"], TS["PV1"] )
      else: (X,Y) = ( TS["FV"], TS["PV"] )
      C.classify( X, Y )
      C.plot( opt.scatterfile )
   if opt.ufile != None:
	somap.uMatrixPlot( opt.ufile )
   if opt.somfile != None:
        pt.saveObject( somap, opt.somfile )
   if opt.outfile != None:
        somap.colourplot( opt.outfile )
