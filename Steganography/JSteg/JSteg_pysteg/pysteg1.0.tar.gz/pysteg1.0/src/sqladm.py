#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *
from pysteg.sql.tools import *
from pysteg.sql.setup import *
from pysteg.sql.imageset import *
from pysteg.sql.svmodel import *
from pysteg.sql.latex import *
from pysteg.sql.features import *


# Database initialisation
config.add_option("-c", "--create",
          help="Create the database tables and standard features.",
          dest="create", default=False, action="store_true" )
config.add_option("-C", "--drop-and-create",
          help="Create the database tables and standard features, " +
	       "dropping existing tables first.",
          dest="dropcreate", default=False, action="store_true" )

# Delete objects
config.add_option( "--delete-feature-set",
          help="Delete feature set definition.",
	  dest="delfs", default=False, action="store_true" )
config.add_option( "--delete-feature-vector",
          help="Delete feature vector definition.",
	  dest="delfv", default=False, action="store_true" )
config.add_option( "--delete-all-models",
          help="Delete all the SVM models.",
          dest="delallmodels", default=False, action="store_true" )
config.add_option("--delete-images",
          help="Delete the given image set.",
          dest="delimg" )
config.add_option("--delete-model",
          help="Delete the given SVM model(s).",
          dest="delmodel" )
config.add_option("--delete-values",
          help="Delete the feature values for the given feature set.",
          dest="delval" )

# Load objects from config file
config.add_option( "--load-feature-sets",
          help="Load feature set definitions from the given file.",
          dest="loadfs" )
config.add_option( "--load-feature-vectors",
          help="Load feature vector definitions from the given file.",
          dest="loadfv" )
config.add_option("-I", "--load-images",
          help="Load image definitions from the given config file.",
          dest="images", )

# Listings
config.add_option("--list-imageset",
          help="List known ImageSet objects.",
          dest="listimageset", default=False, action="store_true" )
config.add_option("--list-testset",
          help="List known TestSet objects.",
          dest="listtest", default=False, action="store_true" )
config.add_option("--list-fv",
          help="List known Feature Vectors.",
          dest="listfv", default=False, action="store_true" )
config.add_option("--list-models",
          help="List known SVM models.",
          dest="listmodels", default=False, action="store_true" )
config.add_option("--tex-models",
          help="List known SVM models with performance.",
          dest="texmodel", default=False, action="store_true" )
config.add_option("--tex-performance",
          help="List known SVM test results (SVMPerformance records).",
          dest="texperf", default=False, action="store_true" )
config.add_option("--list-performance",
          help="List known SVM test results (SVMPerformance records).",
          dest="listperf", default=False, action="store_true" )

# Misc
config.add_option("-o", "--outfile", help="Output file.", dest="outfile" )
config.add_option("-r","--calculation-report",
          help="Report which features have been calculated.",
          dest="calcreport", default=False, action="store_true" )
(opt,args) = config.parse_args()

sqlConnect()

if opt.calcreport:
    calculated()

# Init
if opt.dropcreate:
    dropTables()
    print "Tables dropped"
    opt.create = True
if opt.create:
    createTables()
    print "Tables created"

# Load
if opt.loadfs != None:
    fsconfig( opt.loadfs )
    print "Feature sets loaded"
if opt.loadfv != None:
    fvconfig( opt.loadfv )
    print "Feature vectors loaded"
if opt.images != None:
    loadImages( opt.images )

# Listings
if opt.listperf:
    for p in SVMPerformance.select( orderBy="svmodel_id"):
        p.display()
if opt.texperf:
    texoutput = texPerformance()
elif opt.texmodel:
    texoutput = texModels()
else:
    texoutput = None
if texoutput != None:
    if opt.outfile == None:
        print texoutput
    else:
        f = open( opt.outfile, "w" )
        f.write(texoutput)
        f.close()
if opt.listimageset:
    for p in ImageSet.select( orderBy="id"):
        print p
if opt.listtest:
    for p in TestSet.select( orderBy="id"):
        print p
if opt.listfv:
    for p in FeatureVector.select( orderBy="id"):
        print p
if opt.listmodels:
    for p in SVModel.select( orderBy="id"):
        print p

# Delete
if opt.delimg != None:
    ImageSet.destroyKey( opt.delimg )
if opt.delfs:
    FeatureSet.destroyKey( opt.delfs )
if opt.delfv:
    FeatureVector.destroyKey( opt.delfv )
if opt.delval != None:
   S = FeatureSet.byKey( opt.delval )
   for f in S:
      for v in f.val:
	 print v
         v.destroySelf()
if opt.delmodel != None:
    mod = SVModel.byKey( opt.delmodel )
    mod.destroy()
elif opt.delallmodels:
    for mod in SVModel.select( ):
        mod.destroy()
