#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "PDF" )

from pysteg.sql import *
import pysteg.sql.stegocompare as sc 

config.add_option("-T", "--test-set", 
          help="The name of the test set to be considered.",
	  dest="tset" )
config.add_option("-M", "--svm-model", 
          help="The SVM model to check.", dest="mod" )
config.add_option("--stat", 
          help="Print stat's.",
	  dest="stat", action="store_true", default=False )
config.add_option("--scatter", 
          help="Print scatter plot to correlate with given feature.",
	  dest="scatter", action="store_true", default=False )
config.add_option("-f", "--feature", 
          help="Correlate with given feature.",
	  dest="feature" )
config.add_option("-o", "--outfile", 
          help="Output file name for the histogram plot.",
	  dest="outfile" )
(opt,args) = config.parse_args()

sqlConnect()

if opt.feature == None:
   sc.chist(args,opt.tset,opt.mod,opt.outfile)
elif opt.stat:
   sc.cstat(args,opt.tset,opt.mod,opt.feature,opt.outfile)
elif opt.scatter:
   sc.cscatter(args,opt.tset,opt.mod,opt.feature,opt.outfile)
else:
   sc.cbar(args,opt.tset,opt.mod,opt.feature,opt.outfile)
