#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "PDF" )

from pysteg.sql import *
import pysteg.sql.stegocompare as sc 

config.add_option("-T", "--test-set", 
          help="The name of the test set to be considered.",
	  dest="tset" )
config.add_option("-M", "--svm-model", 
          help="The SVM model to check.", dest="mod" )
config.add_option("--scatter", 
          help="Print scatter plot to correlate with given feature.",
	  dest="scatter", action="store_true", default=False )
config.add_option("-f", "--feature", 
          help="Correlate with given feature.",
	  dest="feature" )
config.add_option("-o", "--outfile", 
          help="Output file name for the histogram plot.",
	  dest="outfile" )
(opt,args) = config.parse_args()

L1 = [ "BOSSv1.0lsbpm0.1",
       "BOSSv1.0lsbpm0.1a",
       "BOSSv1.0lsbpm0.1b",
       "BOSSv1.0lsbpm0.1c",
       "BOSSv1.0lsbpm0.1d",
       "BOSSv1.0lsbpm0.1e", ]
L2 = [ "BOSSv1.0hugo0.4", "BH40a", "BH40b", "BH40c", "BH40d", "BH40e", ]

s1 = "Boss0.1lsbpm-SPAM-848"
s2 = "HugoBoss-SPAM-848"

sqlConnect()

print sc.cdata2d(L1,L2,"HugoBoss_test",s1,s2)
