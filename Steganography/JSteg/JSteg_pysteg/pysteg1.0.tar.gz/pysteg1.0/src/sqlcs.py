#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "PDF" )

from pysteg.sql import *
from pysteg.sql.coverselect import *

config.add_option("-S", "--image-set", 
          help="The name of the image set to be considered.",
	  dest="imgset" )
config.add_option("-T", "--test-set", 
          help="The name of the test set to be considered.",
	  dest="tset" )
config.add_option("-A", "--accuracy-plot", 
          help="Filename for the accuracy plot.",
	  dest="aplot" )
config.add_option("-E", "--error-plot", 
          help="Filename for the FP/FN plot.",
	  dest="eplot" )
config.add_option("-f", "--selection-feature", 
          help="The key of the feature for cover selection.",
	  dest="feature" )
config.add_option("-b", "--bins", help="Number of histogram bins.", 
      dest="bins" )
config.add_option("-M", "--model", 
          help="The key of the SVM model to assess.",
	  dest="model" )
config.add_option("-N", "--count", help="Number of images to consider.",
	  dest="count" )
config.add_option("-I", "--intersection", 
          help="Consider intersection of two heuristics.",
	  dest="int", action="store_true", default=False )
(opt,args) = config.parse_args()

sqlConnect()

kw = {}

if opt.int:
    fl = [ ("TXB(0)",True), ("corr-hor",False) ]
    R = iStat( opt.tset, fl, opt.model, int(opt.count) )
    print R
elif opt.count != None:
    fl = [ ("TXB(0)",True), ("corr-hor",False) ]
    for f in fl:
        print f
        print iStat( opt.tset, [f], opt.model, int(opt.count) )
elif opt.model == None:
    if opt.bins != None: kw["bins"] = int(opt.bins)
    mcStat( opt.tset, opt.feature, args, aplot=opt.aplot, **kw )
else:
    if opt.bins != None: kw["bins"] = int(opt.bins)
    cStat( opt.tset, opt.feature, opt.model,
          aplot=opt.aplot, eplot=opt.eplot, **kw )
