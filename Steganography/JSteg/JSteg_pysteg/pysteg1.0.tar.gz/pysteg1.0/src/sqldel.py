#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *

config.add_option( "--delete-values",
          help="Delete feature values.", dest="delval",
          default=False, action="store_true" )
config.add_option("-S", "--image-set",
          help="The name of the image set to process.",
          dest="tset" )
(opt,args) = config.parse_args()

sqlConnect()

S = ImageSet.byName( opt.tset )

if opt.delval:
    S.destroyValues()
