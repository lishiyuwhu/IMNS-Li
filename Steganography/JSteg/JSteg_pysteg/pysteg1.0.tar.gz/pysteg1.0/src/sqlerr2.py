#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "Cairo" )

from pysteg.sql import *
from pysteg.sql.errors import ImgList

config.add_option("-o", "--outfile", 
          help="Outpuy filename.",
	  dest="outfile" )
config.add_option("-I", "--image-set", 
          help="Image set",
	  dest="imgset" )
config.add_option("-F", "--feature-vector", 
          help="The key of the feature vector for classification.",
	  dest="fv" )
config.add_option("-f", "--selection-feature", 
          help="The key of the feature for cover selection.",
	  dest="feature" )
config.add_option("--f1", help="Feature #1", dest="f1" )
config.add_option("--f2", help="Feature #2", dest="f2" )
config.add_option("--bins1", help="Bins for feature #1", dest="b1" )
config.add_option("--bins2", help="Bins for feature #2", dest="b2" )
(opt,args) = config.parse_args()

sqlConnect()

P = ImgList( opt.imgset )
P.loadCoverFeatures([ opt.f1,  opt.f2 ])
kw = {}
if opt.b1 != None:
    b1 = list(eval(opt.b1))
    b2 = list(eval(opt.b2))
    kw["bins"] = (b1,b2)
if opt.feature == None:
    for f in args:
        P.loadFeatures(f)
        fn = "bar3d-" + f + ".pdf"
        P.bar3d( fn,k1=opt.f1,k2=opt.f2,key=f,**kw)
    P.bar3d( "bar3d.pdf",k1=opt.f1,k2=opt.f2,**kw)
else:
    P.loadFeatures(opt.feature)
    P.bar3d( opt.outfile,k1=opt.f1,k2=opt.f2,key=opt.feature,**kw)
