#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *
from pysteg.sql.tools import *

config.add_option("-T", "--image-set",
          help="The name of the image set to be used.",
          dest="tset" )
config.add_option("--csv",
          help="Use comma separated values instead of libsvm sparse format.",
          dest="libsvm", action="store_false", default=True )
config.add_option("-f", "--feature-vector", 
          help="The feature vector to be used.",
	  dest="fv" )
config.add_option("-M", "--svm-model", 
          help="Get the scaled features from the given model.",
	  dest="mod" )
config.add_option("-o", "--outfile", 
          help="Output file.",
	  dest="outfile" )
(opt,args) = config.parse_args()

sqlConnect()

T = TestSet.byName( opt.tset )
if opt.fv != None:
    savefeatures(opt.outfile,T,opt.fv,libsvm=opt.libsvm)
else:
    saveScaledFeatures(opt.outfile,T,opt.mod,libsvm=opt.libsvm)
