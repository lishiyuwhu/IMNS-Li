#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *

docstring="""
Enter new jobs into the queue.

Many modes of operations exist to support a variety of job categories,
and different approaches to bulk entry.  It is one of the most heavily
used scripts.
"""

# Performance options
config.add_option("--svmtraining-performance", 
          help="Test multiple SVM models with training set.",
	  dest="trainingperf", default=False, action="store_true" )
config.add_option("--svm-performance", 
          help="Test multiple SVM models with default test set.",
	  dest="perfbulk", default=False, action="store_true" )
config.add_option("-t", "--svm-test", 
          help="Test multiple SVM models with given test set.",
	  dest="svmtest" )
# Model options
config.add_option("-A", "--algorithm", 
          help="Classifier algorithm to use.  Default is SVM.",
	  dest="alg", default="SVM" )
config.add_option("-L", "--ec-L", 
          help="L parameter for EC.", dest="L" )
config.add_option("--ec-dred", help="dred parameter for EC.", dest="dred" )
config.add_option("--new-models", 
          help="Create SVM models for multiple feature vectors.",
	  dest="modelbulk", default=False, action="store_true" )
config.add_option("-M", "--model", 
          help="SVM model to be tested or trained.",
	  dest="model" )
# Diagnostics - no new tasks entered
config.add_option("-l", "--list",
          help="List the queue.",
          dest="list", default=False, action="store_true" )
config.add_option("-c", "--count",
          help="Display the number of items in the queue.",
          dest="count", default=False, action="store_true" )
# Remove tasks
config.add_option( "--delete",
          help="Delete the queue",
          dest="delete", default=False, action="store_true" )
# Feature extraction
config.add_option("-T", "--image-set",
          help="The name of the image set to be used.",
          dest="tset" )
config.add_option("-f", "--feature-vector", 
          help="The feature vector to be used.",
	  dest="fv" )
config.add_option("-F", "--feature-set", 
          help="The feature vector to be used.",
	  dest="fset" )
config.add_option( "--feature-set-description", 
          help="Description string for the new feature set.",
	  dest="fsdesc" )
config.add_option("-g", "--grid-search-fold", 
          help="Set n for n-fold cross-validation.",
	  dest="fold" )
config.add_option("-d", "--description", 
          help="Description string for the new feature.",
	  dest="desc" )
config.add_option("--stego-only",
          help="Queue feature extraction for steganograms only.",
          dest="stegonly", default=False, action="store_true" )
(opt,args) = config.parse_args()

import pysteg.sql.svmodel as sqlsvm
from pysteg.sql.extract import queueSet
import datetime as dt

sqlConnect()

if opt.delete:
    for q in Queue.select():
        q.destroySelf()

kw = {}
if opt.alg != None:
    kw["classifier"] = opt.alg
if opt.fold != None:
    kw["fold"] = int(opt.fold)
if opt.dred != None:
    kw["dred"] = int(opt.dred)
if opt.L != None:
    kw["L"] = int(opt.L)

if opt.modelbulk:
    sqlsvm.newSVM( opt.tset, args, fsdesc=opt.fsdesc, **kw )
elif opt.model != None:
    if opt.tset != None:
        mod = sqlsvm.newModel( opt.fset,  opt.model, opt.fv, opt.tset,
	        opt.fsdesc, opt.desc, **kw )
        q = Queue( image=None, entered=dt.datetime.now(), svmodel=mod )
        print q
    else:
        mod = sqlsvm.SVModel.byKey( opt.model )
        for key in args:
            T = TestSet.byName( key )
            sqlsvm.perfQueue( T, mod )
        T = None
elif opt.tset != None:
    T = getImageSet( opt.tset )
    print T
    queueSet( T, args, stegonly=opt.stegonly )

if opt.perfbulk:
    print "perfbulk"
    sqlsvm.testSVM( )
if opt.trainingperf:
    print "trainingperf"
    sqlsvm.testSVM( training=True )
if opt.svmtest != None:
    print "test", opt.svmtest
    sqlsvm.testSVM( key=opt.svmtest )

if opt.list:
    for q in Queue.select():
        print q
elif opt.count:
    A = Queue.select( Queue.q.assigned == None ).count()
    B = Queue.select( Queue.q.assigned != None ).count()
    print "Assigned: ", B
    print "Available:", A
    print "Total:    ", A+B
