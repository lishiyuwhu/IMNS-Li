#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "PDF" )

from pysteg.sql import *
from pysteg.sql.errors import ErrorProfiler,scatterPlot

config.add_option("-I", "--image-set", 
          help="Image set",
	  dest="imgset" )
config.add_option("-F", "--feature-vector", 
          help="The key of the feature vector for classification.",
	  dest="fv" )
config.add_option("--f1", help="Feature #1", dest="f1" )
config.add_option("--f2", help="Feature #2", dest="f2" )
(opt,args) = config.parse_args()

sqlConnect()

L = [ (  k + "_test", k + "-" + opt.fv ) for k in args  ]
L = [ (TestSet.byName(a),Feature.byKey(b)) for (a,b) in L ]
P = ErrorProfiler( L )

A = P.cat( L[0][1], L[1][1] )

f = args[0] + "-scatter.pdf"
scatterPlot( f, opt.imgset, [ A[1], A[3] ], opt.f1, opt.f2 )
f = args[1] + "-scatter.pdf"
scatterPlot( f, opt.imgset, [ A[2], A[3] ], opt.f1, opt.f2 )
