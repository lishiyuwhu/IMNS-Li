#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

import matplotlib 
matplotlib.use( "PDF" )

from pysteg.sql import *
from pysteg.sql.stats import *

config.add_option("-S", "--test-set", 
          help="The name of the test set to be considered.",
	  dest="tset" )
config.add_option("-C", "--compare-classifiers", 
          help="Compare classification errors of classifiers.",
	  dest="compare", action="store_true", default=False )
config.add_option("-P", "--percentiles", 
          help="Include percentile statistics.", dest="perc" )
config.add_option("-D", "--diff", 
          help="Include diff statistics.",
	  dest="diff", action="store_true", default=False )
config.add_option("-d", "--delta", 
          help="Include delta statistics.",
	  dest="delta", action="store_true", default=False )
config.add_option("-m", "--statistics", 
          help="Print median and moments of the features.",
	  dest="stat", action="store_true", default=False )
config.add_option("-c", "--correlation", 
          help="Print correlation matrix.",
	  dest="corr", action="store_true", default=False )
config.add_option("-F", "--feature-set", 
          help="Get the stats for a complete feature set.",
	  dest="fset" )
config.add_option("-p", "--scatter-plot", 
          help="Output file name for a scatter plot of two features.",
	  dest="scatter" )
(opt,args) = config.parse_args()

sqlConnect()

S = getImageSet( opt.tset )

if opt.fset != None:
   fl = FeatureSet.byKey( opt.fset )
else:
   fl = [ Feature.byKey( key ) for key in args ]

if opt.stat:
   for f in fl:
      print "Feature", f.id, f.key
      print "Moments:", featureMoments( S, f )
      print "Median:", featureMedian( S, f )
      print

if opt.perc != None:
   for f in fl:
      print "Feature", f.id, f.key
      print "Perc:", featurePerc( S, f, bins=int(opt.perc) )

if opt.delta:
   for f in fl:
      print "Feature", f.id, f.key
      print "Delta:", deltaMoments( S, f )

if opt.diff != None:
   if len(fl) != 2:
      print "Diff requires exactly two features to compare."
   else:
      L = [ im.getOneFeature(fl[0]) - im.getOneFeature(fl[1]) 
	    for im in S ]
      print "Diff", max(L), min(L)

if opt.scatter != None:
   if len(fl) != 2:
      print "Scatter plots require exactly two features to compare."
   else:
      scatterPlot( S, fl[0], fl[1], opt.scatter )

if opt.corr:
   print "Correlation matrix:"
   print corrcoef(S,fl)

if opt.compare:
   compareClassifiers(S,fl)
