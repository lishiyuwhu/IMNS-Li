#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *
from pysteg.sql.svmodel import *

config.add_option("--delete",
          help="Delete given SVModel and scaling model.",
          dest="delete", default=False, action="store_true" )
config.add_option("-l", "--list",
          help="List existing SVModels and their performance.",
          dest="list", default=False, action="store_true" )
config.add_option("-T", "--training-set", 
          help="The name of the training set to be used.",
	  dest="train" )
config.add_option("-S", "--test-set", 
          help="The name of the test set to be considered.",
	  dest="tset" )
config.add_option("-M", "--model", 
          help="SVM model to be tested.  (Required)",
	  dest="model" )
config.add_option("-A", "--algorithm", 
          help="Classifier algorithm to use.  Default is SVM.",
	  dest="alg", default="SVM" )
config.add_option("-L", "--ec-L", 
          help="L parameter for EC.", dest="L" )
config.add_option("--ec-dred", help="dred parameter for EC.", dest="dred" )
config.add_option("-f", "--feature-vector", 
          help="The feature vector to be used.",
	  dest="fv" )
config.add_option("-F", "--feature-set", 
          help="The feature vector to be used.",
	  dest="fset" )
config.add_option("-D", "--feature-set-description", 
          help="Description string for the new feature set.",
	  dest="fsdesc" )
config.add_option("-g", "--grid-search-fold", 
          help="Set n for n-fold cross-validation.",
	  dest="fold" )
config.add_option("-d", "--description", 
          help="Description string for the new feature.",
	  dest="desc" )
(opt,args) = config.parse_args()

sqlConnect()

kw = {}
if opt.alg != None:
    kw["classifier"] = opt.alg
if opt.fold != None:
    kw["fold"] = int(opt.fold)
if opt.dred != None:
    kw["dred"] = int(opt.dred)
if opt.L != None:
    kw["L"] = int(opt.L)

if opt.list:
    for p in SVMPerformance.select( orderBy="svmodel_id"):
        p.display()
   
elif opt.train != None:
    mod = newModel( opt.fset,  opt.model, opt.fv, opt.tset,
	    opt.fsdesc, opt.desc, **kw )
    mod.train()
    mod.saveModel()
elif opt.model != None:
    mod = SVModel.byKey( opt.model )
else: 
    mod = None

if opt.tset != None:
    mod.loadModel()
    S = TestSet.byName( opt.tset )
    P = SVMPerformance( svmodel=mod, testset=S )
    P.run()
    for p in P.list: print p
elif opt.delete:
    if mod != None:
        mod.destroy()
    else:
        for m in args:
            mod = SVModel.byKey( m )
            mod.destroy()
