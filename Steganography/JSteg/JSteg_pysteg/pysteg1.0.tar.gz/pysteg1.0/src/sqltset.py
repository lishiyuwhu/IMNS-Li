#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import *
import pysteg.sql.imageset as psi
from pysteg.sql.svmodel import *

config.add_option("-c", "--count",
          help="Count the images which would be filtered into the new set, without creating it.",
          dest="create", default=True, action="store_false" )
config.add_option( "--incomplete",
          help="Accept missing stegograms when creating TestSet.",
          dest="incomplete", default=False, action="store_true" )
config.add_option("-f", "--feature",
          help="The feature to use for the filter criterion.",
          dest="feature" )
config.add_option("-m", "--min",
          help="The minimum feature value.",
          dest="min" )
config.add_option("-M", "--max",
          help="The maximum feature value.",
          dest="max" )
config.add_option( "--delete-test-set",
          help="Delete the given TestSet.", dest="delset",
          default=False, action="store_true" )
config.add_option("-T", "--image-set",
          help="The name of the image set to create.",
          dest="tset" )
config.add_option("-i", "--cover-set",
          help="The name of the cover set.",
          dest="clean" )
config.add_option("-g", "--stego-set",
          help="The name of the stego set.",
          dest="stego" )
config.add_option("--skew", help="The class skew.", dest="skew" )
config.add_option("--test-key",
     help="Key for the test set; default appends _test to training set name.",
     dest="testname" )
config.add_option("--train-size",
          help="The size for the train set.", dest="trainsize" )
config.add_option("--test-size",
          help="The size for the test set.", dest="testsize" )
config.add_option("-S", "--source-set",
          help="The name of the source image set.",
          dest="source" )
config.add_option( "--filter",
          help="Test set to use to filter a test set",
          dest="filter" )
config.add_option("--dummy",
     help="Create a dummy test set containing multiple, complete Image sets.",
     dest="dummy", default=False, action="store_true" )
config.add_option("--merge",
     help="Merge the given TestSets into a new TestSet.",
     dest="merge", default=False, action="store_true" )
(opt,args) = config.parse_args()

sqlConnect()

if opt.source == None:
   S = None
else:
   S = TestSet.byName( opt.source )

if opt.delset:
   for key in args:
      try:
         T = TestSet.byName( key)
         T.destroy()
      except:
	 pass
elif opt.dummy:
   psi.dummyTestSet( opt.tset, args )
elif opt.merge:
   psi.mergeTestSet( opt.tset, args )
elif opt.filter != None:
   psi.filter( opt.tset, opt.source, opt.filter )
elif S == None:
   kw = {}
   if opt.testsize != None: kw["testsize"] = float(opt.testsize)
   if opt.trainsize != None: kw["trainsize"] = float(opt.trainsize)
   if opt.skew != None: kw["skew"] = float(opt.skew)
   clean = ImageSet.byName( opt.clean )
   stego = ImageSet.byName( opt.stego )
   psi.makeTestSets( clean, stego, opt.tset, opt.testname, **kw )
elif opt.feature != None:
   F = Feature.byKey( opt.feature )

   if opt.min == None:
      vmin = None
   else:
      vmin = float(opt.min)
   if opt.max == None:
      vmax = None
   else:
      vmax = float(opt.max)
   
   R = psi.groupTestSet( S, opt.tset, F, min=vmin, max=vmax, 
         create=opt.create )

   if opt.create:
      N = R.count()
   else:
      N = R

   print "Number of images:", N
elif opt.stego != None:
   stego = ImageSet.byName( opt.stego )
   psi.similarTestSet( S, stego, opt.tset, incomplete=opt.incomplete )
else:
   print "Error!  Nothing to do."
