#! /usr/bin/env python
## -*- coding: utf-8 -*-
# (C) 2012: Hans Georg Schaathun <georg@schaathun.net> 

from pysteg.sql import config,sqlConnect
from pysteg.sql.extract import worker
import os

config.add_option("--no-svm", 
          help="Ignore SVM related tasks.",
	  dest="svm", default=True, action="store_false" )
config.add_option("-i", "--id", 
          help="Identity string for the worker", dest="id" )
(opt,args) = config.parse_args()

if opt.id: idstring = opt.id
else:
    pid = os.getpid()
    (sys,node,rel,version,machine) = os.uname()
    idstring = "%s%s" % (node,pid)

sqlConnect()
verbosity = config.get( "sql", "verbosity" )
print "[sqlworker.py] verbosity =", verbosity

worker( idstring, SVM=opt.svm )
