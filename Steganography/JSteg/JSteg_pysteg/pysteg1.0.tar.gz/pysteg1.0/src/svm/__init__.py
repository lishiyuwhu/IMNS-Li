## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>
"""

# **********************
# The :mod:`svm` library
# **********************
#   
#
# .. automodule:: svm
#
# This package is an adaptation of the python interface included
# in the libsvm distribution, which is distributed under a modified
# BSD licence.
#
# Changes are made in an attempt to make the code more readable,
# at least for myself, as well as some changes necessary to make
# it run on my system.  Some new code is written to get a convenient
# interface for pysteg.
