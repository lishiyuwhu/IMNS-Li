## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm.dataset
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

This module provides additional functions and classes to do SVM 
testing, tailored specifically for pysteg.  The DataSet class
contains a single dataset, for testing or for training, with 
methods to scale features, train a model, and to apply a model
to classify.

Users will not normally use this module directly, but rather use
the interface provided by the :class:`svmTest` class in the 
:mod:`svmtest` module.
"""

# ***********
# svm.dataset
# ***********
#
# .. automodule:: svm.dataset
#
# This module offer two definitions which are ready for use.
# The :class:`DataSet` is a data type to hold a complete data set
# for either training or testing.  The :func:`mkdataset` function
# provides a simple method to create a :class:`DataSet` from a list
# of feature vector objects.
#
# ::

__all__ = [ "DataSet", "mkdataset" ]

# We build heavily on other definitions within the package, and
# import those::

from .svm import svm_problem, svm_parameter
from .svmutil import svm_train, svm_predict
from .gridsearch import gridsearch
from .tools import *

# We need the complete numpy/scipy/matplotlib framework, for
# scientific calculations and plotting::

import matplotlib.pyplot as plt
import numpy as np
import scipy as sp

# The grid search recommended in the libsvm package uses gnuplot to
# create scatter plot.  It would be convenient if this was recoded
# in matplotlib; so far, we have isolated the gnuplot handling in the
# :mod:`gnuplot` module::

from .gnuplot import GnuPlot

# The os.path and sys modules offer basic system operations for file
# handling::

import os.path
import sys

# Core functions
# ==============

def mkdataset(C,S,id=None,*a,**kw):
   """
     Make a dataset from lists or iterators of features,
     C for clean images and S for steganogrammes.
   """
   cs = [ (O.getVector(id),O.getFileName()) for O in C ]
   ss = [ (O.getVector(id),O.getFileName()) for O in S ]
   F = [ v for (v,n) in cs ] + [ v for (v,n) in ss ] 
   N = [ n for (v,n) in cs ] + [ n for (v,n) in ss ] 
   print "Names:", N, len(F)
   assert len(F) == len(N)
   print "[mkdataset] %s (%i features) %i objects" % (id,len(F[0])-1,len(F)) 
   return DataSet(F,*a,names=N,**kw)

# The BaseDataSet Class
# =====================
#
# The :class:`BaseDataSet` class contains the methods which are not
# particular for SVM, such as scaling.  It forms the base class of
# a more specific purpose :class:`DataSet`.
#
# ::

class BaseDataSet(object):
  """
    Class to hold a dataset for classification with machine learning.
    It is used as an ancestor for Data Sets used in the :mod:`itml`
    and in :mod:`svm`.  It provides essential methods for building 
    the data structure and for scaling features.
  """

# Main data
#
#   ::

  _features = None
  _labels = None
  _names = None

# Attributes to be calculated during the life of the object
#
#   ::

  model = None
  _scalemodel = None

  def names(self): return self._names

  def __init__(self,labels,features=None,names=None,parallel=1,verbosity=None):
    """
      DataSet(l,f) or DataSet((l,f)) generates a dataset from a
      list l of labels and a list f of feature vectors.
      The other arguments specify options to be used by other
      methods.
    """

# The data set
# ------------
#
#     ::

    if features == None:
      if len(labels) == 2: (labels, features) = labels
      else: (labels, features) = fvsplit(labels)
    assert len(features) == len(labels), \
           "Number of labels does not match number of feature vectors"
    print "[DataSet] %i features / %i objects" % (len(features[0]),len(features)) 

# The labels is simply a list of integers.  The names is a list of
# strings, usually the file names of the objects.
#
#   ::

    self._labels = labels
    self._names = names
    if names != None: assert len(labels) == len(names)

# The features should be converted to floating point, lest we
# get integer division in the scale() method and possible problems
# elsewhere too.
#
#     ::

    self._features = map( lambda x : map( np.float64, x ), features )

# Other parameters
#
#     ::

    if verbosity != None: self.verbosity = verbosity
    self.skew = ( self._labels.count(1), self._labels.count(0) )
    assert self.skew[0] + self.skew[1] == len(self._labels), \
      "Labels should be 0 and 1."

# Simple data access methods
# --------------------------
#
#    ::

  def __len__(self): return len(self._labels)
  def len(self): return len(self._labels)
  def dim(self): return len(self._features[0])
    
# Scaling
# --------
#
#   ::

  def _getminmax(self,zero=False):
    "Get the minimum and maximum of each feature across the set."
    N = self.dim()
    (mn,mx) = ([],[])
    for i in xrange(N):
      f = [ x[i] for x in self._features ]
      if zero: f.append(0)
      mn.append( min( f ) )
      mx.append( max( f ) )
    return (mn,mx)
  def scale(self,model=None):
    """
      Scale the features using the given scaling model.
      If no model is given, optimal parameters are calculated for this
      data set.
    """

    # If a model is given as an argument, that's what we use.
    # Otherwise we use our own model as provided by :method:`getscalemodel`.
    #
    # ::

    if model == None:
      print "[scale] Creating model"
      model = self.getscalemodel()
    else: print "[scale] model given"

    if self.verbosity > 0:
       print "[scale] model selected"
       sys.stdout.flush()

    # We iterate over the feature vectors, scaling one vector at a time.
    # This could be made more efficient with matrix algebra, but the
    # current approach makes it straight-forward to cover special cases.
    #
    # ::

    for fv in self._features:
      assert len(fv) == self.dim(), "Feature vectors of inconsistent dimension"

      # We iterate over the dimensions and scale each feature.
      # This is crude and inefficient, but but makes it easy to
      # treat the special case and avoid division by zero.
      #
      # ::

      for i in xrange(len(fv)):
        if model["div"][i] == 0: fv[i] = 0
        else:
	   fv[i] = model["lower"] + \
		 model["range"] * (fv[i]-model["min"][i])/model["div"][i]

# We provide two methods generating scaling models, one scaling the
# features to withing a fixed range, and one scaling to zero mean and
# unit variance.
#
# ::

  def mkscalemodel(self,lower=-1,upper=1):
    """
    Make optimal scaling parameters to scale the data to within
    a given range the data set.
    """
    print "[mkscalemodel]", (lower,upper)
    sys.stdout.flush()
    (mn,mx) = self._getminmax()
    if lower == None: lower = -1
    if upper == None: upper = +1
    self._scalemodel = { 
          "min"   : mn,
	  "max"   : mx,
	  "div"   : [ a-b for (a,b) in zip(mx,mn) ],
          "range" : upper - lower,
	  "lower" : lower,
	  "upper" : upper }
    return self._scalemodel
  def unitvarModel(self):
    "Make scaling parameters to scale the data to unit variance."
    print "[mkunitvariance]"
    sys.stdout.flush()
    A = np.array( self._features )
    sig = np.sqrt(np.var( A, axis=0 ))
    sig[sig==0] = 1
    mu = np.mean( A, axis=0 )
    self._scalemodel = { 
          "min"   : mu,
	  "max"   : None,
	  "div"   : sig,
          "range" : 1,
	  "lower" : 0,
	  "upper" : None }
    return self._scalemodel

  def getscalemodel(self,lower=None,upper=None):
    "Get optimal scaling parameters for the data set."
    print "[getscalemodel]", (lower,upper)
    sys.stdout.flush()
    if self._scalemodel == None: self.mkscalemodel(lower,upper)
    if (upper != None and upper != self._scalemodel["upper"]) or \
       (lower != None and lower != self._scalemodel["lower"]):
         self.mkscalemodel(lower,upper)
    return self._scalemodel

# Input/Output
# ------------

  def write(self,file,libsvm=True):
    """
    Write the dataset to file.  If the second argument libsvm=True,
    then the libsvm sparse format is used.  Otherwise a comma separated
    data file is used.
    """
    N = len(self._labels)
    if libsvm: sf = sparsestr
    else: sf = csvstr
    assert N == len(self._features)
    if hasattr(file,"w"): f = file
    else: f = open(file,"w")
    for i in xrange(N):
      f.write( sf( [self._labels[i]] + self._features[i]) + "\n" )
    if hasattr(file,"w"): f.close()

# The DataSet Class
# =================
#
# ::

class DataSet(BaseDataSet):
  """
    Class to hold a dataset for training or classifications.
    It also implements the Options interface used by gridsearch,
    and includes methods for grid search, training, prediction,
    and evaluation.
  """

# Feature data
# ^^^^^^^^^^^^
#
#   ::

  _features = None
  _labels = None
  _names = None

# SVM model data
# ^^^^^^^^^^^^^^
#
# The :attr:`model` is the SVM model obtaining by training the machine.
# It is a ctypes object which cannot be pickled.
#
#   ::

  model = None

# Configuration parameters
# ^^^^^^^^^^^^^^^^^^^^^^^^
#
# Default parameters for the gridsearch.
#
#   ::

  fold = 5
  crange = ( -5,  15,  2)
  grange = (  3, -15, -2)

# Other configuration parameters::

  verbosity = 3
  gnuplot = None
  param = None

# I wonder what the following are used for::

  xargs = "-q"
  nr_local_worker = None

# Performance data
# ^^^^^^^^^^^^^^^^
#
# These attributes are calculated during or after testing.
# First of all, we have the key performance indicators.
# They will be scalars or other short and simple values.
#
#   ::

  FP = None
  FN = None
  acc = None
  auc = None

# We store a complete set of classifier output, with both 
# soft and hard information::

  val = None
  plab = None

# The :attr:`roc` attribute contains the data points for a ROC curve.
# It is produced while analysing the test results.
#
#   ::

  roc = None


  def __init__(self,labels,features=None,names=None,parallel=1,
               gnuplot=None,param=None,verbosity=None):
    """
      DataSet(l,f) or DataSet((l,f)) generates a dataset from a
      list l of labels and a list f of feature vectors.
      The other arguments specify options to be used by other
      methods.

      param is a string of libsvm options, as accepted by the svm-train
      program.

      One should be very careful with the libsvm parameters, param.
      If -c or -g is specified, gridsearch() should not be used,
      because the gridsearch() method specifies these options without
      being able to strip them from the param string.  The -v (fold)
      options should not be present.
    """

    BaseDataSet.__init__(self,labels,features,names,
	      parallel=parallel,verbosity=verbosity)

# gridsearch options
#
#     ::

    self.nr_local_worker = parallel
    if isinstance(gnuplot,str):
      assert os.path.exists(gnuplot), "Given gnuplot executable does not exist"
      self.gnuplot = GnuPlot(gnuplot,self.crange,self.grange)
    else: self.gnuplot = gnuplot

# SVM parameters
#
#     ::

    self.param = svm_parameter(param)
    if param != None: self.xargs = param

# Overriding special methods
# --------------------------
#
# The :attr:`model` object cannot be pickled because it is a ctypes
# object.  We do not expect to need this upon retrieving the
# the object, so we can remove it from the pickled object.
#
#    ::

  def __getstate__(self):
     print "[svmTest.__getstate__]"
     R = self.__dict__.copy()
     R['model'] = None
     R['gnuplot'] = None
     R['param'] = None
     return R


# Simple data access methods
# --------------------------
#
#    ::

  def getproblem(self): return svm_problem(self._labels,self._features)
    
# Field access
# ------------
#
#   ::

  def getmodel(self,rerun=False):
    "Return a model for the data set.  Training will be run if necessary."
    if self.model == None: self.train()
    if rerun: self.train()
    return self.model

  # Setting grid searchoptions
  def setcrange(self,l,u,s):
    self.crange = (l,u,s)
  def setgrange(self,l,u,s):
    self.grange = (l,u,s)
  def setfold(self,f):
    self.fold = f
  def setxargs(self,x):
    self.xargs = x

# Training
# --------
#
# ::

  def gridsearch(self,pngfile=None):
    """
      Optimise the SVM parameters using a grid search.
    """
    (db, (c1,g1), (c, g), rate) = gridsearch(self.getproblem(), self)
      # self is here passed as the options argument to gridsearch
      # DataSet implements the interface of the Options class used in grid.py
    if pngfile != None:
      self.gnuplot.redraw(db,[c1, g1, rate],pngfile)
      if self.verbosity > 1:
        print "[gridsearch] Writing parameter contour plot to file %s.\n" % (
                  pngfile)
    self.param.C = c
    self.param.gamma = g
    if self.verbosity > 1:
      print "[gridsearch] (%s,%s) Best rate %s.\n" % (c,g,rate)

  def train(self):
    "Trains the machine and returns a (new) model."
    self.model = svm_train( self.getproblem(), self.param )
    if self.verbosity > 2:
      print "[train] Training complete.\n" 
    return self.model

# Testing and evaluation

  def _checkval(self):
    """
      Auxiliary function.  Flip the sign of classification values
      if negative values correspond to label 1.
    """
    T = [ np.sign(self.val[i]*(2.0*self.plab[i]-1))
          for i in xrange(len(self.plab)) ] 
    (neg,pos) = (T.count(-1),T.count(+1))
    if self.verbosity > 1: print "[_checkval]", (neg,pos)
    assert neg*pos == 0, \
       "Strange! Inconsistent interpretation of classification values"
    if neg > 0:
      if self.verbosity > 2:
        print "[checkval] flipping sign of classification values"
      self.val = [ -v for v in self.val ]
  def predict(self,model=None):
    """
      Predict labels using the given model.  If no model is given,
      a model already held by the object is used.
    """
    if model == None: model = self.model
    assert model != None, "No prediction model is available"
    print "svmtest skew", self.skew
    (self.plab,self.acc,val) = \
      svm_predict(self._labels,self._features,model)
    print type(val), len(val), type(val[0]), val[0]
    self.val = [ v[0] for v in val ]
    self._checkval()
    acc = self.acc[0]
    if self.verbosity > 1:
      print "True labels:      -1:%i;  0:%i;  +1:%i" % ( 
        self._labels.count(-1), self._labels.count(0), self._labels.count(1) )
      print "Predicted labels: -1:%i;  0:%i;  +1:%i" % ( 
        self.plab.count(-1), self.plab.count(0), self.plab.count(1) )
    comp = [ int(self.plab[i]) - int(self._labels[i])
             for i in xrange(len(self)) ]
    (P,N) = self.skew
    self.FP = float(comp.count(1))/N
    self.FN = float(comp.count(-1))/P
    if self.verbosity > 1:
      print "[predict] FP %s; FN %s; Accuracy %s." % (self.FP,self.FN,acc,)
      print "[predict] Accuracy tuple %s." % (self.acc,)
    return acc
  def getrocdata(self):
     if self.roc: return self.roc
     else: return self.mkroc()
  def getscores(self):
     return zip( self.val, self._labels )
  def mkroc(self):
    """
      Calculate the points for the ROC curve.  The result is a list
      of pairs (x,y) where x is the detections rate and y the false
      positives rate.  This list is returned, and also stored in the
      roc attribute.
    """
    L = zip( self.val, self._labels )
    L.sort(reverse=True)
    #C = [ (0,0) ]
    C = []
    (fp,d) = (0,0)
    (P,N) = self.skew
    vold = -np.inf
    for (v,l) in L:
      if v != vold:
        C.append( (float(fp)/N,float(d)/P) )
        vold = v
      if l > 0: d += 1
      else: fp += 1
    C.append( (float(fp)/N,float(d)/P) )
    self.roc = C
    return C
  def mkauc(self):
    """
    Calculate the Area under the Curve (AUC) of the ROC curve.
    The ROC is calculated if necessary.
    """
    if self.roc == None: self.mkroc()
    L = len(self.roc)
    X = [ x for (x,y) in self.roc ]
    Y = [ y for (x,y) in self.roc ]
    self.auc = sum( [ (Y[i]+Y[i-1])*(X[i]-X[i-1])/2 for i in xrange(1,L) ] )
    return self.auc
  def Gini(self):
    "Return the Gini coefficient of the classifier."
    if self.auc == None: self.mkauc()
    return (2*self.auc - 1)
  def rocplot(self,*a,**kw):
    """
      Plot the ROC curve using matplotlib.pyplot.plot().
      This may be stacked with other pyplot functions to produce
      sofisticated plots.  DataSet.rocplot(filename) prints the plot
      to the given file.

      If fill is a matplotlib colour, it is used to fill the area 
      between the ROC curve and the main diagonal.  If (additionally)
      ufill is not None, the mirror image under the main diagonal is
      filled in the same colour.
  
      If dline is specified, it should be a line style, used to
      draw the main diagonal.

      All other arguments are passed to pyplot.plot().
    """
    if self.roc == None: self.mkroc()
    return lplot(self.roc,*a,**kw)
  def histplot(self,filename=None,nbin=15,addto=False):
    """Make histogram of classification labels for each class."""
    L = len(self._labels)

# Extract values (v) for separately for positives (p) and negatives (n)

    pl = [ i for i in xrange(L) if self._labels[i] == 1 ]
    nl = [ i for i in xrange(L) if self._labels[i] != 1 ]
    pv = [ self.val[i] for i in pl ]
    nv = [ self.val[i] for i in nl ]

# Construct the bins
#
#     ::

    rng = (min(self.val),max(self.val))
      # range of values
    stepsize = float(rng[1]-rng[0])/nbin
      # bin width
    barwidth = 0.4*stepsize
      # width of the histogram bars in the plot
    bins = [ rng[0] + i*stepsize for i in xrange(nbin+1) ]
      # The bins as passed to scipy.histogram()
    bincenter = [ rng[0] + (i+0.5)*stepsize for i in xrange(nbin) ]
      # Centre point of each bin (reference point for the bar plot
    left1 = [ rng[0] + (i+0.5)*stepsize - barwidth for i in xrange(nbin) ]
      # Reference point for bars to the left of the centre point 

# Calculate the histogram
#
#     ::

    nh = sp.histogram( nv, bins )[0]
    ph = sp.histogram( pv, bins )[0]

# Plot the histogram
#
#     ::

    if not addto: plt.figure()
    plt.bar( left1, nh, width=barwidth, color="#A0A0A0" )
    plt.bar( bincenter, ph, width=barwidth, color="k" )

# Save to file (if required)
#
#     ::

    if filename != None: plt.savefig( filename )
    return None

# Utility tools
# -------------
#
#   ::

  def quickrun(self):
    """
      INCOMPLETE.  The quick and easy all-in-one experiment and evaluation.
    """
    self.gridsearch()
    self.train()
    self.predict()
    self.roc()

# Auxiliary functions
# ===================

def lplot(L,file=None,fill=None,ufill=None,dline=None,line=None,
            addto=True,figsize=None,*a,**kw):
  """
    Use matplotlib.pyplot.plot() to make a plot from a list L of
    (x,y) co-ordinate pairs.  If a filename file is given, the
    output is written to the specified file.

    This function is an auxiliary for DataSet.rocplot() and the
    fill, ufill, and dline options are documented there.

    All other arguments are passed to pyplot.plot().
  """
  X = [ x for (x,y) in L ]
  Y = [ y for (x,y) in L ]
  if figsize != None: addto = False
  else: figsize = (7,7)
  if not addto:
    print "[lplot] Creating new figure."
    plt.figure( figsize=figsize )
    plt.xlim( 0, 1 )
    plt.ylim( 0, 1 )
    plt.xlabel( "False Positive Rate" )
    plt.ylabel( "Detection Rate" )
  if line == None: P = plt.plot( X, Y, *a, **kw )
  else: P = plt.plot( X, Y, line, *a, **kw )
  if fill != None:
    plt.fill_between( X, Y, X, color=fill )
  if ufill != None:
    plt.fill_between( Y, X, Y, color=fill )
  if dline != None:
    plt.plot( [0,1], [0,1], dline )
  if file != None: plt.savefig( file )
  return P

# Redundant functions
# ===================

def relabel(x):
  """
    Auxiliary function used internally to translate labels so that they
    be compatible with libsvm's internal labels.
    (NOT USED)
  """
  return x
  if x == 1: return x
  elif x == 0: return -1
  else: raise "Unknown label"

