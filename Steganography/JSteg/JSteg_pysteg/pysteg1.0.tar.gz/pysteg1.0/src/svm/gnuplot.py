## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm.gnuplot
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

This module defines classes which can be used to plot data
for the gridsearch module.

*  GnuPlot   - makes a contour plot as used in grid.py from libsvm
*  VoidPlot  - implements the same interface as GnuPlot and does nothing
"""

# ******************
# :mod:`svm.gnuplot`
# ******************
#   
#
# .. automodule:: svm.gnuplot


from subprocess import Popen,PIPE
import sys

is_win32 = (sys.platform == 'win32')

class VoidPlot(object):
  """
    This is a dummy to be used when a GnuPlot object is required and
    no effect is desired.  It implements the GnuPlot interface and does
    nothing.
  """
  def __init__(self,exe=None): pass
  def redraw(self,*a,**kw): pass

class GnuPlot(object):
  def __init__(self,exe,crange,grange,title=""):
    self.stream = Popen(exe,stdin = PIPE).stdin
    self.crange = crange
    self.grange = grange
    self.title = title
  def write(self,s):
    self.stream.write( s.encode() )
  def redraw(self,db,best_param,file=None):
    if len(db) == 0: return
    begin_level = round(max(x[2] for x in db)) - 3
    step_size = 0.5

    best_log2c,best_log2g,best_rate = best_param

    if file != None: 
        self.write( "set term png transparent small\n" )
        self.write( "set output \"%s\"\n" % file.replace('\\','\\\\') )
        #gnuplot.write("set term postscript color solid\n")
        #gnuplot.write(("set output \"%s.ps\"\n" % dataset_title))
    elif is_win32:
        self.write("set term windows\n")
    else:
        self.write( "set term x11\n")
    self.write("set xlabel \"log2(C)\"\n")
    self.write("set ylabel \"log2(gamma)\"\n")
    self.write(("set xrange [%s:%s]\n" % self.crange[:2]))
    self.write(("set yrange [%s:%s]\n" % self.grange[:2]))
    self.write("set contour\n")
    self.write(("set cntrparam levels incremental %s,%s,100\n" % (
                    begin_level,step_size)))
    self.write("unset surface\n")
    self.write("unset ztics\n")
    self.write("set view 0,0\n")
    self.write(("set title \"%s\"\n" % self.title))
    self.write("unset label\n")
    self.write(("set label \"Best log2(C) = %s  log2(gamma) = %s  accuracy = %s%%\" \
                  at screen 0.5,0.85 center\n" % \
                  (best_log2c, best_log2g, best_rate)))
    self.write(("set label \"C = %s  gamma = %s\""
                  " at screen 0.5,0.8 center\n" % (2**best_log2c, 2**best_log2g)))
    self.write("splot \"-\" with lines\n")
    
    
    db.sort(key = lambda x:(x[0], -x[1]))

    prevc = db[0][0]
    for line in db:
        if prevc != line[0]:
            self.write("\n")
            prevc = line[0]
        self.write(("%s %s %s\n" % line))
    self.write("e\n")

# force gnuplot back to prompt when term set failure
#
#     ::

    self.write("\n") 
    self.stream.flush()


