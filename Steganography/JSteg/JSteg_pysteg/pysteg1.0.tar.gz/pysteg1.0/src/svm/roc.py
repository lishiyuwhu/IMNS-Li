## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm.roc
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>
"""

import matplotlib.pyplot as plt
import numpy as np


def rocplot(Y,V=None,line="k-",errorbars=0,plt=plt,**kw):
   if V == None:
     V1 = [ v for (v,l) in Y if l == 1 ]
     V2 = [ v for (v,l) in Y if l != 1 ]
     V  = [ v for (v,l) in Y ]
   else: 
     V1 = [ V[i] for i in range(len(V)) if Y[i] == -1 ]
     V2 = [ V[i] for i in range(len(V)) if Y[i] == +1 ]
   (mn,mx) = ( min(V), max(V) )
   N = 250
   bins = [ mn + (mx-mn)*i/N for i in range(N+1) ]
   (H1,b) = np.histogram( V1, bins )
   (H2,b) = np.histogram( V2, bins )
   H1 = np.cumsum( H1.astype( float ) ) / len(V1)
   H2 = np.cumsum( H2.astype( float ) ) / len(V2)
   plt.plot( H1, H2, line, **kw )
   if errorbars != 0:
      print "[rocplot] errorbars =", errorbars
      if errorbars > 0:
        step = int( N / (errorbars+1) )
        s = int(step / 2)
        (P1,P2) = (H1[s::step], H2[s::step])
      else:
	L = [50,95,110,120,130,140,155,200]
        (P1,P2) = (H1[L], H2[L])
      xerr = 2*np.sqrt( P1*(1-P1) / len(V1) )
      yerr = 2*np.sqrt( P2*(1-P2) / len(V2) )
      plt.errorbar( P1, P2, fmt=None, xerr=xerr, yerr=yerr )
