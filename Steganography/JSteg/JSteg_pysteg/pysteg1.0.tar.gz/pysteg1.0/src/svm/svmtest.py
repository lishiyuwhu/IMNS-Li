## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm.svmtest
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2010: Hans Georg Schaathun <H.Schaathun@surrey.ac.uk>

This module provides the :class:`svmTest` class designed to hold all
the feature sets (training and testing) associated with one experiment,
run SVM training and testing, and store the complete test classification.
This means that the :class:`svmTest` object may be pickled, and retrieved
later for extensive analysis.
"""

# ***********
# svm.svmtest
# ***********
#   
# .. automodule:: svm.svmtest

from pysteg.tools import saveObject
import sys
from .dataset import mkdataset

__all__ = [ "svmTest" ]

# The :class:`svmTest` class
# =============================
#
# ::

class svmTest(object):

  def __init__(self,T,S=None,id=None,verbosity=None):
     """
     A :class:`svmTest` object can be created either as
     svmTest(T,id=id) where T is a :class:`fvEval` object,
     or as svmTest(T,S) where T and S are :class:`DataSet` objects,
     with T the training set and S the test set.
     """
     if S == None:
       ((a1,a2),(b1,b2),id) = T.getDataSets(id)
       if verbosity == None: self._verbosity = T.getverbosity()
       if self._verbosity == None: self._verbosity = 1
       self.train = mkdataset(a1,a2,id=id,verbosity=self._verbosity)
       self.test = mkdataset(b1,b2,id=id,verbosity=self._verbosity)
     else:
       self.train = T
       self.test = S
     self.id = id
     if verbosity == None: self._verbosity = 1
     else: self._verbosity = verbosity
  def writeFeatures(self,trainfile,testfile,libsvm=True):
     """
     Write feature data to text files.  The first argument is the name
     of the file for training data, and the second argument for test
     data.  If libsvm=False, the will be comma separated data, otherwise
     it will be in the libsvm sparse format.
     """
     self.train.write( trainfile, libsvm )
     self.test.write( testfile, libsvm )
  def runsvm(self,opt):
    """
    Run the SVM training and testing, and add performance indicators
    as object attributes.
    """

    T = self.train
    S = self.test
    assert self.test.names() != []
    assert self.train.names() != []

  # Pre-processing (scaling and grid search)
  #
  #   ::

    if not hasattr(opt,"outputdir"): opt.outputdir = ""
    if opt.outputdir != None: opt.outputdir = ""

  # Pre-processing (scaling and grid search)
  #
  #   ::

    if opt.unitvar:
      if opt.verbosity > 0: 
         print "[runsvm] Creating scaling model ..."
         sys.stdout.flush()
      T.unitvarModel()
    if not opt.noscaling: 
      if opt.verbosity > 0: 
         print "[runsvm] Scaling ..."
         sys.stdout.flush()
      T.scale()
      if opt.verbosity > 0: 
         print "[runsvm] Scaled training set."
         sys.stdout.flush()
      S.scale(T.getscalemodel())
      if opt.verbosity > 0: 
         print "[runsvm] Scaling comlete"
         sys.stdout.flush()
  
  # SVM Testing
  # ^^^^^^^^^^^
  #
  # First we make a grid search
  #   ::
  
    if opt.verbosity > 0: print "[svmtest] Ready for Grid Search", opt.gnufile
    if opt.gnufile == None: T.gridsearch()
    else: T.gridsearch(pngfile=opt.outputdir+opt.gnufile)
  
  # Train and Predict
  #
  #   ::
  
    if opt.verbosity > 0: print "[svmtest] Ready to train"
    model = T.train()
    if opt.verbosity > 0: 
       print "[runsvm] Trained"
       sys.stdout.flush()
    self.acc = S.predict(model)
    if opt.verbosity > 0:
       print "[runsvm] Tested"
       sys.stdout.flush()
  
  # Output and return
  #
  #   ::
  
    self.gini = S.Gini()
    if opt.id != None: self.id = opt.id

    self.t_acc = T.predict(model)
    self.t_gini = T.Gini()

    if opt.verbosity > 0:
      print "[datsvm] Error rates (training, testing)", \
	    (100-self.t_acc,100-self.acc)
      print "[datsvm] Gini coefficients (training, testing)", \
	    (self.t_gini,self.gini)
      print "[datsvm] Accuracy %s; ROC (AUC) %s" % (self.acc, S.mkauc(), )
   
# Plotting and printing
# ---------------------
#
#   ::

  def mkroc(self,outfile):
      return self.test.rocplot(outfile,addto=False)
  def mkhist(self,outfile):
      return self.test.histplot(filename=outfile,nbin=18,addto=False)
  def printdiag(self):
     print "[svmtest]", (self.id,self.acc,self.gini)
  def dump(self,fn):
     self.train = None
     saveObject(self,fn)
