## $Id$
## -*- coding: utf-8 -*-

"""
:Module:    svm.tools
:Date:      $Date$
:Revision:  $Revision$
:Author:    2010-11: Hans Georg Schaathun <georg@schaathun.net>
:Copyright: 2010: University of Surrey
            2011: Aalesund University College

This module includes methods to manipulate feature vector sets
as lists of lists, including file IO.
"""

# ***************************
# The :mod:`svm.tools` module
# ***************************
#   
#
# .. automodule:: svm.tools

def fvsplit(X):
  """
  Split a list of feature vectors including the label as the first
  element into a pair of lists (L,F), where L is a list of labels
  and F is a list of feature vectors without label.
  """
  L = [ v[0] for v in X ]
  F = [ v[1:] for v in X ]
  return (L, F)

def fvjoin(L,F):
  """
  Join lists of labels and of feature vectors as one lists of
  feature vectors with label as the first element.
  """
  return [ [l] + list(v) for (l,v) in zip(L,F) ]

def savefeatures(fn,l,libsvm=True):
  """
  Save the a list of feature vectors in text format.
  If libsvm=True (default), the sparse format of libsvm
  is used.  Otherwise a comma separated file is used.
  The first entry in each vector is the label.
  """
  if libsvm: strcmd = sparsestr
  else: strcmd = csvstr
  L = [ strcmd(v) + "\n" for v in l ]
  print "[savefeatures] %i vectors to file %s" % (len(L),fn)
  f = open( fn, "w" )
  f.writelines( L )
  f.close()
def sparsestr(L):
   """
   Take a feature vector as returned by featureVector.getVector()
   and make a printable string in the format expected by libSVM.
   """
   return str(L[0]) + "".join(
     [ "  " + str(i) + ":" + str(L[i]) for i in range(1,len(L)) ] )
def csvstr(L):
   """
   Take a feature vector as returned by featureVector.getVector()
   and make a printable string in CSV format.
   """
   return ",".join( [ str(l) for l in L ] )


