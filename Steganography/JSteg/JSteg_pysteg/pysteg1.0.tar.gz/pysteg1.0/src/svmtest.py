#! /usr/bin/env python
## -*- coding: utf-8 -*-
print "$Id$"

# SVM Testing
# ===========

docstring = """
:Script:    svmtest.py
:Date:      $Date$
:Revision:  $Revision$
:Copyright: © 2011: Hans Georg Schaathun <georg@schaathun.net>

svmtest.py -i data.dat -o results.dat [-f id] [-d] [-z]
  Test feature set given in data.dat using SVM.  The data.dat file
  should be on the format produced by bowsdata.py.
  The output file, results.dat, is a pickled object with complete
  classification data.  No tools currently exist to analyse this
  output.  However, very extensive output is created, and the
  accuracy and the area under the ROC curve will appear in the last
  few lines of stdout output.

  If the -f option is given, id specifies a feature subvector
  to use, e.g. PEV-219, otherwise all features would be used.  
  Normally, using all features will give a terrible result because
  of the curse of diensionality, and is strongly discouraged.
  See below.

svmtest.py -i data.dat -o results.dat -F selection -f name [-N n] [-d] [-z]

  This mode uses feature selection as produced by the select.py script.
  It will be documented later.

The -d flag causes extra diagnostic input to be printed.
The -z flag uses unscaled features.

Supported Feature Vectors
-------------------------

CCPEV-438: (aka. MPEV-274) due to Pevny et al.
  Using Cartesian Calibration.

NCPEV-219: (aka. NCPEV-274) due to Pevny et al.  No calibration.

PEV-219: (aka. PEV-274) due to Pevny et al.  Difference calibration.

Markov:  The 243D feature set of Yun Q Shi et al based on Markov chains.

Fridrich:
	The features for JPEG images
        of Jessica Fridrich using difference calibration.

HCF-39: Xuan et al's 39D feature vector using the histogram
   characteristic function.

HCF-390: Chen et al's extension of HCF-39, using features from the JPEG
  domain as well.

SPAM: The SPAM features due to Jessica Fridrich's group.

WAM-27: The wavelet based features from Jessica Fridrich's group.

EM-108: Chen, Want, Tan and Guo's features using the so-called
   empirical matrix.

Farid: Liu and Farid's classic 72D feature set (based on wavelets).

AC-10:  Autocorrelation features of Yadollahpour and Naimi

BSM-12: Binary Similarity Measures of Avcibaş et al.

CP-27: The conditional probability features of Ainuddin Abdul Wahab

ALE-10: Amplitude of Local Extrema of Camncelli et al.

SMCM-130: Sullivan et al's feature designed for the SSIS system.
"""

gnuplotpath = "/usr/bin/gnuplot"

import optparse 
import sys

import pysteg.tools as pt
from svm.svmtest import svmTest
import numpy as np

# The following two lists include all the feature vectors to be included
# if the `all feture sets' flag is used.  For spatial images idlist is
# used, for jpeg images we use jdlist.
#
# ::

idlist = [ "WAM(7)-27", "WAM(B)-27", "AC", "EM-108", "HCF-39", "SPAM",
           "avcibas", "Farid", "HCF", "SMCM-130", "ALE-10",
	   "BSM-18", "BSM-12" ]
jdlist = [ "PEV-219", "HCF-390", "CP", "JHCF", "Markov", "Fridrich"
         ] + idlist


# Function Definitions
# ====================

def diagstr(L):
  "Auxiliary routine for diagnostics printing"
  return "%f (%f) [%f,%f]" % (np.median(L),np.mean(L),min(L),max(L))

def printdiag(L):
   """
   Given a list of classifier test results L,
   print the id, accuracy and Gini coefficient.
   """
   print type(L)
   L = list(L)
   print type(L)
   print "[datsvm] Summary for %i classifiers" % (len(L),)
   for (id,a,g,(T,S)) in L: print (id,a,g)


# Parsing Options
# ---------------

def parseArgs():
  parser = optparse.OptionParser(usage=docstring)

# The following are core options, fully supported and validated.
#
# ::

# File name options::

  parser.add_option("-O", "--svmtest-file",
            help="""Output file for the pickled untrained svmTest object.""",
            dest="svmtestfile" )
  parser.add_option("-o", "--outfile",
            help="""Output file for the pickled test object.""",
            dest="outfile" )
  parser.add_option("-i", "--infile",
            help="Input data file for a pickled fvEval object",
            dest="infile" )

  parser.add_option("-S", "--test-outfile",
            help="""Output file for the test set.""",
            dest="testfile" )
  parser.add_option("-s", "--train-outfile",
            help="""Output file for the training set.""",
            dest="trainfile" )
  parser.add_option("-C", "--csv-format", 
            help="Print features as CSV file instead of libsvm.",
            dest="libsvm", default=True,
	    action='store_false' )

# Scaling options::

  parser.add_option("-z", "--no-scaling", help="Do not scale the features.",
            dest="noscaling", default=False, action="store_true" )
  parser.add_option("-u", "--unit-variance", 
	    help="Scale the features to unit variance.",
            dest="unitvar", default=False, action="store_true" )

# Other options::

  parser.add_option("-f", "--feature-set", 
            help="Feature set identifier (e.g. Fridrich, Markov, CP)",
            dest="id" )
  parser.add_option("-F", "--selection", 
            help="""
	    Use the feature selection from the give file, which should be
	    a pickled fvSelect object.
	    """,
            dest="select" )
  parser.add_option("-N", "--dimension", 
            help="""Use the top N features.""",
            dest="dim" )
  parser.add_option("-d", "--diagnostics", 
            help="Print diagnostics of the embedding.",
            dest="diag", default=False,
	    action='store_true' )
  parser.add_option("-X", "--no-svmtest", 
            help="Do not run the svmtest.  Only makes sense with -O.",
            dest="svmtest", default=True,
	    action='store_false' )


# The -D option is used to specify a common directory for output.
# It is not used for the pickled objects, but should probably be
# used for pdf plots when they are introduced (see options below).
#
#   ::

  parser.add_option("-D", "--outputdir", 
            help="Directory for output files.",
            dest="outputdir", default="" )

# Plotting options.
#
# These options have not been reimplemented for this script.
# They existed in previous versions of the script and should be
# supported.  TODO.
#
# -G  -- outfile for gridsearch contour plot
#
#   ::

  parser.add_option("-G", "--contour-file",
            help="File for the Contour Plot from the Grid Search.",
            dest="gnufile" )

# -H  -- plot file for a classification score histogram

  parser.add_option("-H", "--hist-file",
            help="File for a histogram plot.",
            dest="histfile" )

# -R  -- output file for ROC plot

  parser.add_option("-R", "--roc-file",
            help="File for the ROC Plot.", dest="rocfile" )
  parser.add_option("-r", "--roc-collect-file",
            help="File for a combined ROC Plot for all feature vectors.",
	    dest="roccol" )

# Verbosity is not currently used, but obviously it should be, in a
# standard way.
#
#   ::

  parser.add_option("-v", "--verbose", 
            help="Verbosity level",
            default=0, dest="verbosity" )

  (opt,a) = parser.parse_args()

# Some options need to be converted to appropriate data types::

  opt.verbosity = int(opt.verbosity)

  return (opt,a)

# The actual work
# ===============
#
#   ::

if __name__ == '__main__':
  (opt,args) = parseArgs()

# Potentially, the script may be extended with different modes of operation.
# The infile option is used to specify a pickled fvEval object as the
# basis of running SVM training and testing.
#
#   ::

  if opt.infile != None:
     X = pt.loadObject( opt.infile )
     if hasattr(X,"load"): X.load()
     print "[svmtest] loaded object"
     sys.stdout.flush()

# The actual test is done using an :class:`svmTest` object.
# This may be obtained either as a pickled object, in which case the
# unpickled object X will have a :meth:`runsvm` method; or by instantiation
# based on a pickled :class:`fvEval` object.  In the latter case, a selection
# of features can either be specified directly with the -f option, or via
# a pickled :class:`fvSelect` object given with the -F option.
#
#   ::

     if hasattr(X,"runsvm"):
	assert opt.id == None, \
	      "The pickled file is prepared from SVM; -f does not make sense."
	assert opt.select == None, \
	      "The pickled file is prepared from SVM; -F does not make sense."
	test = X
        print "[svmtest] loaded test object"
     elif opt.select != None:
        Z = pt.loadObject( opt.select )
	L = list( Z.getSelectedKeys() )
	if opt.dim != None: L = L[:int(opt.dim)]
        print "[svmtest] Selection from %s (%i features)" % (opt.select,len(L))
	test = svmTest( X, id=L )
        print "[svmtest] created test object"
     else:
	test = svmTest( X, id=opt.id )
        print "[svmtest] created test object"

# Now the :class:`svmTest` object has been created.
# If requested, we pickle this object for backup.
# This feature should be checked as the class excludes some attributes
# from pickling.  It is possible that the pickled file is rather useless...
#
#   ::

     if opt.svmtestfile != None:
	pt.saveObject(test,opt.svmtestfile)
        print "[svmtest] saved untrained svmtest object"

# Running the test is a simple method call to the :class:`svmTest` object.
#
#   ::

     if opt.svmtest:
        test.runsvm(opt)
        print "[svmtest] completed test run"

# If requested, we store the features in a text file.
#
#   ::

     if opt.trainfile != None:
	assert opt.testfile != None
	test.writeFeatures(opt.trainfile,opt.testfile,libsvm=opt.libsvm)

# Finally, we can store the :class:`svmTest` object to keep a complete
# record of the test results.  This may be useful to compare results
# or generate ROC plots or other reports later.
#
#   ::

     if opt.outfile != None:
	assert test.test.names() != []
	pt.saveObject(test,opt.outfile)
        print "[svmtest] saved test object", opt.outfile
        sys.stdout.flush()

# Currently, no other modes of operation is supported.  We should add 
# modes to load the pickled svmTest objects and produce plots and reports.
#
# The print diagostics feature is not obviously useful, but it does no
# harm so it has been retained::
# 
#   ::

  if opt.diag: test.printdiag()
